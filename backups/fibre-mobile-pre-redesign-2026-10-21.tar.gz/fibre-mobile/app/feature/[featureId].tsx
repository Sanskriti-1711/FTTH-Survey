import React, { useEffect, useMemo, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TextInput,
  TouchableOpacity,
  ActivityIndicator,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useLocalSearchParams, router } from 'expo-router';
import { useThemeStore } from '../../lib/stores/theme';
import { useAuthStore } from '../../lib/stores/auth';
import { useSurveyStore } from '../../lib/stores/survey';
import { useImageStore } from '../../lib/stores/image';
import { useProjectStore } from '../../lib/stores/project';
import { getFeatureDetail as apiGetFeatureDetail } from '../../lib/api/projects';
import { getLayerSchema } from '../../lib/stores/layer-schemas';
import { Card } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { StatusBadge } from '../../components/ui/StatusBadge';
import { Toast } from '../../components/ui/Toast';
import LayerEditor from '../../lib/components/LayerEditor';
import FeatureSurveySections from '../../lib/components/FeatureSurveySections';
import SurveyChangeDiff from '../../lib/components/SurveyChangeDiff';
import CommitBar from '../../lib/components/CommitBar';
import { EMPTY_COMMIT_SUMMARY } from '../../lib/utils/commit';
import { Spacing, Radius } from '../../lib/theme/colors';
import {
  ArrowLeft,
  Camera,
  MapPin,
  Edit3,
  ClipboardList,
} from 'lucide-react-native';
import { useSurveyFeaturesStore } from '../../lib/stores/survey-features';
import type { Feature, GeoJSONFeature, FieldSchemaField } from '../../lib/utils/types';

/**
 * Seed the Field Measurements form with existing values so engineers see
 * what was previously captured instead of blank fields. Priority:
 *   1. Explicitly saved field_measurements (win always)
 *   2. Matching schema editable-field values from the feature's properties
 *      (HLD attributes / survey_attributes) as a starting point
 */
function seedMeasurements(
  layerId: string | null,
  props: Record<string, unknown> | null | undefined,
  existing: Record<string, unknown> | null | undefined
): Record<string, unknown> {
  const base: Record<string, unknown> = { ...(existing ?? {}) };
  if (!layerId || !props) return base;
  const schema = getLayerSchema(layerId);
  if (!schema) return base;
  for (const field of schema.editableFields) {
    if (base[field.key] === undefined && props[field.key] !== undefined) {
      base[field.key] = props[field.key];
    }
  }
  return base;
}

/** Order-independent field comparison — JSON.stringify would call two equal
 *  measurements "dirty" just because their keys came back in another order. */
function sameValues(
  a: Record<string, unknown> | null | undefined,
  b: Record<string, unknown> | null | undefined
): boolean {
  const keysA = Object.keys(a ?? {}).sort();
  const keysB = Object.keys(b ?? {}).sort();
  if (keysA.length !== keysB.length) return false;
  return keysA.every((k, i) => k === keysB[i] && String(a?.[k] ?? '') === String(b?.[k] ?? ''));
}

// ── Feature Detail Screen ─────────────────────────────────────────────────

export default function FeatureDetailScreen() {
  const { featureId, projectId: routeProjectId } = useLocalSearchParams<{ featureId: string; projectId: string }>();
  const colors = useThemeStore((s) => s.colors);
  const { user } = useAuthStore();
  const { updateFieldMeasurements, submitFeatures, isLoading } = useSurveyStore();
  const { addPhoto } = useImageStore();

  const [feature, setFeature] = useState<Feature | null>(null);
  const [geojson, setGeojson] = useState<GeoJSONFeature | null>(null);
  const [measurements, setMeasurements] = useState<Record<string, unknown>>({});
  const [notes, setNotes] = useState('');
  const [toastVisible, setToastVisible] = useState(false);
  const [toastMsg, setToastMsg] = useState('');
  const [toastType, setToastType] = useState<'success' | 'error'>('success');
  const [loading, setLoading] = useState(true);

  const { projectGeojsons } = useProjectStore();

  // ── Resolve the REAL backend feature UUID for survey API calls ─────────
  // The route param can be a synthetic id ("imp-feat-<layer>-<n>") when the
  // GeoJSON carried no backend id, or a SurveyFeature UUID when the engineer
  // opened an orange survey copy. The survey endpoints (risks/hazards/trenches)
  // require a valid projects.Feature UUID, so resolve:
  //   1. the API-loaded feature.id (real HLD UUID) when available
  //   2. the SurveyFeature's original_hld_feature / hld_feature_id
  const backendFeatureId = useMemo((): string => {
    const routeId = (featureId as string) ?? '';
    const isUuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
    // 1. Survey-features store FIRST: if the route id is a survey copy's own
    //    id, map it to its original HLD feature id. The detail endpoint and
    //    the survey sections key on the projects.Feature UUID — using the
    //    copy's id 404s the detail fetch and breaks every survey save.
    const st = useSurveyFeaturesStore.getState();
    for (const list of Object.values(st.surveyFeatures)) {
      const sf = list.find((s) => s.id === routeId);
      if (sf) {
        const hldId = sf.original_hld_feature || sf.hld_feature_id;
        return hldId || routeId;
      }
    }
    // 2. Genuine HLD feature UUID → use as-is.
    if (isUuid.test(routeId)) return routeId;
    // 3. Feature loaded from the API carries the real id (synthetic route id).
    const fid = feature?.id;
    if (fid && isUuid.test(fid)) {
      return fid;
    }
    // 4. Synthetic id that matches an existing survey copy's HLD link.
    for (const list of Object.values(st.surveyFeatures)) {
      const sf = list.find(
        (s) => s.original_hld_feature === routeId || s.hld_feature_id === routeId
      );
      if (sf) {
        const hldId = sf.original_hld_feature || sf.hld_feature_id;
        if (hldId) return hldId;
      }
    }
    return routeId;
  }, [feature, featureId]);

  useEffect(() => {
    if (!featureId) return;
    loadData();
  }, [featureId, routeProjectId]);

  const loadData = async () => {
    try {
      setLoading(true);
      if (routeProjectId) {
        try {
          const data = await apiGetFeatureDetail(routeProjectId, backendFeatureId);
          setFeature(data.feature);
          setGeojson(data.geojson);
          setMeasurements(seedMeasurements(data.feature.layer_id, data.feature.properties, data.feature.field_measurements as Record<string, unknown>));
          setNotes(data.feature.comparison_notes ?? '');
        } catch {
          // API failed — try to find imported feature from project store
          const found = findImportedFeature(featureId as string, projectGeojsons);
          if (found) {
            setFeature(found.feature);
            setGeojson(found.geojson);
            setMeasurements(seedMeasurements(found.feature.layer_id, found.feature.properties, null));
            setNotes('');
          } else {
            // Try survey features store
            const surveyFound = findSurveyFeature(featureId as string);
            if (surveyFound) {
              setFeature(surveyFound.feature);
              setGeojson(surveyFound.geojson);
              setMeasurements(seedMeasurements(surveyFound.feature.layer_id, surveyFound.feature.properties, null));
              setNotes('');
            } else {
              showToast('Failed to load feature details', 'error');
            }
          }
        }
      } else {
        // No routeProjectId — lookup in imported data
        const found = findImportedFeature(featureId as string, projectGeojsons);
        if (found) {
          setFeature(found.feature);
          setGeojson(found.geojson);
          setMeasurements(seedMeasurements(found.feature.layer_id, found.feature.properties, null));
          setNotes('');
        } else {
          // Try survey features store
          const surveyFound = findSurveyFeature(featureId as string);
          if (surveyFound) {
            setFeature(surveyFound.feature);
            setGeojson(surveyFound.geojson);
            setMeasurements(seedMeasurements(surveyFound.feature.layer_id, surveyFound.feature.properties, null));
            setNotes('');
          } else {
            setLoading(false);
          }
        }
      }
    } catch {
      showToast('Failed to load feature details', 'error');
    } finally {
      setLoading(false);
    }
  };

  /** Look up an imported feature by ID in projectGeojsons */
  function findImportedFeature(
    fid: string,
    geojsons: Record<string, import('../../lib/utils/types').GeoJSONFeature[]>
  ): { feature: import('../../lib/utils/types').Feature; geojson: import('../../lib/utils/types').GeoJSONFeature } | null {
    // Try 1: Direct property match (original GeoJSON had an id in properties)
    for (const [layerId, features] of Object.entries(geojsons)) {
      const idx = features.findIndex((f) => f.properties?.id === fid || f.properties?._id === fid);
      if (idx !== -1) {
        const gf = features[idx];
        const feat: import('../../lib/utils/types').Feature = {
          id: fid,
          layer_name: layerId.toUpperCase(),
          layer_id: layerId,
          properties: (gf.properties as Record<string, unknown>) ?? {},
          field_schema: null,
          field_measurements: null,
          comparison_notes: '',
          status: 'assigned',
          photo_url: null,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        };
        return { feature: feat, geojson: gf };
      }
    }

    // Try 2: Parse imported feature ID pattern: imp-feat-{layerId}-{index}
    const match = fid.match(/^imp-feat-(.+?)-(\d+)$/);
    if (match) {
      const [, layerId, idxStr] = match;
      const idx = parseInt(idxStr, 10) - 1;
      const features = geojsons[layerId];
      if (features && features[idx]) {
        const gf = features[idx];
        const feat: import('../../lib/utils/types').Feature = {
          id: fid,
          layer_name: layerId.toUpperCase(),
          layer_id: layerId,
          properties: (gf.properties as Record<string, unknown>) ?? {},
          field_schema: null,
          field_measurements: null,
          comparison_notes: '',
          status: 'assigned',
          photo_url: null,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        };
        return { feature: feat, geojson: gf };
      }
    }

    return null;
  }

  /** Look up a survey feature by ID in the survey-features store */
  function findSurveyFeature(
    fid: string,
  ): { feature: Feature; geojson: GeoJSONFeature } | null {
    const { surveyFeatures } = useSurveyFeaturesStore.getState();
    for (const [layerId, sfList] of Object.entries(surveyFeatures)) {
      const sf = sfList.find((s) => s.id === fid);
      if (sf) {
        const feat: Feature = {
          id: sf.id,
          layer_name: `Survey: ${sf.layer_name || layerId.toUpperCase()}`,
          layer_id: sf.layer_id,
          properties: (sf.survey_attributes as Record<string, unknown>) ?? {},
          field_schema: null,
          field_measurements: null,
          comparison_notes: '',
          status: (sf.survey_status === 'new' || sf.survey_status === 'modified' ? 'assigned' : 'under_review') as 'assigned' | 'under_review',
          photo_url: null,
          created_at: sf.created_at,
          updated_at: sf.updated_at,
        };
        const gf: GeoJSONFeature = {
          type: 'Feature',
          geometry: sf.survey_geometry as { type: string; coordinates: unknown[] },
          properties: feat.properties,
        };
        return { feature: feat, geojson: gf };
      }
    }
    return null;
  }

  const showToast = (msg: string, type: 'success' | 'error' = 'success') => {
    setToastMsg(msg);
    setToastType(type);
    setToastVisible(true);
  };

  // Unsaved = what is on screen differs from what the server holds. Saving the
  // measurements is what makes a later submit carry them, which is why the
  // commit bar warns instead of quietly submitting the old values.
  const hasUnsavedEdits =
    !sameValues(measurements, feature?.field_measurements) ||
    notes !== (feature?.comparison_notes ?? '');

  const handleSave = async () => {
    if (!featureId || !feature) return;
    try {
      await updateFieldMeasurements(featureId as string, measurements, notes);
      showToast('Measurements saved', 'success');
    } catch {
      showToast('Failed to save', 'error');
    }
  };

  // The commit bar owns the confirm (two taps, which also works in the web
  // build where Alert.alert is a no-op) — this is only the request itself.
  const handleSubmit = async () => {
    if (!featureId || !user) return;
    try {
      await submitFeatures([featureId as string], user.id);
      showToast('Feature submitted — the planner has it', 'success');
      if (feature) {
        setFeature({ ...feature, status: 'under_review' });
      }
    } catch {
      showToast('Submit failed — check the connection and try again', 'error');
    }
  };

  const renderFieldSchema = (schema: FieldSchemaField[] | null) => {
    if (!schema || schema.length === 0) return null;

    return schema.map((field) => {
      if (field.type === 'readonly') {
        return (
          <View key={field.key} style={styles.fieldRow}>
            <Text style={[styles.fieldLabel, { color: colors.textSecondary }]}>{field.label}</Text>
            <Text style={[styles.fieldValue, { color: colors.textPrimary }]}>
              {String(measurements[field.key] ?? '—')}
            </Text>
          </View>
        );
      }

      return (
        <View key={field.key} style={styles.fieldRow}>
          <Text style={[styles.fieldLabel, { color: colors.textSecondary }]}>
            {field.label}
            {field.required ? ' *' : ''}
            {field.unit ? ` (${field.unit})` : ''}
          </Text>
          {field.type === 'textarea' ? (
            <TextInput
              style={[
                styles.textarea,
                {
                  color: colors.textPrimary,
                  borderColor: colors.outline,
                  backgroundColor: colors.background,
                },
              ]}
              value={String(measurements[field.key] ?? '')}
              onChangeText={(val) =>
                setMeasurements((prev) => ({ ...prev, [field.key]: val }))
              }
              multiline
              numberOfLines={3}
              placeholder={field.placeholder ?? `Enter ${field.label.toLowerCase()}`}
              placeholderTextColor={colors.textTertiary}
            />
          ) : field.type === 'select' && field.options ? (
            <View style={styles.optionsRow}>
              {field.options.map((opt) => (
                <TouchableOpacity
                  key={opt.value}
                  style={[
                    styles.optionChip,
                    {
                      backgroundColor:
                        measurements[field.key] === opt.value
                          ? colors.primary
                          : colors.outlineLight,
                      borderColor: colors.outline,
                    },
                  ]}
                  onPress={() =>
                    setMeasurements((prev) => ({ ...prev, [field.key]: opt.value }))
                  }
                >
                  <Text
                    style={[
                      styles.optionText,
                      {
                        color:
                          measurements[field.key] === opt.value
                            ? colors.onPrimary
                            : colors.textSecondary,
                      },
                    ]}
                  >
                    {opt.label}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          ) : field.type === 'boolean' ? (
            <TouchableOpacity
              style={[
                styles.toggleBtn,
                {
                  backgroundColor: measurements[field.key]
                    ? colors.success + '20'
                    : colors.outlineLight,
                  borderColor: measurements[field.key] ? colors.success : colors.outline,
                },
              ]}
              onPress={() =>
                setMeasurements((prev) => ({
                  ...prev,
                  [field.key]: !prev[field.key],
                }))
              }
            >
              <Text
                style={{
                  color: measurements[field.key] ? colors.success : colors.textSecondary,
                  fontSize: 14,
                  fontWeight: '500',
                }}
              >
                {measurements[field.key] ? 'Yes' : 'No'}
              </Text>
            </TouchableOpacity>
          ) : (
            <TextInput
              style={[
                styles.textInput,
                {
                  color: colors.textPrimary,
                  borderColor: colors.outline,
                  backgroundColor: colors.background,
                },
              ]}
              value={String(measurements[field.key] ?? '')}
              onChangeText={(val) =>
                setMeasurements((prev) => ({
                  ...prev,
                  [field.key]: field.type === 'number' ? Number(val) || 0 : val,
                }))
              }
              keyboardType={field.type === 'number' ? 'numeric' : 'default'}
              placeholder={field.placeholder ?? `Enter ${field.label.toLowerCase()}`}
              placeholderTextColor={colors.textTertiary}
            />
          )}
        </View>
      );
    });
  };

  if (loading) {
    return (
      <SafeAreaView style={[styles.safe, { backgroundColor: colors.background }]}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={colors.primary} />
        </View>
      </SafeAreaView>
    );
  }

  if (!feature) {
    return (
      <SafeAreaView style={[styles.safe, { backgroundColor: colors.background }]}>
        <View style={styles.loadingContainer}>
          <Text style={{ color: colors.textSecondary }}>Feature not found</Text>
          <Button title="Go Back" variant="secondary" size="sm" onPress={() => router.back()} style={{ marginTop: 16 }} />
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={[styles.safe, { backgroundColor: colors.background }]} edges={['top']}>
      <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.topBar}>
          <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
            <ArrowLeft size={22} stroke={colors.textPrimary} />
          </TouchableOpacity>
          <View style={styles.topInfo}>
            <Text style={[styles.featureTitle, { color: colors.textPrimary }]} numberOfLines={1}>
              {feature.layer_name}
            </Text>
          </View>
          <StatusBadge status={feature.status} />
        </View>

        {/* GPS / Coordinates */}
        {geojson?.geometry && (
          <View style={[styles.gpsBar, { backgroundColor: colors.surface }]}>
            <MapPin size={14} stroke={colors.primary} />
            <Text style={[styles.gpsText, { color: colors.textSecondary }]} numberOfLines={1}>
              {(() => {
                try {
                  const coords = geojson.geometry.coordinates;
                  const geomType = geojson.geometry.type;
                  if (geomType === 'Point') {
                    return `Lat ${(coords[1] as number).toFixed(6)}, Lng ${(coords[0] as number).toFixed(6)}`;
                  } else if (geomType === 'LineString') {
                    const pts = coords as number[][];
                    return `${pts.length} pts • ${pts[0][1].toFixed(4)}, ${pts[0][0].toFixed(4)} → ${pts[pts.length - 1][1].toFixed(4)}, ${pts[pts.length - 1][0].toFixed(4)}`;
                  } else if (geomType === 'Polygon') {
                    return `Polygon • ${((coords as number[][][])[0]?.length ?? 0)} vertices`;
                  }
                  return JSON.stringify(coords).slice(0, 60);
                } catch { return ''; }
              })()}
            </Text>
          </View>
        )}

        {/* Reference Properties — only non-schema fields (schema read-only/editable
            fields are already displayed with proper labels inside Field Measurements) */}
        {feature.properties && Object.keys(feature.properties).length > 0 && (() => {
          const schema = feature.layer_id ? getLayerSchema(feature.layer_id) : null;
          const schemaKeys = new Set([
            ...(schema?.readOnlyFields ?? []).map((f) => f.key),
            ...(schema?.editableFields ?? []).map((f) => f.key),
          ]);
          // Skip injected live-geometry props + internal ids (redundant noise)
          const excessKeys = new Set([
            'id', '_id', '_layer_id', '_layer_name', '_is_survey',
            'latitude', 'longitude', 'vertex_count',
            'start_lat', 'start_lng', 'end_lat', 'end_lng',
          ]);
          const entries = Object.entries(feature.properties as Record<string, unknown>).filter(
            ([key, value]) =>
              !key.startsWith('_') &&
              !excessKeys.has(key) &&
              !schemaKeys.has(key) &&
              value !== null &&
              value !== undefined &&
              String(value).trim() !== ''
          );
          if (entries.length === 0) return null;
          return (
            <Card title="Reference Data" variant="outlined">
              {entries.map(([key, value]) => (
                <View key={key} style={styles.propRow}>
                  <Text style={[styles.propKey, { color: colors.textSecondary }]}>{key}</Text>
                  <Text style={[styles.propValue, { color: colors.textPrimary }]}>
                    {String(value).slice(0, 100)}
                  </Text>
                </View>
              ))}
            </Card>
          );
        })()}

        {/* Dynamic Form — LayerEditor replaces legacy schema renderer */}
        <Card title="Field Measurements" variant="default">
          <LayerEditor
            layerId={feature.layer_id}
            measurements={measurements}
            properties={(feature.properties as Record<string, unknown>) ?? {}}
            onFieldChange={(key, value) =>
              setMeasurements((prev) => ({ ...prev, [key]: value }))
            }
            onSave={async (updatedMeasurements) => {
              if (!featureId) return;
              try {
                await updateFieldMeasurements(featureId as string, updatedMeasurements, notes);
                showToast('Measurements saved', 'success');
              } catch {
                showToast('Failed to save', 'error');
              }
            }}
            saving={isLoading}
          />
        </Card>

        {/* Notes */}
        <Card title="Notes" variant="outlined" headerRight={
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}>
            <Edit3 size={12} stroke={colors.textTertiary} />
            <Text style={[styles.cardHeaderHint, { color: colors.textTertiary }]}>Observations</Text>
          </View>
        }>
          <TextInput
            style={[
              styles.textarea,
              {
                color: colors.textPrimary,
                borderColor: colors.outline,
                backgroundColor: colors.background,
              },
            ]}
            value={notes}
            onChangeText={setNotes}
            placeholder="Add comparison notes or observations..."
            placeholderTextColor={colors.textTertiary}
            multiline
            numberOfLines={4}
          />
        </Card>

        {/* ── Survey: change diff + typed survey facts ── */}
        <View style={{ marginTop: Spacing.md }}>
          <View style={styles.surveyModulesHeader}>
            <ClipboardList size={16} stroke={colors.primary} />
            <Text style={[styles.surveyModulesTitle, { color: colors.textPrimary }]}>Survey</Text>
          </View>
          <SurveyChangeDiff
            featureId={backendFeatureId}
            projectId={routeProjectId}
          />
          <FeatureSurveySections
            featureId={backendFeatureId}
            layerId={feature.layer_id}
            initialGeometry={(geojson?.geometry as Record<string, unknown> | null | undefined) ?? null}
          />
        </View>

        {/* Photo */}
        <Card
          title="Photos"
          variant="outlined"
          headerRight={
            <TouchableOpacity
              style={[styles.addPhotoBtn, { backgroundColor: colors.primary }]}
              onPress={() => router.push({ pathname: '/camera', params: { featureId: featureId as string } })}
            >
              <Camera size={16} stroke={colors.onPrimary} />
              <Text style={[styles.addPhotoText, { color: colors.onPrimary }]}>Add</Text>
            </TouchableOpacity>
          }
        >
          {feature.photo_url ? (
            <View style={styles.photoPreview}>
              <Text style={[styles.photoUrl, { color: colors.textSecondary }]} numberOfLines={1}>
                Photo uploaded
              </Text>
            </View>
          ) : (
            <Text style={[styles.noPhoto, { color: colors.textTertiary }]}>
              No photos attached yet. Use the camera to capture field evidence.
            </Text>
          )}
        </Card>
      </ScrollView>

      {/* Sticky Bottom Actions — the same commit bar as the map, so Save and
          Submit always live in the same place with the same words. */}
      <CommitBar
        onSave={handleSave}
        onSubmit={handleSubmit}
        summary={{ ...EMPTY_COMMIT_SUMMARY, unsaved: hasUnsavedEdits ? 1 : 0 }}
        summaryText={
          hasUnsavedEdits
            ? 'Unsaved edits on this feature — Save to keep them'
            : 'Measurements saved'
        }
        submitLabel="Submit feature"
        submittedLabel={
          feature?.status === 'under_review' ? 'Submitted — with the planner' : undefined
        }
        busy={isLoading}
        expectChanges={false}
      />

      <Toast visible={toastVisible} message={toastMsg} type={toastType} onDismiss={() => setToastVisible(false)} />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1 },
  scroll: { padding: Spacing.lg, paddingBottom: 100 },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  topBar: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.md,
    marginBottom: Spacing.md,
  },
  backBtn: { width: 40, height: 40, alignItems: 'center', justifyContent: 'center' },
  topInfo: { flex: 1 },
  featureTitle: { fontSize: 18, fontWeight: '600' },
  gpsBar: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: Spacing.md,
    borderRadius: Radius.md,
    marginBottom: Spacing.lg,
    gap: Spacing.sm,
  },
  gpsText: { fontSize: 12, flex: 1 },
  propRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: Spacing.xs,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: '#E5E7EB',
  },
  propKey: { fontSize: 13, flex: 1 },
  propValue: { fontSize: 13, flex: 1.5, textAlign: 'right', fontWeight: '500' },
  fieldRow: { marginBottom: Spacing.lg },
  fieldLabel: { fontSize: 13, fontWeight: '500', marginBottom: Spacing.xs },
  fieldValue: { fontSize: 15, fontWeight: '500' },
  textInput: {
    borderWidth: 1,
    borderRadius: Radius.md,
    paddingHorizontal: Spacing.lg,
    height: 56,
    fontSize: 15,
  },
  textarea: {
    borderWidth: 1,
    borderRadius: Radius.md,
    paddingHorizontal: Spacing.lg,
    paddingTop: Spacing.md,
    fontSize: 15,
    minHeight: 100,
    textAlignVertical: 'top',
  },
  optionsRow: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.sm },
  optionChip: {
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: Radius.full,
    borderWidth: 1,
  },
  optionText: { fontSize: 13, fontWeight: '500' },
  toggleBtn: {
    alignSelf: 'flex-start',
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: Radius.md,
    borderWidth: 1,
  },
  noSchema: { fontSize: 14, textAlign: 'center', paddingVertical: Spacing.lg },
  photoPreview: { padding: Spacing.md },
  photoUrl: { fontSize: 13 },
  noPhoto: { fontSize: 14, textAlign: 'center', paddingVertical: Spacing.lg },
  addPhotoBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: Radius.full,
  },
  addPhotoText: { fontSize: 12, fontWeight: '600' },
  // ── Survey Modules Header ─────────────────────────────────────────
  surveyModulesHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    marginBottom: Spacing.md,
  },
  surveyModulesTitle: {
    fontSize: 17,
    fontWeight: '700',
  },

  // ── Card Header Hint ──────────────────────────────────────────────
  cardHeaderHint: {
    fontSize: 11,
    fontStyle: 'italic',
  },

});
