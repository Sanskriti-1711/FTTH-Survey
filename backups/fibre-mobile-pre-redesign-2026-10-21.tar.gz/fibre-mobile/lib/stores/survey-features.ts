// ── Survey Features Store (HLD/Survey Separation) ────────────────────────
//
// This store manages SurveyFeature data separately from the HLD (High-Level
// Design) features. The HLD remains read-only — all engineer edits create or
// update SurveyFeature records that reference the original HLD feature.
//
// Architecture (think of it like Git):
//   HLD    = Original branch  (read-only, blue styling)
//   Survey = Working branch   (editable, orange styling)
//   Planner = Merge request   (future: compare HLD vs Survey)

import { create } from 'zustand';
import * as surveyApi from '../api/survey';
import { useProjectStore } from './project';
import { useOfflineStore } from './offline';
import type { TypedSurveyPayload } from '../api/survey';
import type { SurveyFeatureData, GeoJSONFeature, LayerDisplayMode } from '../utils/types';

// ── Offline edit queue ────────────────────────────────────────────────────
// Every edit used to be written straight to the API, so a Save in a street
// with no signal simply failed: the reroute was lost even though the store
// has an offline mode and a pending-sync counter. Writes that cannot reach
// the server are now applied to the LOCAL store with sync_status='pending' and
// queued; they are replayed in order as soon as the device is back online.
//
// The queue lives for the app session (the app has no persistent key/value
// store wired up); the local survey features themselves stay in the store, so
// nothing is lost while the app is running.
export type PendingSurveyEdit =
  | { kind: 'create'; localId: string; layerId: string; body: Parameters<typeof surveyApi.createSurveyFeature>[0] }
  | { kind: 'upsert'; localId: string; layerId: string; body: Parameters<typeof surveyApi.upsertSurveyFeature>[0] }
  | { kind: 'update'; surveyFeatureId: string; layerId: string; data: Partial<SurveyFeatureData> };

/** True for failures that mean "no usable network" rather than "server said no". */
export function isOfflineError(err: unknown): boolean {
  if (!err) return false;
  const status = (err as { status?: number }).status;
  if (status === 0) return true;
  const msg = err instanceof Error ? err.message : String(err);
  if (/no internet|network request failed|failed to fetch|networkerror|load failed|timed? ?out/i.test(msg)) return true;
  // fetch() rejects with a TypeError when the request never reaches a server.
  return typeof TypeError !== 'undefined' && err instanceof TypeError;
}

function localFeatureId(): string {
  return `local-sf-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
}

/** Apply a PATCH to the local store only (offline path). */
function applyLocalUpdate(
  set: (fn: (s: SurveyFeaturesState) => Partial<SurveyFeaturesState>) => void,
  get: () => SurveyFeaturesState,
  surveyFeatureId: string,
  layerId: string,
  data: Partial<Pick<SurveyFeatureData, 'survey_geometry' | 'survey_attributes' | 'survey_status' | 'change_reason'>>,
): void {
  const cleanData: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(data ?? {})) {
    if (v !== undefined) cleanData[k] = v;
  }
  void get;
  set((s) => ({
    surveyFeatures: {
      ...s.surveyFeatures,
      [layerId]: (s.surveyFeatures[layerId] ?? []).map((sf) =>
        sf.id === surveyFeatureId
          ? ({ ...sf, ...cleanData, sync_status: 'pending', updated_at: new Date().toISOString() } as SurveyFeatureData)
          : sf,
      ),
    },
  }));
}

// ── Color scheme for survey features (orange) ─────────────────────────────
export const SURVEY_COLOR = '#FF8C00'; // Dark orange — survey edits
export const HLD_COLOR_OVERRIDE = '#2563EB'; // Blue — original HLD

interface SurveyFeaturesState {
  /** Survey features keyed by layer_id */
  surveyFeatures: Record<string, SurveyFeatureData[]>;
  /** Whether survey features have been loaded for the active project */
  isLoaded: boolean;
  isLoading: boolean;
  error: string | null;

  /** Display mode: 'hld' = blue only, 'survey' = orange only, 'overlay' = both */
  displayMode: LayerDisplayMode;

  /** Survey feature to focus/highlight when the map opens (deep-link target). */
  focusFeatureId: string | null;
  /** Request the map to fly to + highlight a specific survey feature. */
  setFocusFeature: (featureId: string | null) => void;

  /**
   * Review isolation: when set, the map renders ONLY this survey feature
   * (orange, highlighted) plus its original HLD counterpart (dimmed blue,
   * immutable). Used by the planner's approval queue "View on Map".
   */
  isolateFeatureId: string | null;
  /** Enter/exit single-feature review isolation. */
  setIsolateFeature: (featureId: string | null) => void;

  /** Load all survey features for a project from the backend */
  fetchSurveyFeatures: (projectId: string) => Promise<void>;

  /** Upsert (create-or-update) a survey feature when the engineer starts editing an HLD feature.
   *  Pass hldFeatureId = null for brand-new engineer-created features (e.g. Add Point).
   *  typedData carries optional typed domain data (trench/risks/hazards/evidence). */
  upsertSurveyFeature: (
    hldFeatureId: string | null,
    layerId: string,
    layerName: string,
    surveyGeometry: Record<string, unknown>,
    surveyAttributes?: Record<string, unknown>,
    originalGeometry?: Record<string, unknown> | null,
    originalAttributes?: Record<string, unknown> | null,
    changeReason?: string,
    typedData?: TypedSurveyPayload,
    gpsMeta?: { accuracyM?: number | null; quality?: string },
    /** Record the write as a removal instead of a new/modified survey copy.
     *  Used by the Delete tool's logical delete: the row is kept (not deleted)
     *  so the planner and the LLD review queue can see the feature was removed
     *  in the field. */
    surveyStatus?: 'new' | 'removed',
  ) => Promise<SurveyFeatureData | null>;

  /** Update an existing survey feature's geometry or attributes */
  updateSurveyFeature: (
    surveyFeatureId: string,
    layerId: string,
    data: Partial<Pick<SurveyFeatureData, 'survey_geometry' | 'survey_attributes' | 'survey_status' | 'change_reason'>>,
  ) => Promise<void>;

  /** Delete a survey feature (e.g. when the engineer discards an edit) */
  deleteSurveyFeature: (surveyFeatureId: string, layerId: string) => Promise<void>;

  /** Set the display mode (hld / survey / overlay) */
  setDisplayMode: (mode: LayerDisplayMode) => void;

  /** Clear all survey features (e.g. when switching projects) */
  clearSurveyFeatures: () => void;

  /** Convert survey features for a layer into GeoJSONFeature[] for map rendering */
  surveyFeaturesToGeoJSON: (layerId: string) => GeoJSONFeature[];

  /** Get survey features for a specific HLD feature (if any exist) */
  getSurveyFeatureForHld: (hldFeatureId: string) => SurveyFeatureData | null;

  // ── Offline queue ───────────────────────────────────────────────────────
  /** Edits waiting for a connection, in the order they were made */
  pendingEdits: PendingSurveyEdit[];
  /** True while a replay is running */
  isFlushing: boolean;
  /** Queue one edit and reflect it locally */
  enqueuePendingEdit: (edit: PendingSurveyEdit) => void;
  /** Replay the queue (called when connectivity returns) */
  flushPendingEdits: () => Promise<{ synced: number; failed: number }>;
}

export const useSurveyFeaturesStore = create<SurveyFeaturesState>((set, get) => ({
  surveyFeatures: {},
  isLoaded: false,
  isLoading: false,
  error: null,
  displayMode: 'hld', // Default: show HLD only (blue)
  focusFeatureId: null,
  isolateFeatureId: null,
  pendingEdits: [],
  isFlushing: false,

  enqueuePendingEdit: (edit) => {
    set((s) => ({ pendingEdits: [...s.pendingEdits, edit] }));
    useOfflineStore.getState().incrementPending();
    console.log(`[SurveyFeatures] Queued offline ${edit.kind} edit — ${get().pendingEdits.length} pending`);
  },

  flushPendingEdits: async () => {
    const queue = get().pendingEdits;
    if (queue.length === 0 || get().isFlushing) return { synced: 0, failed: 0 };
    if (!useOfflineStore.getState().isOnline) return { synced: 0, failed: queue.length };
    set({ isFlushing: true });
    let synced = 0;
    let failed = 0;
    const remaining: PendingSurveyEdit[] = [];

    // Replace the local placeholder with the server record so the map/list stop
    // showing a temporary id, and mark it synced. Updates queued against a
    // local id were folded into its create/upsert body when they were made.
    const applyServerRecord = (localId: string, server: SurveyFeatureData) => {
      set((s) => {
        const next: Record<string, SurveyFeatureData[]> = { ...s.surveyFeatures };
        for (const [layerId, list] of Object.entries(next)) {
          const idx = list.findIndex((sf) => sf.id === localId);
          if (idx >= 0) {
            const updated = [...list];
            updated[idx] = { ...server, sync_status: 'synced' };
            next[layerId] = updated;
          }
        }
        return { surveyFeatures: next };
      });
    };

    for (const edit of queue) {
      try {
        if (edit.kind === 'create') {
          const res = await surveyApi.createSurveyFeature(edit.body);
          applyServerRecord(edit.localId, res);
        } else if (edit.kind === 'upsert') {
          const res = await surveyApi.upsertSurveyFeature(edit.body);
          applyServerRecord(edit.localId, res);
        } else {
          const res = await surveyApi.updateSurveyFeature(edit.surveyFeatureId, edit.data);
          const cleanData: Record<string, unknown> = {};
          for (const [k, v] of Object.entries(edit.data ?? {})) {
            if (v !== undefined) cleanData[k] = v;
          }
          set((s) => ({
            surveyFeatures: {
              ...s.surveyFeatures,
              [edit.layerId]: (s.surveyFeatures[edit.layerId] ?? []).map((sf) =>
                sf.id === edit.surveyFeatureId
                  ? ({ ...res, ...cleanData, sync_status: 'synced' } as SurveyFeatureData)
                  : sf,
              ),
            },
          }));
        }
        synced++;
        useOfflineStore.getState().decrementPending();
      } catch (err) {
        failed++;
        remaining.push(edit);
        console.warn('[SurveyFeatures] Replay failed, edit stays queued:', err instanceof Error ? err.message : err);
      }
    }

    set({ pendingEdits: remaining, isFlushing: false });
    if (synced > 0) useOfflineStore.getState().setLastSync(new Date().toISOString());
    console.log(`[SurveyFeatures] Offline replay: ${synced} synced, ${failed} still queued`);
    return { synced, failed };
  },

  fetchSurveyFeatures: async (projectId: string) => {
    if (projectId.startsWith('imported-')) {
      // Local-only import project — no survey features on the backend
      set({ surveyFeatures: {}, isLoaded: true, isLoading: false });
      return;
    }

    set({ isLoading: true, error: null });
    try {
      // Fetch all survey features for this project (paginated — get up to 500)
      const data = await surveyApi.listSurveyFeatures({
        project: projectId,
        page_size: 100,
      });

      // Group by layer_id
      const grouped: Record<string, SurveyFeatureData[]> = {};
      for (const sf of data.results) {
        if (!grouped[sf.layer_id]) grouped[sf.layer_id] = [];
        grouped[sf.layer_id].push(sf);
      }

      // If there are more pages, fetch them
      let allResults = data.results;
      let currentPage = data.page;
      while (currentPage < data.total_pages && currentPage < 10) {
        currentPage++;
        const more = await surveyApi.listSurveyFeatures({
          project: projectId,
          page: currentPage,
          page_size: 100,
        });
        for (const sf of more.results) {
          if (!grouped[sf.layer_id]) grouped[sf.layer_id] = [];
          grouped[sf.layer_id].push(sf);
        }
        allResults = allResults.concat(more.results);
      }

      console.log(
        `[SurveyFeatures] Loaded ${allResults.length} survey features across ${Object.keys(grouped).length} layers`
      );

      set({ surveyFeatures: grouped, isLoaded: true, isLoading: false });
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Failed to fetch survey features';
      console.error('[SurveyFeatures] fetchSurveyFeatures:', message);
      set({ error: message, isLoading: false, isLoaded: true });
    }
  },

  upsertSurveyFeature: async (
    hldFeatureId,
    layerId,
    layerName,
    surveyGeometry,
    surveyAttributes,
    originalGeometry,
    originalAttributes,
    changeReason,
    typedData,
    gpsMeta,
    surveyStatus,
  ) => {
    const activeProject = useProjectStore.getState().activeProject;
    if (!activeProject || activeProject.id.startsWith('imported-')) {
      return null;
    }

    // ── Build the request body once so an offline queue entry is byte-identical
    // to what would have been sent on the wire.
    const hldBody = hldFeatureId
      ? {
          original_hld_feature: hldFeatureId,
          project: activeProject.id,
          layer_id: layerId,
          layer_name: layerName,
          survey_geometry: surveyGeometry,
          survey_attributes: surveyAttributes,
          original_geometry: originalGeometry,
          original_attributes: originalAttributes,
          change_reason: changeReason,
          ...(surveyStatus ? { survey_status: surveyStatus } : {}),
          ...(typedData || {}),
          ...(gpsMeta
            ? { gps_accuracy_m: gpsMeta.accuracyM ?? null, gps_quality: gpsMeta.quality || '' }
            : {}),
        }
      : null;
    const newBody = !hldFeatureId
      ? {
          original_hld_feature: null,
          project: activeProject.id,
          layer_id: layerId,
          layer_name: layerName,
          original_geometry: originalGeometry ?? null,
          original_attributes: originalAttributes ?? null,
          survey_geometry: surveyGeometry,
          survey_attributes: surveyAttributes ?? {},
          survey_status: (surveyStatus ?? 'new') as 'new' | 'removed',
          version_number: 1,
          sync_status: 'pending' as const,
          change_reason: changeReason ?? '',
          ...(typedData || {}),
          ...(gpsMeta
            ? { gps_accuracy_m: gpsMeta.accuracyM ?? null, gps_quality: gpsMeta.quality || '' }
            : {}),
        }
      : null;

    /** Keep the edit locally when the server is unreachable, and queue it. */
    const keepOffline = (): SurveyFeatureData => {
      // Reuse the pending record for this HLD feature / layer so repeated
      // offline saves update one local feature (and one queue entry) instead
      // of piling up duplicates.
      const existingLocal = (get().surveyFeatures[layerId] ?? []).find(
        (sf) => sf.sync_status === 'pending' && (hldFeatureId ? sf.original_hld_feature === hldFeatureId : true),
      );
      const id = existingLocal?.id ?? localFeatureId();
      const local: SurveyFeatureData = {
        id,
        original_hld_feature: hldFeatureId,
        hld_feature_id: hldFeatureId,
        project: activeProject.id,
        project_name: activeProject.name ?? '',
        engineer: existingLocal?.engineer ?? '',
        engineer_name: existingLocal?.engineer_name ?? '',
        layer_id: layerId,
        layer_name: layerName,
        original_geometry: (originalGeometry ?? existingLocal?.original_geometry ?? null) as SurveyFeatureData['original_geometry'],
        original_attributes: (originalAttributes ?? existingLocal?.original_attributes ?? null) as SurveyFeatureData['original_attributes'],
        survey_geometry: surveyGeometry as SurveyFeatureData['survey_geometry'],
        survey_attributes: (surveyAttributes ?? existingLocal?.survey_attributes ?? {}) as SurveyFeatureData['survey_attributes'],
        survey_status: surveyStatus ?? existingLocal?.survey_status ?? (hldFeatureId ? 'modified' : 'new'),
        version_number: existingLocal?.version_number ?? 1,
        sync_status: 'pending',
        change_reason: changeReason ?? existingLocal?.change_reason ?? '',
        created_at: existingLocal?.created_at ?? new Date().toISOString(),
        updated_at: new Date().toISOString(),
      };

      set((s) => {
        const list = s.surveyFeatures[layerId] ?? [];
        const idx = list.findIndex((sf) => sf.id === id);
        const nextList = idx >= 0 ? list.map((sf) => (sf.id === id ? local : sf)) : [...list, local];
        return { surveyFeatures: { ...s.surveyFeatures, [layerId]: nextList } };
      });

      const edit: PendingSurveyEdit = hldBody
        ? { kind: 'upsert', localId: id, layerId, body: hldBody as Parameters<typeof surveyApi.upsertSurveyFeature>[0] }
        : { kind: 'create', localId: id, layerId, body: newBody as Parameters<typeof surveyApi.createSurveyFeature>[0] };
      get().enqueuePendingEdit(edit);
      console.log(`[SurveyFeatures] Offline — ${hldFeatureId ? 'upsert' : 'create'} kept locally as ${id}`);
      return local;
    };

    if (!useOfflineStore.getState().isOnline) {
      return keepOffline();
    }

    try {
      let result: SurveyFeatureData;

      if (hldBody) {
        // ── Existing HLD feature → upsert ──
        result = await surveyApi.upsertSurveyFeature(hldBody);
      } else {
        // ── Brand-new engineer-created feature (no HLD parent) → create ──
        result = await surveyApi.createSurveyFeature(
          newBody as Parameters<typeof surveyApi.createSurveyFeature>[0],
        );
      }

      // Update local state
      set((s) => {
        const existing = s.surveyFeatures[layerId] ?? [];
        if (hldFeatureId) {
          const idx = existing.findIndex((sf) => sf.original_hld_feature === hldFeatureId);
          if (idx >= 0) {
            const updated = [...existing];
            updated[idx] = result;
            return { surveyFeatures: { ...s.surveyFeatures, [layerId]: updated } };
          }
        }
        // Add new
        return {
          surveyFeatures: {
            ...s.surveyFeatures,
            [layerId]: [...existing, result],
          },
        };
      });

      console.log(`[SurveyFeatures] ${hldFeatureId ? 'Upserted' : 'Created'} survey feature → ${result.id}`);
      return result;
    } catch (err: unknown) {
      // No usable network → keep the edit locally and queue it instead of
      // throwing the engineer's work away with a "Save failed" toast.
      if (isOfflineError(err)) {
        return keepOffline();
      }
      const message = err instanceof Error ? err.message : 'Failed to upsert survey feature';
      console.error('[SurveyFeatures] upsertSurveyFeature:', message);
      set({ error: message });
      return null;
    }
  },

  updateSurveyFeature: async (surveyFeatureId, layerId, data) => {
    // An edit of a feature that only exists locally folds into that feature's
    // queued create/upsert — never into a PATCH for an id the server has never
    // seen. The queue stays one entry per feature.
    if (surveyFeatureId.startsWith('local-sf-')) {
      const cleanData: Record<string, unknown> = {};
      for (const [k, v] of Object.entries(data ?? {})) if (v !== undefined) cleanData[k] = v;
      set((s) => ({
        surveyFeatures: {
          ...s.surveyFeatures,
          [layerId]: (s.surveyFeatures[layerId] ?? []).map((sf) =>
            sf.id === surveyFeatureId
              ? ({ ...sf, ...cleanData, updated_at: new Date().toISOString() } as SurveyFeatureData)
              : sf,
          ),
        },
        pendingEdits: get().pendingEdits.map((edit) =>
          (edit.kind === 'create' || edit.kind === 'upsert') && edit.localId === surveyFeatureId
            ? ({ ...edit, body: { ...edit.body, ...cleanData } } as PendingSurveyEdit)
            : edit,
        ),
      }));
      console.log(`[SurveyFeatures] Local-only edit folded into queued write ${surveyFeatureId}`);
      return;
    }

    const isOffline = !useOfflineStore.getState().isOnline;
    if (isOffline) {
      applyLocalUpdate(set, get, surveyFeatureId, layerId, data);
      get().enqueuePendingEdit({ kind: 'update', surveyFeatureId, layerId, data });
      return;
    }

    try {
      const result = await surveyApi.updateSurveyFeature(surveyFeatureId, data);
      set((s) => {
        const features = s.surveyFeatures[layerId] ?? [];
        // Merge the requested fields OVER the API response: the backend
        // serializer can echo stale/original values (e.g. it ignores
        // survey_status PATCHes), so the fields we just sent must win.
        // Drop undefined keys so a caller that omits a field can't clobber
        // the backend's value with undefined.
        const cleanData: Record<string, unknown> = {};
        for (const [k, v] of Object.entries(data ?? {})) {
          if (v !== undefined) cleanData[k] = v;
        }
        const updated = features.map((sf) =>
          sf.id === surveyFeatureId ? ({ ...result, ...cleanData } as SurveyFeatureData) : sf
        );
        return { surveyFeatures: { ...s.surveyFeatures, [layerId]: updated } };
      });
    } catch (err: unknown) {
      // No usable network: apply locally and queue. A real server rejection
      // (4xx/5xx) still throws so callers can block submission/approval.
      if (isOfflineError(err)) {
        applyLocalUpdate(set, get, surveyFeatureId, layerId, data);
        get().enqueuePendingEdit({ kind: 'update', surveyFeatureId, layerId, data });
        return;
      }
      const message = err instanceof Error ? err.message : 'Failed to update survey feature';
      console.error('[SurveyFeatures] updateSurveyFeature:', message);
      set({ error: message });
      // Do not silently convert a failed database write into a successful
      // local edit. Callers must be able to stop submission/approval when the
      // reroute was not persisted.
      throw err instanceof Error ? err : new Error(message);
    }
  },

  deleteSurveyFeature: async (surveyFeatureId, layerId) => {
    try {
      await surveyApi.deleteSurveyFeature(surveyFeatureId);
      set((s) => {
        const features = s.surveyFeatures[layerId] ?? [];
        return {
          surveyFeatures: {
            ...s.surveyFeatures,
            [layerId]: features.filter((sf) => sf.id !== surveyFeatureId),
          },
        };
      });
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Failed to delete survey feature';
      console.error('[SurveyFeatures] deleteSurveyFeature:', message);
      set({ error: message });
    }
  },

  setDisplayMode: (mode) => set({ displayMode: mode }),

  setFocusFeature: (featureId) => set({ focusFeatureId: featureId }),

  setIsolateFeature: (featureId) => set({ isolateFeatureId: featureId }),

  clearSurveyFeatures: () => set({ surveyFeatures: {}, isLoaded: false, error: null, isolateFeatureId: null }),

  surveyFeaturesToGeoJSON: (layerId: string): GeoJSONFeature[] => {
    const features = get().surveyFeatures[layerId] ?? [];
    return features
      .filter((sf) => sf.survey_status !== 'removed')
      .map((sf) => ({
        type: 'Feature' as const,
        geometry: sf.survey_geometry as { type: string; coordinates: unknown[] },
        properties: {
          ...sf.survey_attributes,
          id: sf.id,
          _survey_feature_id: sf.id,
          _hld_feature_id: sf.original_hld_feature,
          _is_survey: true,
          _survey_status: sf.survey_status,
          _version: sf.version_number,
        },
      }));
  },

  getSurveyFeatureForHld: (hldFeatureId: string): SurveyFeatureData | null => {
    const all = get().surveyFeatures;
    for (const layerFeatures of Object.values(all)) {
      const found = layerFeatures.find((sf) => sf.original_hld_feature === hldFeatureId);
      if (found) return found;
    }
    return null;
  },
}));
