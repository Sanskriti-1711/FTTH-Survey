// ── Cross-Platform MapLibre Map Component ───────────────────────────────
// Uses @maplibre/maplibre-react-native on mobile (iOS/Android)
// Falls back to CDN-loaded maplibre-gl on web
//
// Features:
//   ✓ Animated loading overlay with progress dots
//   ✓ 30-second timeout detection
//   ✓ Error states: network failure, style load fail, timeout
//   ✓ Retry button on error
//   ✓ Empty state when all layers are hidden
//   ✓ Feature click handling with bottom sheet
//   ✓ Fly-to selected feature animation

import React, { useEffect, useRef, useState, useCallback, useMemo } from 'react';
import {
  View,
  Platform,
  StyleSheet,
  Text,
  ActivityIndicator,
  Animated,
  TouchableOpacity,
  Easing,
  PanResponder,
  Vibration,
} from 'react-native';
import type { GeoJSONFeature } from '../utils/types';
import Constants from 'expo-constants';
import { Map as MapIcon, CircleAlert, RotateCw, Ruler, Package } from 'lucide-react-native';
import { useThemeStore } from '../stores/theme';

// ── Types ────────────────────────────────────────────────────────────────

export interface MapLayerData {
  id: string;
  name: string;
  features: (GeoJSONFeature & { properties: Record<string, unknown> & { id?: string } })[];
  visible: boolean;
  color: string;
  geometryType?: 'Point' | 'LineString' | 'Polygon';
}

export interface BasemapStyle {
  id: string;
  name: string;
  style: string | Record<string, unknown>;
}

type MapStatus = 'loading' | 'ready' | 'error' | 'timeout' | 'empty';

// ── Vertex snap index ────────────────────────────────────────────────────
// Flat list of line/ring segments from all rendered layers, used to snap a
// dragged vertex onto existing infrastructure (trenches, ducts, cables...).
// Built once per layers change and queried per move event with a cheap
// planar point-to-segment test — no per-feature allocation during drags.
interface SnapSegment {
  lng1: number;
  lat1: number;
  lng2: number;
  lat2: number;
  layerId: string;
  featureId: string;
}

function pushSegments(out: SnapSegment[], layerId: string, featureId: string, pts: [number, number][], closeRing: boolean) {
  if (pts.length < 2) {
    // Single point (Point feature) — degenerate segment so it still snaps.
    if (pts.length === 1) {
      const [lng, lat] = pts[0];
      out.push({ lng1: lng, lat1: lat, lng2: lng, lat2: lat, layerId, featureId });
    }
    return;
  }
  const n = closeRing ? pts.length : pts.length - 1;
  for (let i = 0; i < n; i++) {
    const [lng1, lat1] = pts[i];
    const [lng2, lat2] = pts[(i + 1) % pts.length];
    out.push({ lng1, lat1, lng2, lat2, layerId, featureId });
  }
}

function buildSnapSegments(layers: MapLayerData[]): SnapSegment[] {
  const out: SnapSegment[] = [];
  for (const layer of layers) {
    // The temp preview is the line currently being edited — never a snap target.
    if (layer.id.startsWith('temp-preview-')) continue;
    for (const feat of layer.features) {
      const fid = String((feat.properties as any)?.id ?? (feat.properties as any)?._id ?? '');
      const g = feat.geometry;
      if (!g) continue;
      if (g.type === 'LineString') {
        pushSegments(out, layer.id, fid, (g.coordinates as [number, number][]) ?? [], false);
      } else if (g.type === 'MultiLineString') {
        for (const line of (g.coordinates as [number, number][][]) ?? []) {
          pushSegments(out, layer.id, fid, line as [number, number][], false);
        }
      } else if (g.type === 'Polygon') {
        const rings = (g.coordinates as [number, number][][]) ?? [];
        if (rings[0]) pushSegments(out, layer.id, fid, rings[0] as [number, number][], true);
      } else if (g.type === 'MultiPolygon') {
        const firstPoly = (g.coordinates as [number, number][][][])?.[0];
        if (firstPoly?.[0]) pushSegments(out, layer.id, fid, firstPoly[0] as [number, number][], true);
      } else if (g.type === 'Point') {
        const c = g.coordinates as [number, number];
        if (c && typeof c[0] === 'number') {
          out.push({ lng1: c[0], lat1: c[1], lng2: c[0], lat2: c[1], layerId: layer.id, featureId: fid });
        }
      }
    }
  }
  return out;
}

/**
 * Nearest point on any snap segment within radiusM of (lng, lat), excluding
 * the feature being dragged, the survey twin of its layer, and any segment
 * that rides in the SAME corridor as the dragged feature (co-located
 * duct/cable/trench lines follow the original path — snapping to them would
 * pull the rerouted vertex right back onto the old route).
 */
function nearestSnapPoint(
  segs: SnapSegment[],
  lng: number,
  lat: number,
  radiusM: number,
  excludeLayerId: string,
  excludeFeatureId: string,
  excludeCorridor?: [number, number][],
): [number, number] | null {
  const cosLat = Math.cos((lat * Math.PI) / 180) || 1;
  const M_PER_LNG = 111320 * cosLat;
  const M_PER_LAT = 110540;
  const r2 = radiusM * radiusM;
  // Pre-tesselate the dragged feature's own path into short segments so
  // co-location can be tested cheaply (a duct/cable riding the same corridor
  // passes within ~1m of the dragged line's vertices).
  const corridorSegs: { x1: number; y1: number; x2: number; y2: number }[] = [];
  if (excludeCorridor && excludeCorridor.length >= 2) {
    const cLat = Math.cos((excludeCorridor[0][1] * Math.PI) / 180) || 1;
    const cM_PER_LNG = 111320 * cLat;
    const cM_PER_LAT = 110540;
    for (let i = 0; i < excludeCorridor.length - 1; i++) {
      const a = excludeCorridor[i];
      const b = excludeCorridor[i + 1];
      corridorSegs.push({
        x1: a[0] * cM_PER_LNG,
        y1: a[1] * cM_PER_LAT,
        x2: b[0] * cM_PER_LNG,
        y2: b[1] * cM_PER_LAT,
      });
    }
  }
  const CORRIDOR_M = 2.5; // a segment within this of the dragged path is "same corridor"
  const c2 = CORRIDOR_M * CORRIDOR_M;
  let bestD2 = r2;
  let bestLng = 0;
  let bestLat = 0;
  for (let i = 0; i < segs.length; i++) {
    const s = segs[i];
    // Skip the dragged feature itself and its survey twin (previous edit copy).
    if (s.layerId === `survey-${excludeLayerId}`) continue;
    if (s.layerId === excludeLayerId && s.featureId === excludeFeatureId) continue;
    // Skip segments co-located with the dragged feature's own path.
    if (corridorSegs.length > 0) {
      const mx = (s.lng1 * M_PER_LNG + s.lng2 * M_PER_LNG) / 2;
      const my = (s.lat1 * M_PER_LAT + s.lat2 * M_PER_LAT) / 2;
      let sameCorridor = false;
      for (let j = 0; j < corridorSegs.length; j++) {
        const c = corridorSegs[j];
        const px = mx - c.x1;
        const py = my - c.y1;
        const dx = c.x2 - c.x1;
        const dy = c.y2 - c.y1;
        const len2 = dx * dx + dy * dy;
        let t = len2 ? (px * dx + py * dy) / len2 : 0;
        if (t < 0) t = 0;
        else if (t > 1) t = 1;
        const qx = px - t * dx;
        const qy = py - t * dy;
        if (qx * qx + qy * qy <= c2) {
          sameCorridor = true;
          break;
        }
      }
      if (sameCorridor) continue;
    }
    const x1 = (s.lng1 - lng) * M_PER_LNG;
    const y1 = (s.lat1 - lat) * M_PER_LAT;
    const x2 = (s.lng2 - lng) * M_PER_LNG;
    const y2 = (s.lat2 - lat) * M_PER_LAT;
    const dx = x2 - x1;
    const dy = y2 - y1;
    const len2 = dx * dx + dy * dy;
    let t = len2 ? (-(x1 * dx) - (y1 * dy)) / len2 : 0;
    if (t < 0) t = 0;
    else if (t > 1) t = 1;
    const px = x1 + t * dx;
    const py = y1 + t * dy;
    const d2 = px * px + py * py;
    if (d2 < bestD2) {
      bestD2 = d2;
      bestLng = lng + px / M_PER_LNG;
      bestLat = lat + py / M_PER_LAT;
    }
  }
  return bestD2 < r2 ? [bestLng, bestLat] : null;
}

interface MapErrorInfo {
  type: 'network' | 'style' | 'module' | 'unknown' | 'timeout';
  message: string;
}

interface MapLibreMapProps {
  layers: MapLayerData[];
  /**
   * Replaces the default "No Layers Visible" copy when nothing on the map has
   * anything to draw. The caller knows *why* it is empty (a view mode that
   * hides some layers by design, say) and the map does not, so the wording is
   * the caller's. Omit it for the generic message.
   */
  emptyState?: { title: string; description: string };
  onFeatureClick?: (featureId: string, layerId: string, lngLat: [number, number], screenPoint?: { x: number; y: number }) => void;
  /**
   * Fired when a tap hits MORE THAN ONE feature (e.g. a premise point sitting
   * on a trench). Ordered point-first, then top-most; the first entry is the
   * feature onFeatureClick was called with, so the caller can offer a
   * "cycle overlapping features" chip without guessing the order.
   */
  onFeatureCandidates?: (
    candidates: { featureId: string; layerId: string; geometryType: string }[],
    lngLat: [number, number],
    screenPoint?: { x: number; y: number },
  ) => void;
  /** Called when clicking on empty map area (no feature found). Used for draw bypass mode. */
  onEmptyAreaClick?: (lng: number, lat: number, screenPoint?: { x: number; y: number }) => void;
  /** Called when a point feature is dragged to a new location. Only fires when dragMode is true. */
  onFeatureDragEnd?: (featureId: string, layerId: string, newLng: number, newLat: number) => void;
  /** Called when a vertex of a LineString or polygon corner is dragged to a new location. */
  onVertexDragEnd?: (featureId: string, layerId: string, vertexIdx: number, newLng: number, newLat: number) => void;
  /** Long-press on a vertex handle (Reroute) — remove that vertex from the working copy. */
  onVertexLongPress?: (featureId: string, layerId: string, vertexIdx: number) => void;
  /** Long-press on the line being edited (Reroute) — insert a bend at that point. */
  onSegmentLongPress?: (featureId: string, layerId: string, lng: number, lat: number) => void;
  /** When set, renders draggable vertex markers for the target feature's LineString vertices. */
  vertexDragTarget?: { featureId: string; layerId: string; vertexIdx: number } | null;
  /** When set, renders a highlighted polygon and draggable corner markers for the target polygon feature. */
  polygonEditTarget?: { featureId: string; layerId: string } | null;
  /** When set, the polygon body itself becomes draggable — a touch anywhere on the
   *  polygon translates the WHOLE feature (all ring vertices move together). The
   *  drag reports a cumulative [dLng, dLat] delta; the parent applies it to its
   *  own coordinate state exactly like vertex drags. Pass null to disable. */
  polygonMoveTarget?: { featureId: string; layerId: string } | null;
  /** Called continuously while a polygon body drag is active with the cumulative
   *  delta from the drag start, so the parent can live-preview the shift. */
  onPolygonMove?: (featureId: string, layerId: string, dLng: number, dLat: number) => void;
  /** Called when the user releases the polygon body drag with the final
   *  cumulative delta from the drag start. */
  onPolygonMoveEnd?: (featureId: string, layerId: string, dLng: number, dLat: number) => void;
  /** Called when a polygon corner handle is dragged to a new location. */
  onPolygonVertexDragEnd?: (featureId: string, layerId: string, vertexIdx: number, newLng: number, newLat: number) => void;
  /** GPS position of the device — renders a blue user-location dot when set. */
  userLocation?: { latitude: number; longitude: number } | null;
  /** Set of layer IDs whose point features can be dragged */
  draggableLayerIds?: Set<string>;
  /** Whether point dragging is enabled */
  dragMode?: boolean;
  selectedFeatureId?: string | null;
  height?: number | string;
  mapStyle?: string | Record<string, unknown>;
  /** Timeout in ms before showing timeout error (default 30s) */
  loadingTimeoutMs?: number;
  /** When this value changes, the map flies to the given center at given zoom */
  flyToCenter?: { lng: number; lat: number; zoom: number } | null;
  /** When ts changes, the map flies to the user's GPS location (crosshair FAB). */
  flyToUserTarget?: { lng: number; lat: number; zoom: number; ts: number } | null;
  /** When true, dragged vertices snap to nearby line/point features (existing
   *  trenches/ducts/cables) so a reroute aligns with the existing infrastructure. */
  snapEnabled?: boolean;
  /** Snap radius in meters (default 10). */
  snapRadiusM?: number;
}

// ── Basemap Presets ──────────────────────────────────────────────────────

// Inline raster StyleSpecification using OpenStreetMap tiles — the same
// reliable pattern as the satellite basemap. Avoids depending on a hosted
// vector style server (style JSON + glyphs + sprites) that can fail on
// mobile networks. OSM tiles are served up to z19; beyond that MapLibre
// scales the last tile, so no layer maxzoom is set.
const OSM_STREETS_STYLE: Record<string, unknown> = {
  version: 8,
  sources: {
    'osm-streets': {
      type: 'raster',
      tiles: ['https://tile.openstreetmap.org/{z}/{x}/{y}.png'],
      tileSize: 256,
      attribution: '© OpenStreetMap contributors',
      maxzoom: 19,
    },
  },
  layers: [
    { id: 'osm-streets-layer', type: 'raster', source: 'osm-streets', minzoom: 0 },
  ],
};

export const BASEMAPS: Record<string, BasemapStyle> = {
  streets: {
    id: 'streets',
    name: 'Streets',
    style: OSM_STREETS_STYLE,
  },
  satellite: {
    id: 'satellite',
    name: 'Satellite',
    style: {
      version: 8,
      sources: {
        'esri-satellite': {
          type: 'raster',
          tiles: [
            'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
          ],
          tileSize: 256,
          attribution: '© Esri',
        },
      },
      layers: [
        { id: 'esri-satellite-layer', type: 'raster', source: 'esri-satellite', minzoom: 0, maxzoom: 20 },
      ],
    },
  },
  light: {
    id: 'light',
    name: 'Light',
    style: 'https://demotiles.maplibre.org/style.json',
  },
};

const OAKWOOD_CENTER: [number, number] = [-0.1100, 51.5900];
/** Sensible project-region fallback: Berlin (the survey area of record). */
const DEFAULT_CENTER: [number, number] = [13.3775, 52.5162];
const DEFAULT_MAP_STYLE: string | Record<string, unknown> = OSM_STREETS_STYLE;
const LOADING_TIMEOUT_MS = 30000;

// ── Platform Detection ───────────────────────────────────────────────────
// IMPORTANT: The guard below prevents Metro/Webpack from bundling the
// native @maplibre/maplibre-react-native module for web, which would
// cause 'Cannot access X before initialization' TDZ errors in the
// combined bundle. On native (iOS/Android) we require it normally.

let NativeMapLibre: any = null;
const IS_NATIVE_PLATFORM = Platform.OS === 'ios' || Platform.OS === 'android';
if (IS_NATIVE_PLATFORM) {
  try {
    NativeMapLibre = require('@maplibre/maplibre-react-native');
  } catch {
    NativeMapLibre = null;
  }
}

const IS_NATIVE = IS_NATIVE_PLATFORM && NativeMapLibre !== null;

// ── Expo Go detection ────────────────────────────────────────────────────
// @maplibre/maplibre-react-native ships a native TurboModule
// (MLRNMapViewModule) that is NOT bundled inside Expo Go. When the module
// fails to load on a native platform, show the user actionable guidance
// instead of a generic error.
const IS_EXPO_GO = IS_NATIVE_PLATFORM
  ? (Constants as any).executionEnvironment === 'storeClient'
  : false;

// ── Shared UI Components ─────────────────────────────────────────────────

function LoadingOverlay({ message = 'Loading map...', progress }: { message?: string; progress?: number }) {
  const pulseAnim = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    const animation = Animated.loop(
      Animated.sequence([
        Animated.timing(pulseAnim, { toValue: 0.4, duration: 800, easing: Easing.inOut(Easing.ease), useNativeDriver: true }),
        Animated.timing(pulseAnim, { toValue: 1, duration: 800, easing: Easing.inOut(Easing.ease), useNativeDriver: true }),
      ])
    );
    animation.start();
    return () => animation.stop();
  }, []);

  // Dot animation for the 3-dot indicator
  const dot1 = useRef(new Animated.Value(0)).current;
  const dot2 = useRef(new Animated.Value(0)).current;
  const dot3 = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    const createDotAnim = (dot: Animated.Value, delay: number) =>
      Animated.loop(
        Animated.sequence([
          Animated.delay(delay),
          Animated.timing(dot, { toValue: 1, duration: 400, useNativeDriver: true }),
          Animated.timing(dot, { toValue: 0, duration: 400, useNativeDriver: true }),
        ])
      );
    const a1 = createDotAnim(dot1, 0);
    const a2 = createDotAnim(dot2, 200);
    const a3 = createDotAnim(dot3, 400);
    Animated.parallel([a1, a2, a3]).start();
    return () => { a1.stop(); a2.stop(); a3.stop(); };
  }, []);

  const dotOpacity = (dot: Animated.Value) =>
    dot.interpolate({ inputRange: [0, 1], outputRange: [0.3, 1] });

  const colors = useThemeStore((s) => s.colors);

  return (
    <View style={styles.overlay} accessibilityRole="progressbar" accessibilityLabel={message}>
      <View style={styles.loadingCard}>
        <Animated.View style={{ opacity: pulseAnim }}>
          <View style={styles.mapIconContainer}>
            <MapIcon size={30} stroke={colors.primary} />
          </View>
        </Animated.View>

        <View style={styles.loadingDots}>
          <Animated.View style={[styles.dot, { opacity: dotOpacity(dot1), backgroundColor: colors.primary }]} />
          <Animated.View style={[styles.dot, { opacity: dotOpacity(dot2), backgroundColor: colors.primary }]} />
          <Animated.View style={[styles.dot, { opacity: dotOpacity(dot3), backgroundColor: colors.primary }]} />
        </View>

        <Text style={styles.loadingTitle}>{message}</Text>

        {progress !== undefined && (
          <View style={styles.progressContainer}>
            <View style={styles.progressTrack}>
              <View style={[styles.progressFill, { width: `${Math.min(progress * 100, 95)}%` }]} />
            </View>
            <Text style={styles.progressText}>{Math.round(progress * 100)}%</Text>
          </View>
        )}

        <Text style={styles.loadingHint}>Initializing basemap & features</Text>
      </View>
    </View>
  );
}

function ErrorOverlay({
  error,
  onRetry,
}: {
  error: MapErrorInfo;
  onRetry?: () => void;
}) {
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const colors = useThemeStore((s) => s.colors);

  useEffect(() => {
    Animated.timing(fadeAnim, { toValue: 1, duration: 300, useNativeDriver: true }).start();
  }, []);

  const errorConfig = useMemo(() => {
    switch (error.type) {
      case 'network':
        return {
          title: 'Network Error',
          description: 'Could not connect to the map tile server. Check your internet connection and try again.',
        };
      case 'style':
        return {
          title: 'Style Load Failed',
          description: 'The map style could not be loaded. The style server may be temporarily unavailable.',
        };
      case 'module':
        return {
          title: 'Map Library Error',
          description: error.message || 'The map rendering library could not be initialized.',
        };
      case 'timeout':
        return {
          title: 'Loading Timeout',
          description: 'The map took too long to load. This may be due to a slow connection or server issue.',
        };
      default:
        return {
          title: 'Map Error',
          description: error.message || 'An unexpected error occurred while loading the map.',
        };
    }
  }, [error]);

  return (
    <Animated.View style={[styles.overlay, { opacity: fadeAnim }]}>
      <View style={styles.errorCard}>
        <View style={styles.errorIconCircle}>
          <CircleAlert size={30} stroke={colors.warning} />
        </View>

        <Text style={styles.errorTitle}>{errorConfig.title}</Text>
        <Text style={styles.errorDescription}>{errorConfig.description}</Text>

        {error.type === 'timeout' && (
          <View style={styles.tipContainer}>
            <Text style={styles.tipText}>Tip: try switching to a different basemap style</Text>
          </View>
        )}

        {onRetry && (
          <TouchableOpacity
            style={[styles.retryButton, { backgroundColor: colors.primary }]}
            onPress={onRetry}
            activeOpacity={0.7}
            accessibilityRole="button"
            accessibilityLabel="Retry loading the map"
          >
            <RotateCw size={16} stroke={colors.onPrimary} />
            <Text style={[styles.retryButtonText, { color: colors.onPrimary }]}>
              Retry loading
            </Text>
          </TouchableOpacity>
        )}
      </View>
    </Animated.View>
  );
}

const DEFAULT_EMPTY_STATE = {
  title: 'No Layers Visible',
  description: 'All layers are currently hidden or contain no features.\nToggle layers on using the layers panel.',
};

function EmptyOverlay({ emptyState }: { emptyState?: { title: string; description: string } }) {
  const { title, description } = emptyState ?? DEFAULT_EMPTY_STATE;
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const colors = useThemeStore((s) => s.colors);

  useEffect(() => {
    Animated.timing(fadeAnim, { toValue: 1, duration: 400, useNativeDriver: true }).start();
  }, []);

  return (
    <Animated.View style={[styles.overlay, { opacity: fadeAnim }]}>
      <View style={styles.emptyCard}>
        <View style={styles.emptyIconContainer}>
          <MapIcon size={24} stroke={colors.primary} />
          <View style={styles.emptyIconBadge}>
            <Text style={styles.emptyBadgeText}>0</Text>
          </View>
        </View>
        <Text style={styles.emptyTitle}>{title}</Text>
        <Text style={styles.emptyDescription}>{description}</Text>
      </View>
    </Animated.View>
  );
}

// ── Geometry Auto-Detect ─────────────────────────────────────────────────

function detectGeometryType(
  features: MapLayerData['features']
): 'Point' | 'LineString' | 'Polygon' {
  for (const f of features) {
    if (f.geometry?.type === 'LineString') return 'LineString';
    if (f.geometry?.type === 'Polygon' || f.geometry?.type === 'MultiPolygon') return 'Polygon';
  }
  return 'Point';
}

function hasVisibleFeatures(layers: MapLayerData[]): boolean {
  return layers.some((l) => l.visible && l.features.length > 0);
}

// ── Mobile (Native) Implementation ────────────────────────────────────────

function NativeMapView({
  layers,
  onFeatureClick,
  onFeatureCandidates,
  onFeatureDragEnd,
  onEmptyAreaClick,
  onVertexDragEnd,
  vertexDragTarget,
  polygonEditTarget,
  polygonMoveTarget,
  onPolygonMove,
  onPolygonMoveEnd,
  onPolygonVertexDragEnd,
  userLocation,
  draggableLayerIds,
  dragMode,
  selectedFeatureId,
  height,
  mapStyle: mapStyleProp,
  loadingTimeoutMs = LOADING_TIMEOUT_MS,
  flyToCenter,
  flyToUserTarget,
  snapEnabled,
  snapRadiusM,
  emptyState,
}: MapLibreMapProps) {
  const cameraRef = useRef<any>(null);
  const mapRef = useRef<any>(null);
  const [status, setStatus] = useState<MapStatus>('loading');
  const [errorInfo, setErrorInfo] = useState<MapErrorInfo>({ type: 'unknown', message: '' });
  const [loadProgress, setLoadProgress] = useState<number | undefined>(undefined);
  const [mapKey, setMapKey] = useState(0);
  const retryCountRef = useRef(0);
  const colors = useThemeStore((s) => s.colors);

  // ── Point Drag State ─────────────────────────────────────────────────
  const [isDragging, setIsDragging] = useState(false);
  const [dragCoords, setDragCoords] = useState<[number, number] | null>(null);
  const [dragDistance, setDragDistance] = useState<number | null>(null);
  const [layerShapes, setLayerShapes] = useState<Record<string, any>>({});
  const dragRef = useRef<{
    featureId: string;
    layerId: string;
    featureIndex: number;
    startLng: number;
    startLat: number;
    startScreenX: number;
    startScreenY: number;
    currentZoom: number;
    baselineCaptured: boolean;
  } | null>(null);
  const zoomRef = useRef(15);
  const centerRef = useRef<[number, number]>([13.3775, 52.5162]); // Berlin default
  const onDragEndRef = useRef(onFeatureDragEnd);
  onDragEndRef.current = onFeatureDragEnd;
  const polygonMoveTargetRef = useRef(polygonMoveTarget);
  polygonMoveTargetRef.current = polygonMoveTarget;
  const onPolygonMoveRef = useRef(onPolygonMove);
  onPolygonMoveRef.current = onPolygonMove;
  const onPolygonMoveEndRef = useRef(onPolygonMoveEnd);
  onPolygonMoveEndRef.current = onPolygonMoveEnd;
  const editHandleRef = useRef<{ coords: [number, number][]; isPolygon: boolean; featureId: string; layerId: string } | null>(null);
  const onVertexDragEndRef = useRef(onVertexDragEnd);
  onVertexDragEndRef.current = onVertexDragEnd;
  const onPolygonVertexDragEndRef = useRef(onPolygonVertexDragEnd);
  onPolygonVertexDragEndRef.current = onPolygonVertexDragEnd;

  // ── Haversine distance (metres) ────────────────────────────────────────
  const haversineDistance = useCallback((lng1: number, lat1: number, lng2: number, lat2: number): number => {
    const R = 6371000;
    const toRad = (d: number) => (d * Math.PI) / 180;
    const dLng = toRad(lng2 - lng1);
    const dLat = toRad(lat2 - lat1);
    const a =
      Math.sin(dLat / 2) ** 2 +
      Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLng / 2) ** 2;
    return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  }, []);

  const MapLibreGL = NativeMapLibre;

  // ── Loading timeout ─────────────────────────────────────────────────────
  useEffect(() => {
    if (status === 'ready' || status === 'error') return;
    const timer = setTimeout(() => {
      if (status === 'loading') {
        setErrorInfo({ type: 'timeout', message: 'Map did not load within the expected time.' });
        setStatus('timeout');
      }
    }, loadingTimeoutMs);
    return () => clearTimeout(timer);
  }, [status, loadingTimeoutMs]);

  // ── Module init ─────────────────────────────────────────────────────────
  useEffect(() => {
    if (!MapLibreGL) {
      setErrorInfo({ type: 'module', message: '@maplibre/maplibre-react-native is not available.' });
      setStatus('error');
    }
  }, []);

  // ── Sync layers → layerShapes (skip during active drag to avoid flicker) ─
  // OPTIMIZATION (memory): layers whose feature array is reference-identical
  // to the previous render are SKIPPED — editing one line/polygon no longer
  // rebuilds the GeoJSON sources for the other ~2,400 map features. Keeping
  // the same shape object reference also lets the native GeoJSONSource skip
  // re-processing. This was the memory-churn spike that made the phone's OS
  // freeze the app under low-memory pressure right after an edit.
  const prevLayersRef = useRef<MapLayerData[]>([]);
  useEffect(() => {
    if (isDragging) return;
    const prevLayers = prevLayersRef.current;
    setLayerShapes((prevShapes) => {
      const next: Record<string, any> = { ...prevShapes };
      for (const layerData of layers) {
        if (!layerData.visible || layerData.features.length === 0) {
          delete next[layerData.id];
          continue;
        }
        // Fast path — keep unchanged layers untouched. NOTE: map.tsx's
        // buildMapLayerData wraps every feature in a new object on each
        // recompute, so feature-object identity is useless — but the spread
        // ({...f}) PRESERVES the geometry reference. Unchanged layers keep
        // the same geometry refs (and the edited preview/survey layer gets
        // fresh geometry), which is the correct change signal.
        const prevLayer = prevLayers.find((p) => p.id === layerData.id);
        const unchanged =
          prevLayer !== undefined &&
          prevLayer.color === layerData.color &&
          prevLayer.features.length === layerData.features.length &&
          prevLayer.features.every(
            (f, i) => (f as any).geometry === (layerData.features[i] as any).geometry
          );
        if (unchanged && next[layerData.id]) continue;

        const features = layerData.features.map((f, i) => ({
          ...f,
          properties: {
            ...(f.properties ?? {}),
            _id: f.properties?.id ?? `${layerData.id}-${i}`,
            _layer_id: layerData.id,
          },
        }));
        next[layerData.id] = { type: 'FeatureCollection' as const, features };
      }
      return next;
    });
    prevLayersRef.current = layers;
  }, [layers, isDragging]);

  // ── Screen-to-LngLat conversion (linear approximation — synchronous) ────
  const screenToLngLat = useCallback((screenX: number, screenY: number): [number, number] => {
    const ds = dragRef.current;
    if (!ds || !ds.baselineCaptured) {
      return [ds?.startLng ?? 0, ds?.startLat ?? 0];
    }
    const dx = screenX - ds.startScreenX;
    const dy = screenY - ds.startScreenY;
    const scale = 256 * Math.pow(2, ds.currentZoom);
    const cosLat = Math.cos((ds.startLat * Math.PI) / 180);
    const lngPerPixel = 360 / (scale * cosLat);
    const latPerPixel = 180 / scale;
    return [ds.startLng + dx * lngPerPixel, ds.startLat - dy * latPerPixel];
  }, []);

  // ── PanResponder for drag overlay (active only during drag) ─────────────
  const dragCoordsRef = useRef<[number, number] | null>(null);

  const panResponder = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () => true,
      onMoveShouldSetPanResponder: () => true,
      onPanResponderGrant: (evt) => {
        // Capture the baseline at TOUCH-DOWN, not on the first move event.
        // The first move event only fires after React Native's touch slop
        // (~10px) is exceeded, so capturing it there left a dead zone where
        // the dragged point lagged behind the finger — it felt rigid.
        const ds = dragRef.current;
        if (!ds) return;
        ds.startScreenX = evt.nativeEvent.pageX;
        ds.startScreenY = evt.nativeEvent.pageY;
        ds.baselineCaptured = true;
      },
      onPanResponderMove: (evt) => {
        const ds = dragRef.current;
        if (!ds) return;

        // Fallback: if no grant was received (e.g. overlay mounted mid-
        // gesture), establish the baseline on the first move instead.
        if (!ds.baselineCaptured) {
          ds.startScreenX = evt.nativeEvent.pageX;
          ds.startScreenY = evt.nativeEvent.pageY;
          ds.baselineCaptured = true;
          return; // skip first frame — establish baseline only
        }

        const coords = screenToLngLat(evt.nativeEvent.pageX, evt.nativeEvent.pageY);
        dragCoordsRef.current = coords;
        setDragCoords(coords);

        // Update the point in the GeoJSONSource data so it moves on the map
        setLayerShapes((prev) => {
          const current = prev[ds.layerId];
          if (!current?.features) return prev;
          const features = [...current.features];
          if (features[ds.featureIndex]?.geometry?.type === 'Point') {
            features[ds.featureIndex] = {
              ...features[ds.featureIndex],
              geometry: { ...features[ds.featureIndex].geometry, coordinates: coords },
            };
          }
          return { ...prev, [ds.layerId]: { ...current, features } };
        });

        // Update drag distance during move (ds already declared above)
        if (ds) {
          const dist = haversineDistance(ds.startLng, ds.startLat, coords[0], coords[1]);
          setDragDistance(Math.round(dist));
        }
      },
      onPanResponderRelease: () => {
        const ds = dragRef.current;
        const coords = dragCoordsRef.current;
        if (ds && onDragEndRef.current && coords) {
          const pixelDx = Math.abs(coords[0] - ds.startLng);
          const pixelDy = Math.abs(coords[1] - ds.startLat);
          // Only fire if moved more than a tiny threshold (~5m at equator ≈ 0.000045°)
          if (pixelDx > 0.00005 || pixelDy > 0.00005) {
            onDragEndRef.current(ds.featureId, ds.layerId, coords[0], coords[1]);
          }
        }
        setIsDragging(false);
        setDragCoords(null);
        setDragDistance(null);
        dragCoordsRef.current = null;
        dragRef.current = null;
      },
      onPanResponderTerminate: () => {
        setIsDragging(false);
        setDragCoords(null);
        setDragDistance(null);
        dragCoordsRef.current = null;
        dragRef.current = null;
      },
    })
  ).current;

  const styleUrl = useMemo(() => {
    if (!mapStyleProp) return DEFAULT_MAP_STYLE;
    // v11's Map.mapStyle accepts both a style URL string and an inline
    // StyleSpecification object (e.g. the satellite raster style). Passing
    // the object through lets satellite imagery work on Android instead of
    // silently falling back to the default streets style.
    return mapStyleProp as string | Record<string, unknown>;
  }, [mapStyleProp]);

  // ── Feature click handler ──────────────────────────────────────────────
  // Fires onFeatureClick for features, onEmptyAreaClick for empty map taps.
  // The MapLibreGL.Map onPress fires with the tapped features array;
  // if no custom feature is at the tap point, fall back to empty-area.
  const handlePress = useCallback(
    (e: any) => {
      // In drag mode, don't fire click events — drag overlay handles interaction
      if (dragMode) return;
      // v11 wraps press payloads in NativeSyntheticEvent — support both shapes
      const allFeatures: any[] = e?.nativeEvent?.features ?? e?.features ?? [];
      // Belt-and-suspenders: never treat the GPS user-location dot as a
      // feature OR as an empty-area tap (draw modes must not place a stray
      // point at the surveyor's own position).
      const dotHit = allFeatures.some((f: any) => f?.properties?._is_user_location);
      const features = allFeatures.filter((f: any) => !f?.properties?._is_user_location);
      if (dotHit && features.length === 0) return;
      // Attempt to extract lngLat from the event (v11 exposes it on nativeEvent)
      const rawCoords = e?.nativeEvent?.coordinates ?? e?.nativeEvent?.lngLat;
      const lngLat: [number, number] | undefined =
        rawCoords && typeof rawCoords[0] === 'number' && typeof rawCoords[1] === 'number'
          ? [rawCoords[0] as number, rawCoords[1] as number]
          : undefined;

      if (!features || features.length === 0) {
        // No feature under tap — fire empty-area click for draw / add-point modes
        if (onEmptyAreaClick && lngLat) {
          onEmptyAreaClick(lngLat[0], lngLat[1], undefined);
        }
        return;
      }

      // A point is a far smaller target than the trench it sits on, so a point
      // hit always wins over a line/polygon — otherwise object points on
      // trenches could never be tapped, edited or attribute-filled. The full
      // stack (>1) is reported so the popup can offer a cycle chip.
      const feature = pickTappedFeature(features);
      if (!feature) {
        if (onEmptyAreaClick && lngLat) {
          onEmptyAreaClick(lngLat[0], lngLat[1], undefined);
        }
        return;
      }
      if (onFeatureCandidates) {
        const stack = tapCandidates(features);
        if (stack.length > 1 && lngLat) onFeatureCandidates(stack, lngLat, undefined);
      }
      const props = feature.properties || {};
      const fid = props.id || props._id;
      const lid = props._layer_id;
      // Vertex marker tap: start a vertex drag ONLY when the current tool mode
      // wires a drag callback for this geometry type (line vs polygon).
      // In delete-section / continue-line modes the callback is disabled so the
      // tap falls through to onFeatureClick for vertex-based selection.
      let vertexDragHandled = false;
      if (props._is_vertex && lngLat) {
        const parentFeatureId = props._parent_feature_id as string | undefined;
        const vertexIdx = props._vertex_idx as number | undefined;
        const parentLayerId = props._layer_id as string | undefined;
        if (parentFeatureId && parentLayerId && typeof vertexIdx === 'number') {
          // Find parent feature coords to set drag baseline
          for (const layerData of layers) {
            const previewLayerId = `temp-preview-${parentLayerId}`;
            if (layerData.id !== parentLayerId && layerData.id !== previewLayerId) continue;
            for (const feat of layerData.features) {
              const pfid = (feat.properties as any)?.id ?? (feat.properties as any)?._id ?? '';
              if (pfid !== parentFeatureId) continue;
              const geom = feat.geometry;
              let vCoords: [number, number][] = [];
              let vIsPolygon = false;
              if (geom?.type === 'LineString') vCoords = (geom.coordinates as [number, number][]) ?? [];
              else if (geom?.type === 'MultiLineString') vCoords = ((geom.coordinates as [number, number][][])[0] ?? []) as [number, number][];
              else if (geom?.type === 'Polygon') { vCoords = ((geom.coordinates as [number, number][][])[0] ?? []) as [number, number][]; vIsPolygon = true; }
              else if (geom?.type === 'MultiPolygon') { vCoords = ((geom.coordinates as [number, number][][][])[0]?.[0] ?? []) as [number, number][]; vIsPolygon = true; }
              if (vertexIdx >= 0 && vertexIdx < vCoords.length) {
                // Only start a drag if the matching callback is wired for this
                // geometry type. Otherwise fall through to onFeatureClick so the
                // delete-section / continue-line handlers can use the vertex tap.
                const dragCb = vIsPolygon ? onPolygonVertexDragEnd : onVertexDragEnd;
                if (!dragCb) break;
                vertexDragHandled = true;
                vertexDragRef.current = {
                  featureId: parentFeatureId,
                  layerId: parentLayerId,
                  vertexIdx,
                  startLng: vCoords[vertexIdx][0],
                  startLat: vCoords[vertexIdx][1],
                  startScreenX: 0,
                  startScreenY: 0,
                  baselineCaptured: false,
                  isPolygon: vIsPolygon,
                  coords: [...vCoords],
                };
                vertexDragCoordsRef.current = lngLat;
                setIsVertexDragging(true);
                setVertexDragDistance(null);
                console.log(`[Vertex] Tap started drag of vertex ${vertexIdx}`);
                return;
              }
            }
          }
        }
        if (vertexDragHandled) return;
        // Fall through → onFeatureClick with the vertex feature so tool-mode
        // handlers (delete-section, continue-line) can select the vertex.
      }
      const geometry = feature.geometry;
      if (fid && lid && geometry && onFeatureClick) {
        const coords = geometry.coordinates;
        const geomPoint: [number, number] =
          geometry.type === 'Point'
            ? [coords[0], coords[1]]
            : [coords[0]?.[0] ?? 0, coords[0]?.[1] ?? 0];
        // CRITICAL: pass the ACTUAL tap coordinate (lngLat from the press
        // event) instead of the geometry's first vertex. For line/polygon
        // features the first vertex is NOT where the user tapped — snapping
        // tools (delete-section, draw-segment) need the real tap location
        // to find the nearest vertex.
        onFeatureClick(fid, lid, lngLat ?? geomPoint, undefined);
      }
    },
    [onFeatureClick, onEmptyAreaClick, onFeatureCandidates, dragMode]
  );

  // ── Vertex Drag State ──────────────────────────────────────────────────
  const [isVertexDragging, setIsVertexDragging] = useState(false);
  const [vertexDragDistance, setVertexDragDistance] = useState<number | null>(null);
  const [cameraVersion, setCameraVersion] = useState(0);
  const vertexDragRef = useRef<{
    featureId: string;
    layerId: string;
    vertexIdx: number;
    startLng: number;
    startLat: number;
    startScreenX: number;
    startScreenY: number;
    baselineCaptured: boolean;
    isPolygon: boolean;
    coords: [number, number][];
  } | null>(null);
  const vertexDragCoordsRef = useRef<[number, number] | null>(null);

  // ── Vertex snap state ──────────────────────────────────────────────────
  const [snapActive, setSnapActive] = useState(false);
  const [snapPos, setSnapPos] = useState<{ lng: number; lat: number } | null>(null);
  const snapEnabledRef = useRef(!!snapEnabled);
  const snapRadiusMRef = useRef(snapRadiusM ?? 10);
  const snapSegmentsRef = useRef<SnapSegment[]>([]);
  const snapActiveRef = useRef(false);

  useEffect(() => {
    snapEnabledRef.current = !!snapEnabled;
  }, [snapEnabled]);

  useEffect(() => {
    snapRadiusMRef.current = snapRadiusM ?? 10;
  }, [snapRadiusM]);

  useEffect(() => {
    snapSegmentsRef.current = buildSnapSegments(layers);
  }, [layers]);

  const clearSnap = useCallback(() => {
    snapActiveRef.current = false;
    setSnapActive(false);
    setSnapPos(null);
  }, []);

  // ── Vertex press handler — starts vertex drag when a handle is tapped ──
  const handleVertexPress = useCallback((e: any) => {
    if (!onVertexDragEnd && !onPolygonVertexDragEnd) return;
    const features = e?.nativeEvent?.features ?? e?.features ?? [];
    if (!features || features.length === 0) return;
    const feature = features[0];
    const props = feature?.properties;
    if (!props?._is_vertex) return;
    const vertexIdx = props._vertex_idx as number;
    const parentFeatureId = props._parent_feature_id as string;
    const parentLayerId = props._layer_id as string;
    if (vertexIdx === undefined || !parentFeatureId || !parentLayerId) return;

    // Find the parent feature in layers to get current coords
    let parentCoords: [number, number][] = [];
    let parentIsPolygon = false;
    for (const layerData of layers) {
      if (layerData.id !== parentLayerId) continue;
      for (const feat of layerData.features) {
        const fid = (feat.properties as any)?.id ?? (feat.properties as any)?._id ?? '';
        if (fid !== parentFeatureId) continue;
        const geom = feat.geometry;
        if (geom?.type === 'LineString') {
          parentCoords = (geom.coordinates as [number, number][]) ?? [];
        } else if (geom?.type === 'MultiLineString') {
          parentCoords = ((geom.coordinates as [number, number][][])[0] ?? []) as [number, number][];
        } else if (geom?.type === 'Polygon') {
          parentCoords = ((geom.coordinates as [number, number][][])[0] ?? []) as [number, number][];
          parentIsPolygon = true;
        } else if (geom?.type === 'MultiPolygon') {
          parentCoords = ((geom.coordinates as [number, number][][][])[0]?.[0] ?? []) as [number, number][];
          parentIsPolygon = true;
        }
        break;
      }
      break;
    }
    if (parentCoords.length === 0 || vertexIdx >= parentCoords.length) return;
    const [lng, lat] = parentCoords[vertexIdx];

    vertexDragRef.current = {
      featureId: parentFeatureId,
      layerId: parentLayerId,
      vertexIdx,
      startLng: lng,
      startLat: lat,
      startScreenX: 0,
      startScreenY: 0,
      baselineCaptured: false,
      isPolygon: parentIsPolygon,
      coords: [...parentCoords],
    };
    vertexDragCoordsRef.current = [lng, lat];
    clearSnap();
    setIsVertexDragging(true);
    setVertexDragDistance(null);
  }, [onVertexDragEnd, onPolygonVertexDragEnd, clearSnap]);

  // ── Vertex screen positions (pre-projected for touch-down arming) ──
  // Ref so the PanResponder (created once) always sees fresh positions.
  const vertexScreenRef = useRef<Array<{ x: number; y: number; coords: [number, number]; idx: number }> | null>(null);
  const vertexScreenVersionRef = useRef(0);

  // ── Vertex PanResponder — captures vertex drags at TOUCH-DOWN ─────────
  const vertexPanResponder = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: (evt) => {
        if (!onVertexDragEndRef.current && !onPolygonVertexDragEndRef.current) return false;
        const positions = vertexScreenRef.current;
        if (!positions || positions.length === 0) return false;
        const px = evt.nativeEvent.locationX ?? evt.nativeEvent.pageX;
        const py = evt.nativeEvent.locationY ?? evt.nativeEvent.pageY;
        const hitRadius = 40;
        let best: { idx: number; dist: number } | null = null;
        for (let i = 0; i < positions.length; i++) {
          const p = positions[i];
          const dx = p.x - px;
          const dy = p.y - py;
          const dist = Math.sqrt(dx * dx + dy * dy);
          if (dist <= hitRadius && (best === null || dist < best.dist)) {
            best = { idx: i, dist };
          }
        }
        if (best === null) return false;
        const targetPos = positions[best.idx];
        const eh = editHandleRef.current;
        if (!eh) return false;
        vertexDragRef.current = {
          featureId: eh.featureId,
          layerId: eh.layerId,
          vertexIdx: targetPos.idx,
          startLng: targetPos.coords[0],
          startLat: targetPos.coords[1],
          startScreenX: 0,
          startScreenY: 0,
          baselineCaptured: false,
          isPolygon: eh.isPolygon,
          coords: [...eh.coords],
        };
        vertexDragCoordsRef.current = [targetPos.coords[0], targetPos.coords[1]];
        clearSnap();
        setIsVertexDragging(true);
        setVertexDragDistance(null);
        return true;
      },
      onMoveShouldSetPanResponder: () => {
        return vertexDragRef.current !== null;
      },
      onPanResponderGrant: (evt) => {
        // Capture the baseline at TOUCH-DOWN so the vertex follows the finger
        // from the very first pixel (see point-drag responder for details).
        const ds = vertexDragRef.current;
        if (!ds) return;
        ds.startScreenX = evt.nativeEvent.pageX;
        ds.startScreenY = evt.nativeEvent.pageY;
        ds.baselineCaptured = true;
      },
      onPanResponderMove: (evt) => {
        const ds = vertexDragRef.current;
        if (!ds) return;

        // Fallback baseline capture if no grant was received.
        if (!ds.baselineCaptured) {
          ds.startScreenX = evt.nativeEvent.pageX;
          ds.startScreenY = evt.nativeEvent.pageY;
          ds.baselineCaptured = true;
          return;
        }

        // Convert screen delta to lngLat delta
        const dx = evt.nativeEvent.pageX - ds.startScreenX;
        const dy = evt.nativeEvent.pageY - ds.startScreenY;
        const scale = 256 * Math.pow(2, zoomRef.current);
        const cosLat = Math.cos((ds.startLat * Math.PI) / 180);
        const lngPerPixel = 360 / (scale * cosLat);
        const latPerPixel = 180 / scale;
        let newLng = ds.startLng + dx * lngPerPixel;
        let newLat = ds.startLat - dy * latPerPixel;

        // ── Snap to existing infrastructure (reroute tool) ──
        // While the vertex is near a trench/duct/cable/point feature within
        // the snap radius, lock onto the nearest point on its geometry so the
        // rerouted line follows the existing network. Haptic fires once when
        // the snap engages and once when it releases.
        //
        // Hysteresis: once locked, the snap only releases when the finger
        // moves beyond 1.8× the radius, so the vertex doesn't flicker on/off
        // at the radius boundary while following the finger (which made the
        // tool feel rigid).
        if (snapEnabledRef.current) {
          const wasSnapped = snapActiveRef.current;
          const snapRadius = wasSnapped
            ? snapRadiusMRef.current * 1.8
            : snapRadiusMRef.current;
          const snapped = nearestSnapPoint(
            snapSegmentsRef.current,
            newLng,
            newLat,
            snapRadius,
            ds.layerId,
            ds.featureId,
            ds.coords,
          );
          if (snapped) {
            newLng = snapped[0];
            newLat = snapped[1];
            if (!snapActiveRef.current) {
              snapActiveRef.current = true;
              setSnapActive(true);
              Vibration.vibrate(12);
            }
            setSnapPos({ lng: newLng, lat: newLat });
          } else if (snapActiveRef.current) {
            snapActiveRef.current = false;
            setSnapActive(false);
            setSnapPos(null);
            Vibration.vibrate(8);
          }
        }

        vertexDragCoordsRef.current = [newLng, newLat];

        // Update the vertex position in the layer data (visual feedback)
        setLayerShapes((prev) => {
          const current = prev[ds.layerId];
          if (!current?.features) return prev;
          const features = [...current.features];
          // Find the parent feature by ID
          for (let i = 0; i < features.length; i++) {
            const f = features[i];
            const fid = f.properties?._id ?? f.properties?.id ?? '';
            if (fid === ds.featureId) {
              const updated = { ...f };
              if (ds.isPolygon && updated.geometry?.type === 'Polygon') {
                const rings = [...updated.geometry.coordinates] as [number, number][][];
                const outer = [...rings[0]] as [number, number][];
                if (ds.vertexIdx < outer.length) {
                  outer[ds.vertexIdx] = [newLng, newLat];
                  if (ds.vertexIdx === 0 && outer.length > 1) outer[outer.length - 1] = [newLng, newLat];
                  else if (ds.vertexIdx === outer.length - 1 && outer.length > 1) outer[0] = [newLng, newLat];
                  updated.geometry = { ...updated.geometry, coordinates: [outer, ...rings.slice(1)] };
                }
              } else if (updated.geometry?.type === 'LineString') {
                const lineCoords = [...updated.geometry.coordinates] as [number, number][];
                if (ds.vertexIdx < lineCoords.length) {
                  lineCoords[ds.vertexIdx] = [newLng, newLat];
                  updated.geometry = { ...updated.geometry, coordinates: lineCoords };
                }
              } else if (updated.geometry?.type === 'MultiLineString') {
                const multiCoords = [...updated.geometry.coordinates] as [number, number][][];
                const firstLine = [...(multiCoords[0] ?? [])] as [number, number][];
                if (ds.vertexIdx < firstLine.length) {
                  firstLine[ds.vertexIdx] = [newLng, newLat];
                  multiCoords[0] = firstLine;
                  updated.geometry = { ...updated.geometry, coordinates: multiCoords };
                }
              } else if (updated.geometry?.type === 'MultiPolygon') {
                const polys = [...updated.geometry.coordinates] as [number, number][][][];
                const firstPoly = polys[0];
                if (firstPoly && Array.isArray(firstPoly) && firstPoly.length > 0 && Array.isArray(firstPoly[0])) {
                  const outerRing = [...firstPoly[0]] as [number, number][];
                  if (ds.vertexIdx >= 0 && ds.vertexIdx < outerRing.length) {
                    outerRing[ds.vertexIdx] = [newLng, newLat];
                    // GeoJSON linear rings must remain closed when an endpoint is moved.
                    if (ds.vertexIdx === 0 && outerRing.length > 1) outerRing[outerRing.length - 1] = [newLng, newLat];
                    else if (ds.vertexIdx === outerRing.length - 1 && outerRing.length > 1) outerRing[0] = [newLng, newLat];
                    const updatedPoly = [...firstPoly];
                    updatedPoly[0] = outerRing;
                    polys[0] = updatedPoly;
                    updated.geometry = { ...updated.geometry, coordinates: polys };
                  }
                }
              }
              features[i] = updated;
              break;
            }
          }
          return { ...prev, [ds.layerId]: { ...current, features } };
        });

        const dist = haversineDistance(ds.startLng, ds.startLat, newLng, newLat);
        setVertexDragDistance(Math.round(dist));
      },
      onPanResponderRelease: () => {
        const ds = vertexDragRef.current;
        const coords = vertexDragCoordsRef.current;
        if (ds && coords) {
          // Threshold in degrees ≈ 0.5 m at this latitude — small but real
          // vertex moves must be persisted. (0.00005° ≈ 5 m discarded genuine
          // reroute tweaks, which is why reroutes looked "not saved".)
          const pixDx = Math.abs(coords[0] - ds.startLng);
          const pixDy = Math.abs(coords[1] - ds.startLat);
          if (pixDx > 0.0000045 || pixDy > 0.0000045) {
            const cbd = ds.isPolygon ? onPolygonVertexDragEndRef.current : onVertexDragEndRef.current;
            if (cbd) {
              cbd(ds.featureId, ds.layerId, ds.vertexIdx, coords[0], coords[1]);
            }
          }
        }
        clearSnap();
        setIsVertexDragging(false);
        setVertexDragDistance(null);
        vertexDragCoordsRef.current = null;
        vertexDragRef.current = null;
      },
      onPanResponderTerminate: () => {
        const ds = vertexDragRef.current;
        const coords = vertexDragCoordsRef.current;
        if (ds && coords) {
          const pixDx = Math.abs(coords[0] - ds.startLng);
          const pixDy = Math.abs(coords[1] - ds.startLat);
          if (pixDx > 0.0000045 || pixDy > 0.0000045) {
            const cbd = ds.isPolygon ? onPolygonVertexDragEndRef.current : onVertexDragEndRef.current;
            if (cbd) {
              cbd(ds.featureId, ds.layerId, ds.vertexIdx, coords[0], coords[1]);
            }
          }
        }
        clearSnap();
        setIsVertexDragging(false);
        setVertexDragDistance(null);
        vertexDragCoordsRef.current = null;
        vertexDragRef.current = null;
      },
    })
  ).current;

  // ── Whole-polygon Move state + PanResponder ─────────────────────────────
  // Unlike vertex drag (which moves ONE corner), the polygon Move tool drags
  // the polygon BODY: a touch anywhere inside the projected ring translates
  // the WHOLE feature, reporting a cumulative [dLng, dLat] delta to the
  // parent who applies it to its polygonEditCoords state.
  const [isPolygonMoving, setIsPolygonMoving] = useState(false);
  const polygonMoveRef = useRef<{
    featureId: string;
    layerId: string;
    startLng: number;
    startLat: number;
    startScreenX: number;
    startScreenY: number;
    cumLng: number;
    cumLat: number;
    active: boolean;
  } | null>(null);

  /** Ray-cast point-in-polygon test on projected screen points. */
  const pointInRing = useCallback((px: number, py: number, ring: Array<{ x: number; y: number }>): boolean => {
    let inside = false;
    for (let i = 0, j = ring.length - 1; i < ring.length; j = i++) {
      const xi = ring[i].x, yi = ring[i].y;
      const xj = ring[j].x, yj = ring[j].y;
      const intersect = ((yi > py) !== (yj > py)) &&
        (px < ((xj - xi) * (py - yi)) / ((yj - yi) || 1e-9) + xi);
      if (intersect) inside = !inside;
    }
    return inside;
  }, []);

  const polygonMovePanResponder = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: (evt) => {
        if (!onPolygonMoveRef.current && !onPolygonMoveEndRef.current) return false;
        const target = polygonMoveTargetRef.current;
        if (!target) return false;
        const positions = vertexScreenRef.current;
        if (!positions || positions.length < 3) return false;
        const px = evt.nativeEvent.locationX ?? evt.nativeEvent.pageX;
        const py = evt.nativeEvent.locationY ?? evt.nativeEvent.pageY;
        // Touch must land INSIDE the projected ring (the polygon body),
        // not merely near it — the body is what Move translates.
        if (!pointInRing(px, py, positions)) return false;
        polygonMoveRef.current = {
          featureId: target.featureId,
          layerId: target.layerId,
          startLng: positions[0].coords[0],
          startLat: positions[0].coords[1],
          startScreenX: 0,
          startScreenY: 0,
          cumLng: 0,
          cumLat: 0,
          active: true,
        };
        setIsPolygonMoving(true);
        return true;
      },
      onMoveShouldSetPanResponder: () => polygonMoveRef.current?.active === true,
      onPanResponderGrant: (evt) => {
        const ds = polygonMoveRef.current;
        if (!ds) return;
        ds.startScreenX = evt.nativeEvent.pageX;
        ds.startScreenY = evt.nativeEvent.pageY;
      },
      onPanResponderMove: (evt) => {
        const ds = polygonMoveRef.current;
        if (!ds || !ds.active) return;
        if (!ds.startScreenX) {
          ds.startScreenX = evt.nativeEvent.pageX;
          ds.startScreenY = evt.nativeEvent.pageY;
          return;
        }
        const dx = evt.nativeEvent.pageX - ds.startScreenX;
        const dy = evt.nativeEvent.pageY - ds.startScreenY;
        const scale = 256 * Math.pow(2, zoomRef.current);
        const cosLat = Math.cos((ds.startLat * Math.PI) / 180);
        const lngPerPixel = 360 / (scale * cosLat);
        const latPerPixel = 180 / scale;
        ds.cumLng = dx * lngPerPixel;
        ds.cumLat = -dy * latPerPixel;
        if (onPolygonMoveRef.current) {
          onPolygonMoveRef.current(ds.featureId, ds.layerId, ds.cumLng, ds.cumLat);
        }
      },
      onPanResponderRelease: () => {
        const ds = polygonMoveRef.current;
        if (ds && ds.active && onPolygonMoveEndRef.current) {
          onPolygonMoveEndRef.current(ds.featureId, ds.layerId, ds.cumLng, ds.cumLat);
        }
        polygonMoveRef.current = null;
        setIsPolygonMoving(false);
      },
      onPanResponderTerminate: () => {
        const ds = polygonMoveRef.current;
        if (ds && ds.active && onPolygonMoveEndRef.current) {
          onPolygonMoveEndRef.current(ds.featureId, ds.layerId, ds.cumLng, ds.cumLat);
        }
        polygonMoveRef.current = null;
        setIsPolygonMoving(false);
      },
    })
  ).current;

  // ── Long-press handler — initiates point drag, or vertex drag when
  //     the long-press lands near an editing vertex ───────────────────────
  const handleLongPress = useCallback(
    (e: any) => {
      // v11 long-press exposes lngLat on nativeEvent (v10 used geometry.coordinates)
      const lngLat = e?.nativeEvent?.lngLat ?? e?.geometry?.coordinates;
      if (!lngLat) return;
      const pressLng = lngLat[0] as number;
      const pressLat = lngLat[1] as number;

      // ── Vertex drag: if editing a line/polygon, long-press near a vertex ──
      const vTarget = vertexDragTarget ?? polygonEditTarget;
      if (vTarget && (onVertexDragEnd || onPolygonVertexDragEnd)) {
        for (const layerData of layers) {
          const previewLayerId = `temp-preview-${vTarget.layerId}`;
          if (layerData.id !== vTarget.layerId && layerData.id !== previewLayerId) continue;
          for (const feat of layerData.features) {
            const fid = (feat.properties as any)?.id ?? (feat.properties as any)?._id ?? '';
            if (fid !== vTarget.featureId) continue;

            const geom = feat.geometry;
            let vCoords: [number, number][] = [];
            let vIsPolygon = false;
            if (geom?.type === 'LineString') vCoords = (geom.coordinates as [number, number][]) ?? [];
            else if (geom?.type === 'MultiLineString') vCoords = ((geom.coordinates as [number, number][][])[0] ?? []) as [number, number][];
            else if (geom?.type === 'Polygon') { vCoords = ((geom.coordinates as [number, number][][])[0] ?? []) as [number, number][]; vIsPolygon = true; }
            else if (geom?.type === 'MultiPolygon') { vCoords = ((geom.coordinates as [number, number][][][])[0]?.[0] ?? []) as [number, number][]; vIsPolygon = true; }

            // Find nearest vertex within ~60m
            let bestIdx = -1;
            let bestVDist = Infinity;
            vCoords.forEach(([vlng, vlat], i) => {
              const d = (vlng - pressLng) ** 2 + (vlat - pressLat) ** 2;
              if (d < bestVDist) { bestVDist = d; bestIdx = i; }
            });
            if (bestIdx >= 0 && bestVDist <= 0.0006 ** 2) {
              const dragCb = vIsPolygon ? onPolygonVertexDragEnd : onVertexDragEnd;
              if (!dragCb) continue; // no drag callback for this mode → skip grab
              // Start from the VERTEX's own coordinates, not the long-press
              // point (which can be up to ~60 m away) — otherwise the vertex
              // visibly jumps to the press location the moment the drag starts.
              const vertexCoords = vCoords[bestIdx];
              vertexDragRef.current = {
                featureId: vTarget.featureId,
                layerId: vTarget.layerId,
                vertexIdx: bestIdx,
                startLng: vertexCoords[0],
                startLat: vertexCoords[1],
                startScreenX: 0,
                startScreenY: 0,
                baselineCaptured: false,
                isPolygon: vIsPolygon,
                coords: [...vCoords],
              };
              vertexDragCoordsRef.current = [vertexCoords[0], vertexCoords[1]];
              setIsVertexDragging(true);
              setVertexDragDistance(null);
              console.log(`[Vertex] Long-press started drag of vertex ${bestIdx}`);
              return;
            }
          }
        }
      }

      // ── Point drag (only when dragMode is enabled) ─────────────────────
      if (!dragMode || !onDragEndRef.current || !draggableLayerIds) return;

      // Find nearest draggable point feature within 500m
      let bestDist = Infinity;
      let bestMatch: { featureId: string; layerId: string; featureIndex: number } | null = null;

      for (const layerData of layers) {
        if (!layerData.visible || layerData.features.length === 0) continue;
        if (!draggableLayerIds.has(layerData.id)) continue;
        const geomType = layerData.geometryType ?? detectGeometryType(layerData.features);
        if (geomType !== 'Point') continue;

        layerData.features.forEach((f, i) => {
          const geom = f.geometry;
          if (geom?.type !== 'Point') return;
          const [flng, flat] = geom.coordinates as [number, number];
          // Approximate distance in metres
          const dlng = (flng - pressLng) * 111320 * Math.cos((pressLat * Math.PI) / 180);
          const dlat = (flat - pressLat) * 110540;
          const dist = Math.sqrt(dlng * dlng + dlat * dlat);
          if (dist < bestDist && dist < 100) {
            bestDist = dist;
            bestMatch = {
              featureId: (f.properties as any)?._id ?? `${layerData.id}-${i}`,
              layerId: layerData.id,
              featureIndex: i,
            };
          }
        });
      }

      if (bestMatch) {
        const match = bestMatch as { featureId: string; layerId: string; featureIndex: number };
        dragRef.current = {
          featureId: match.featureId,
          layerId: match.layerId,
          featureIndex: match.featureIndex,
          startLng: pressLng,
          startLat: pressLat,
          startScreenX: 0,
          startScreenY: 0,
          currentZoom: zoomRef.current,
          baselineCaptured: false,
        };
        dragCoordsRef.current = [pressLng, pressLat];
        setDragCoords([pressLng, pressLat]);
        setIsDragging(true);
      }
    },
    [dragMode, draggableLayerIds, layers, vertexDragTarget, polygonEditTarget, onVertexDragEnd, onPolygonVertexDragEnd]
  );

  // ── Fly-to imported center ────────────────────────────────────────────
  useEffect(() => {
    if (!cameraRef.current || !flyToCenter || status !== 'ready') return;
    try {
      cameraRef.current?.flyTo({ center: [flyToCenter.lng, flyToCenter.lat], duration: 1200 });
      cameraRef.current?.zoomTo(flyToCenter.zoom, { duration: 1200 });
    } catch {}
  }, [flyToCenter?.lng, flyToCenter?.lat, flyToCenter?.zoom, status]);

  // ── Fly-to user GPS location (crosshair FAB) ──────────────────────────
  useEffect(() => {
    if (!cameraRef.current || !flyToUserTarget || status !== 'ready') return;
    try {
      cameraRef.current?.flyTo({ center: [flyToUserTarget.lng, flyToUserTarget.lat], duration: 1000 });
      cameraRef.current?.zoomTo(flyToUserTarget.zoom, { duration: 1000 });
    } catch {}
  }, [flyToUserTarget?.ts, status]);

  // ── Fly-to selected feature ────────────────────────────────────────────
  useEffect(() => {
    if (!cameraRef.current || !selectedFeatureId || status !== 'ready') return;

    for (const layerData of layers) {
      for (const feature of layerData.features) {
        const fid = (feature.properties?.id as string) ?? (feature.properties?._id as string);
        if (fid === selectedFeatureId) {
          const coords = feature.geometry.coordinates;
          if (feature.geometry.type === 'Point') {
            try {
              cameraRef.current?.flyTo({ center: [coords[0] as number, coords[1] as number], duration: 800 });
              cameraRef.current?.zoomTo(17, { duration: 800 });
            } catch {}
          } else {
            // LineString: coords = [[lng,lat],...] → first = [lng,lat]
            // Polygon:    coords = [[[lng,lat],...]] → first = [[lng,lat],...] → need first[0]
            const raw = (coords as unknown[][])[0];
            const lng = typeof raw === 'number' ? raw : (raw as number[])?.[0];
            const lat = typeof raw === 'number' ? (coords as unknown[][])[1] : (raw as number[])?.[1];
            if (typeof lng === 'number' && typeof lat === 'number') {
              try {
                cameraRef.current?.flyTo({ center: [lng, lat], duration: 800 });
                cameraRef.current?.zoomTo(17, { duration: 800 });
              } catch {}
            }
          }
          return;
        }
      }
    }
  }, [selectedFeatureId, layers, status]);

  // ── Retry handler ──────────────────────────────────────────────────────
  const handleRetry = useCallback(() => {
    retryCountRef.current += 1;
    // CRITICAL: reset the alive-flag so the fallback ready-signals can
    // re-fire on the fresh map instance. Without this, a retry after a
    // dropped-event hang would stay stuck on 'loading' forever.
    mapAliveRef.current = false;
    setStatus('loading');
    setLoadProgress(undefined);
    setErrorInfo({ type: 'unknown', message: '' });
    // Bump mapKey to force React to unmount/remount the MapLibreGL.Map
    setMapKey((k) => k + 1);
  }, []);

  // ── Robust 'map is alive' detection ───────────────────────────────────
  // v11 on RN 0.8x (New Architecture) can silently drop DirectEventHandler
  // events (Fabric requires a 'top' prefix that the library may not emit),
  // so relying on onDidFinishLoadingMap alone leaves the loading overlay
  // stuck forever. Instead, treat ANY of these signals as proof the map
  // initialized and rendering: style loaded, first frame rendered, or the
  // camera moved (the initial <Camera> always moves the viewport).
  const mapAliveRef = useRef(false);
  const aliveTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const markMapReady = useCallback((source: string) => {
    mapAliveRef.current = true;
    if (aliveTimerRef.current) { clearTimeout(aliveTimerRef.current); aliveTimerRef.current = null; }
    setLoadProgress(1);
    setStatus('ready');
    console.log(`[MapLibre] Map marked ready via ${source}`);
  }, []);

  const markMapAlive = useCallback(() => {
    if (mapAliveRef.current) return;
    // Grace: if any event proves the map is interactive, accept it as ready.
    // The timeout effect will still fire if nothing ever signals.
    mapAliveRef.current = true;
    if (aliveTimerRef.current) clearTimeout(aliveTimerRef.current);
    aliveTimerRef.current = setTimeout(() => {
      aliveTimerRef.current = null;
      setLoadProgress(1);
      setStatus((s) => (s === 'loading' ? 'ready' : s));
      console.log('[MapLibre] Map marked ready via camera/interaction signal');
    }, 1200);
  }, []);

  // Clear any pending alive-timer on unmount to avoid setState-after-unmount
  useEffect(() => {
    return () => {
      if (aliveTimerRef.current) { clearTimeout(aliveTimerRef.current); aliveTimerRef.current = null; }
    };
  }, []);

  // ── TurboModule liveness poll (event-bridge independent) ───────────────
  // The event bridge (DirectEventHandler) can silently drop events under
  // Fabric, but the imperative TurboModule (getZoom/getCenter) does NOT go
  // through that bridge. Polling it proves the native map is alive even if
  // every event is dropped — a bulletproof ready-signal.
  useEffect(() => {
    if (status !== 'loading') return;
    const poll = setInterval(() => {
      try {
        // getZoom() is a TurboModule call that returns a Promise — it does
        // NOT depend on the (possibly dropped) event bridge. If it resolves
        // with a finite number, the native map is alive and interactive.
        const maybe = mapRef.current?.getZoom?.();
        if (maybe && typeof maybe.then === 'function') {
          maybe.then((zoom: unknown) => {
            if (typeof zoom === 'number' && Number.isFinite(zoom)) {
              markMapAlive();
            }
          }).catch(() => { /* native not ready yet */ });
        } else if (typeof maybe === 'number' && Number.isFinite(maybe)) {
          markMapAlive();
        }
      } catch { /* native not ready yet */ }
    }, 2000);
    // Stop polling once we leave the loading state or after 25s (timeout covers it)
    const stop = setTimeout(() => clearInterval(poll), 25000);
    return () => { clearInterval(poll); clearTimeout(stop); };
  }, [status, markMapAlive, mapKey]);

  // ── Check if all layers are empty ───────────────────────────────────────
  const isEmpty = useMemo(() => !hasVisibleFeatures(layers), [layers]);

  // ── Vertex markers / polygon highlight data derivation ────────────────
  // When vertexDragTarget or polygonEditTarget is set, find the target
  // feature in the layers and build point features for each vertex.
  const editHandleData = useMemo(
    () => buildEditHandleData(layers, vertexDragTarget ?? polygonEditTarget ?? polygonMoveTarget),
    [layers, vertexDragTarget, polygonEditTarget, polygonMoveTarget],
  );

  // Keep the ref in sync so the gesture responder (created once) can see
  // current vertex positions without stale closures.
  useEffect(() => {
    if (editHandleData) {
      editHandleRef.current = {
        coords: editHandleData.coords,
        isPolygon: editHandleData.isPolygon,
        featureId: editHandleData.featureId,
        layerId: editHandleData.layerId,
      };
    } else {
      editHandleRef.current = null;
    }
  }, [editHandleData]);

  // Re-project vertex screen positions when edit data or the camera changes.
  useEffect(() => {
    const eh = editHandleData;
    if (!eh || !eh.coords || eh.coords.length === 0) {
      vertexScreenRef.current = null;
      vertexScreenVersionRef.current += 1;
      return;
    }
    const version = vertexScreenVersionRef.current + 1;
    vertexScreenVersionRef.current = version;
    let cancelled = false;
    const projectAll = async () => {
      const map = mapRef.current;
      if (!map || typeof map.project !== 'function') return;
      const results: Array<{ x: number; y: number; coords: [number, number]; idx: number }> = [];
      for (let i = 0; i < eh.coords.length; i++) {
        try {
          const [lng, lat] = eh.coords[i];
          const pt = await map.project([lng, lat]);
          if (cancelled || vertexScreenVersionRef.current !== version) return;
          results.push({ x: pt[0], y: pt[1], coords: [lng, lat], idx: i });
        } catch { /* vertex stays unprojected; tap-release fallback still works */ }
      }
      if (!cancelled && vertexScreenVersionRef.current === version) {
        vertexScreenRef.current = results.length > 0 ? results : null;
      }
    };
    projectAll();
    return () => { cancelled = true; };
  }, [editHandleData, cameraVersion]);

  const containerStyle: any = { flex: 1, minHeight: 300 };
  if (height !== undefined && typeof height === 'number') {
    containerStyle.height = height;
  }

  if (!MapLibreGL) {
    return (
      <View style={[containerStyle, styles.errorContainer]}>
        <ErrorOverlay
          error={{ type: 'module', message: '@maplibre/maplibre-react-native is not available.' }}
          onRetry={handleRetry}
        />
      </View>
    );
  }

  return (
    <View style={containerStyle}>
      <MapLibreGL.Map
        key={`map-${mapKey}`}
        ref={mapRef}
        style={{ flex: 1 }}
        mapStyle={styleUrl}
        // Android v11 stability fix: 'surface' (GLSurfaceView) is prone to
        // native lifecycle crashes when navigating away / unmounting layers.
        // 'texture' (TextureView) renders through the normal Android view
        // hierarchy, avoiding the documented SurfaceView thread-lifecycle bugs.
        androidView="texture"
        onPress={handlePress}
        onLongPress={handleLongPress}
        dragPan={!isDragging && !isVertexDragging && !isPolygonMoving}
        touchZoom={!isDragging && !isVertexDragging}
        touchPitch={!isDragging && !isVertexDragging}
        touchRotate={!isDragging && !isVertexDragging}
        onRegionIsChanging={(e: any) => {
          const zoom = e?.nativeEvent?.zoom ?? e?.properties?.zoom;
          if (zoom !== undefined) {
            zoomRef.current = zoom;
          }
          const center = e?.nativeEvent?.center ?? e?.properties?.center;
          if (center && Array.isArray(center) && center.length === 2) {
            centerRef.current = [center[0], center[1]];
          }
          markMapAlive();
        }}
        onRegionDidChange={() => { markMapAlive(); setCameraVersion((v) => v + 1); }}
        onDidFinishLoadingMap={() => markMapReady('onDidFinishLoadingMap')}
        onDidFinishLoadingStyle={() => markMapReady('onDidFinishLoadingStyle')}
        onDidFinishRenderingMap={() => markMapReady('onDidFinishRenderingMap')}
        onDidFinishRenderingMapFully={() => markMapReady('onDidFinishRenderingMapFully')}
        onDidFailLoadingMap={(e: any) => {
          // v11 passes NativeSyntheticEvent<null> here — no error payload is
          // available, so report a generic style-load failure. Log to the
          // native console (visible via `adb logcat`) with diagnostic
          // context so style failures are traceable in the field.
          const styleDesc =
            typeof styleUrl === 'string'
              ? styleUrl
              : `inline StyleSpecification (${Object.keys(styleUrl).length} keys)`;
          console.error(
            `[MapLibre] Map style failed to load. platform=${Platform.OS} mapKey=${mapKey} retry=${retryCountRef.current} style=${styleDesc}`,
            e?.nativeEvent ?? e ?? '',
          );
          setErrorInfo({
            type: 'style',
            message: 'Map style failed to load.',
          });
          setStatus('error');
        }}
        logo={false}
        attribution={true}
      >
        <MapLibreGL.Camera
          ref={cameraRef}
          centerCoordinate={flyToCenter ? [flyToCenter.lng, flyToCenter.lat] : DEFAULT_CENTER}
          zoomLevel={flyToCenter?.zoom ?? 13}
        />

        {layers.map((layerData) => {
          if (!layerData.visible || layerData.features.length === 0) return null;

          const sourceId = `src-${layerData.id}`;
          const geomType = layerData.geometryType ?? detectGeometryType(layerData.features);
          const shape = layerShapes[layerData.id];
          if (!shape) return null;

          return (
            <React.Fragment key={sourceId}>
              <MapLibreGL.GeoJSONSource id={sourceId} data={shape} onPress={handlePress}>
                {geomType === 'Point' && (
                  <>
                    {/* Drag highlight ring — visible only when this layer has the dragged feature */}
                    {isDragging && dragRef.current?.layerId === layerData.id && (
                      <MapLibreGL.Layer
                        type="circle"
                        id={`drag-hl-${layerData.id}`}
                        source={sourceId}
                        filter={['==', ['get', '_id'], dragRef.current?.featureId ?? '']}
                        style={{
                          circleRadius: 16,
                          circleColor: 'transparent',
                          circleStrokeWidth: 3,
                          circleStrokeColor: '#0D5CFF',
                          circleStrokeOpacity: 0.8,
                        }}
                      />
                    )}
                    <MapLibreGL.Layer
                      type="circle"
                      id={`lyr-${layerData.id}`}
                      source={sourceId}
                      style={{
                        circleRadius: isDragging && dragRef.current?.layerId === layerData.id ? 10 : 7,
                        circleColor: layerData.color,
                        circleStrokeWidth: isDragging && dragRef.current?.layerId === layerData.id ? 3 : 2,
                        circleStrokeColor: isDragging && dragRef.current?.layerId === layerData.id ? '#0D5CFF' : '#ffffff',
                      }}
                    />
                  </>
                )}
                {geomType === 'LineString' && (
                  <MapLibreGL.Layer
                    type="line"
                    id={`lyr-${layerData.id}`}
                    source={sourceId}
                    style={{
                      lineColor: layerData.color,
                      lineWidth: 3,
                      lineOpacity: 0.85,
                    }}
                  />
                )}
                {geomType === 'Polygon' && (
                  <>
                    <MapLibreGL.Layer
                      type="fill"
                      id={`fill-${layerData.id}`}
                      source={sourceId}
                      style={{ fillColor: layerData.color, fillOpacity: 0.25 }}
                    />
                    <MapLibreGL.Layer
                      type="line"
                      id={`out-${layerData.id}`}
                      source={sourceId}
                      style={{ lineColor: layerData.color, lineWidth: 2 }}
                    />
                  </>
                )}
              </MapLibreGL.GeoJSONSource>
            </React.Fragment>
          );
        })}

        {/* ── Vertex Markers — rendered when a line/polygon is being edited.
             Hidden in whole-polygon Move mode — the corners stay put there
             (the body translates), so showing draggable handles is misleading. ── */}
        {editHandleData && !polygonMoveTarget && (
          <MapLibreGL.GeoJSONSource
            id={`ml-vert-src-${editHandleData.layerId}-${editHandleData.featureId}`}
            onPress={handleVertexPress}
            data={{
              type: 'FeatureCollection',
              features: editHandleData.vertexFeatures as any[],
            }}
          >
            {/* White circle with colored stroke for each vertex */}
            <MapLibreGL.Layer
              type="circle"
              id={`ml-vert-lyr-${editHandleData.layerId}-${editHandleData.featureId}`}
              source={`ml-vert-src-${editHandleData.layerId}-${editHandleData.featureId}`}
              style={{
                circleRadius: 7,
                circleColor: '#FFFFFF',
                circleStrokeWidth: 2.5,
                circleStrokeColor: editHandleData.color,
                circleOpacity: 0.95,
              }}
            />
            {/* Larger invisible drag handle for easier tapping */}
            <MapLibreGL.Layer
              type="circle"
              id={`ml-vert-drag-${editHandleData.layerId}-${editHandleData.featureId}`}
              source={`ml-vert-src-${editHandleData.layerId}-${editHandleData.featureId}`}
              style={{
                circleRadius: 20,
                circleColor: 'transparent',
                circleStrokeWidth: 0,
              }}
            />
          </MapLibreGL.GeoJSONSource>
        )}

        {/* ── Snap halo — green ring shown while a dragged vertex is locked
             onto existing infrastructure (trench/duct/cable) ── */}
        {snapActive && snapPos && (
          <MapLibreGL.GeoJSONSource
            id="ml-snap-src"
            data={{
              type: 'FeatureCollection',
              features: [
                {
                  type: 'Feature',
                  geometry: { type: 'Point', coordinates: [snapPos.lng, snapPos.lat] },
                  properties: {},
                },
              ],
            }}
          >
            <MapLibreGL.Layer
              type="circle"
              id="ml-snap-halo"
              source="ml-snap-src"
              style={{
                circleRadius: 16,
                circleColor: 'transparent',
                circleStrokeWidth: 3.5,
                circleStrokeColor: '#22C55E',
                circleOpacity: 0.95,
              }}
            />
          </MapLibreGL.GeoJSONSource>
        )}

        {/* ── Polygon Highlight — rendered when a polygon is being edited ── */}
        {editHandleData && editHandleData.isPolygon && editHandleData.polygonGeom && !isVertexDragging && (
          <MapLibreGL.GeoJSONSource
            id={`ml-poly-hl-src-${editHandleData.layerId}-${editHandleData.featureId}`}
            data={{
              type: 'FeatureCollection',
              features: [
                {
                  type: 'Feature',
                  geometry: editHandleData.polygonGeom,
                  properties: {
                    _id: editHandleData.featureId,
                    _layer_id: editHandleData.layerId,
                  },
                },
              ],
            }}
          >
            {/* Semi-transparent fill */}
            <MapLibreGL.Layer
              type="fill"
              id={`ml-poly-hl-fill-${editHandleData.layerId}-${editHandleData.featureId}`}
              source={`ml-poly-hl-src-${editHandleData.layerId}-${editHandleData.featureId}`}
              style={{
                fillColor: editHandleData.color,
                fillOpacity: 0.18,
              }}
            />
            {/* Thick outline */}
            <MapLibreGL.Layer
              type="line"
              id={`ml-poly-hl-line-${editHandleData.layerId}-${editHandleData.featureId}`}
              source={`ml-poly-hl-src-${editHandleData.layerId}-${editHandleData.featureId}`}
              style={{
                lineColor: editHandleData.color,
                lineWidth: 3.5,
                lineOpacity: 0.95,
              }}
            />
          </MapLibreGL.GeoJSONSource>
        )}

        {/* ── User Location Dot (GPS) ── blue dot + white halo when the device has a fix ── */}
        {userLocation && (
          <MapLibreGL.GeoJSONSource
            id="ml-user-loc-src"
            onPress={() => {
              // Swallow taps on the GPS dot — must not fire empty-area clicks
              // (e.g. placing a stray path point while in draw-segment mode).
            }}
            data={{
              type: 'FeatureCollection',
              features: [
                {
                  type: 'Feature',
                  geometry: {
                    type: 'Point',
                    coordinates: [userLocation.longitude, userLocation.latitude],
                  },
                  properties: { _is_user_location: true },
                },
              ],
            }}
          >
            <MapLibreGL.Layer
              type="circle"
              id="ml-user-loc-halo"
              source="ml-user-loc-src"
              style={{
                circleRadius: 14,
                circleColor: 'transparent',
                circleStrokeWidth: 3,
                circleStrokeColor: '#0D5CFF',
                circleStrokeOpacity: 0.35,
              }}
            />
            <MapLibreGL.Layer
              type="circle"
              id="ml-user-loc-dot"
              source="ml-user-loc-src"
              style={{
                circleRadius: 6,
                circleColor: '#0D5CFF',
                circleStrokeWidth: 2,
                circleStrokeColor: '#FFFFFF',
              }}
            />
          </MapLibreGL.GeoJSONSource>
        )}
      </MapLibreGL.Map>

      {/* ── Vertex Drag overlay — always present in vertex-edit mode so a
            single touch-and-drag moves the vertex (touch-down arming).
            onStartShouldSetPanResponder returns false when the finger is
            not near a vertex, so map pan/zoom still works normally. ─── */}
      {(onVertexDragEnd || onPolygonVertexDragEnd) && (vertexDragTarget || polygonEditTarget) && (
        <View
          style={StyleSheet.absoluteFill}
          pointerEvents="auto"
          {...vertexPanResponder.panHandlers}
        />
      )}

      {/* ── Whole-polygon Move overlay — present in polygon Move mode so a
            single touch-and-drag on the polygon BODY translates the whole
            feature. onStartShouldSetPanResponder returns false unless the
            touch lands inside the projected ring, so pan/zoom elsewhere
            still works normally. ─── */}
      {polygonMoveTarget && (onPolygonMove || onPolygonMoveEnd) && (
        <View
          style={StyleSheet.absoluteFill}
          pointerEvents="auto"
          {...polygonMovePanResponder.panHandlers}
        />
      )}

      {/* ── Drag overlay — transparent PanResponder view that captures
            gestures during active drag. Only renders when dragging. ──────── */}
      {isDragging && (
        <View
          style={StyleSheet.absoluteFill}
          pointerEvents="auto"
          {...panResponder.panHandlers}
        />
      )}

      {/* Drag Distance Display — shown during drag on native */}
      {isDragging && dragDistance !== null && (
        <View style={styles.dragDistanceOverlay}>
          <View style={styles.dragDistanceCard}>
            <Text style={styles.dragDistanceIcon}>↕️</Text>
            <View style={{ flexDirection: 'row', alignItems: 'baseline' }}>
              <Text style={styles.dragDistanceValue}>{dragDistance}</Text>
              <Text style={styles.dragDistanceUnit}>m</Text>
            </View>
          </View>
        </View>
      )}

      {/* Vertex Drag Distance Display */}
      {isVertexDragging && vertexDragDistance !== null && (
        <View style={styles.dragDistanceOverlay}>
          <View style={styles.dragDistanceCard}>
            <Ruler size={16} stroke={colors.textSecondary} />
            <View style={{ flexDirection: 'row', alignItems: 'baseline' }}>
              <Text style={styles.dragDistanceValue}>{vertexDragDistance}</Text>
              <Text style={styles.dragDistanceUnit}>m</Text>
            </View>
          </View>
        </View>
      )}

      {/* Loading Overlay — only on loading, not during timeout to avoid visual stacking */}
      {status === 'loading' && (
        <LoadingOverlay
          message={
            retryCountRef.current > 0
              ? `Retrying... (attempt ${retryCountRef.current})`
              : 'Loading map...'
          }
          progress={loadProgress}
        />
      )}

      {/* Timeout Error */}
      {status === 'timeout' && (
        <ErrorOverlay
          error={{ type: 'timeout', message: 'Map did not load within the expected time.' }}
          onRetry={handleRetry}
        />
      )}

      {/* Error Overlay */}
      {status === 'error' && (
        <ErrorOverlay error={errorInfo} onRetry={handleRetry} />
      )}

      {/* Empty State Overlay */}
      {status === 'ready' && isEmpty && <EmptyOverlay emptyState={emptyState} />}
    </View>
  );
}

// ── Web Implementation (self-hosted) ───────────────────────────────────────
// MapLibre GL is served locally from /public/vendor/maplibre/ (same 4.7.1
// UMD build the web admin frontend vendors) instead of a CDN, because the
// unpkg CDN was unreliable/blocked in some environments.
const MAPLIBRE_VERSION = '4.7.1';
const CSS_URL = `/vendor/maplibre/maplibre-gl.css`;
const JS_URL = `/vendor/maplibre/maplibre-gl.js`;

let scriptLoadPromise: Promise<void> | null = null;

function loadMapLibreCSS(): Promise<void> {
  return new Promise((resolve) => {
    // Defensive guard — this code path must only run in a browser.
    if (typeof document === 'undefined') { resolve(); return; }
    if (document.getElementById('ml-css')) { resolve(); return; }
    const link = document.createElement('link');
    link.id = 'ml-css';
    link.rel = 'stylesheet';
    link.href = CSS_URL;
    link.onload = () => resolve();
    link.onerror = () => resolve();
    document.head.appendChild(link);
  });
}

function loadMapLibreJS(): Promise<void> {
  // Defensive guard — this code path must only run in a browser.
  if (typeof document === 'undefined' || typeof window === 'undefined') {
    return Promise.resolve();
  }
  if ((window as any).maplibregl) return Promise.resolve();
  if (scriptLoadPromise) return scriptLoadPromise;

  scriptLoadPromise = new Promise((resolve) => {
    const script = document.createElement('script');
    script.src = JS_URL;
    script.onload = () => setTimeout(resolve, 100);
    script.onerror = () => {
      console.warn('Failed to load maplibre-gl from local /vendor/maplibre');
      resolve();
    };
    document.body.appendChild(script);
  });

  return scriptLoadPromise;
}

/** Remove all vertex marker layers and sources from the map */
/**
 * True for any Point-family geometry (Point / MultiPoint).
 * Points are small, manually placed targets (premises, PDP, MFG, chambers) —
 * they must always beat the line or polygon rendered underneath them.
 */
function isPointFeature(f: any): boolean {
  const t = f?.geometry?.type;
  return t === 'Point' || t === 'MultiPoint';
}

/**
 * Pick the feature a tap means when several overlap.
 * Priority: our own layer features > point geometry > top-most (first in
 * MapLibre's render order, which is bottom-to-top for the layers array).
 */
function pickTappedFeature(features: any[]): any | null {
  if (!features || features.length === 0) return null;
  const ours = features.filter((f) => f?.properties?._id || f?.properties?._layer_id);
  const pool = ours.length > 0 ? ours : features;
  return pool.find(isPointFeature) ?? pool[0] ?? null;
}

/**
 * All tappable features at a press, ordered exactly as the tap resolver ranks
 * them (point-first, top-most ties preserved). The popup offers a "cycle"
 * chip from this list, so its order must match what was selected.
 */
function tapCandidates(
  features: any[],
): { featureId: string; layerId: string; geometryType: string }[] {
  const out: { featureId: string; layerId: string; geometryType: string }[] = [];
  // The drag-handle layer mirrors the visible layer, so a tap on a point
  // returns the SAME feature twice (`ml-drag-imp-pdps` and `ml-lyr-imp-pdps`
  // both carry `_layer_id = imp-pdps`). A duplicate is not an overlap, and it
  // is what stopped the popup's cycle chip: the handler looks the selected
  // feature up with `findIndex`, which always matched the first copy, so the
  // next entry was the feature's own twin and "N of M here" could never
  // advance past the feature it started on. The duplicates also inflated M.
  // One entry per (feature, layer), in the top-most order they arrived in.
  const seen = new Set<string>();
  for (const f of features ?? []) {
    if (f?.properties?._is_user_location) continue;
    const id = f?.properties?._id;
    const lid = f?.properties?._layer_id;
    if (id && lid) {
      const key = `${lid}|${id}`;
      if (seen.has(key)) continue;
      seen.add(key);
      out.push({
        featureId: String(id),
        layerId: String(lid),
        geometryType: String(f?.geometry?.type ?? ''),
      });
    }
  }
  // Stable sort (JS sort is stable) keeps top-most order inside each group.
  return out.sort(
    (a, b) =>
      (a.geometryType === 'Point' || a.geometryType === 'MultiPoint' ? 0 : 1) -
      (b.geometryType === 'Point' || b.geometryType === 'MultiPoint' ? 0 : 1),
  );
}

/**
 * Derive the vertex-handle data for the feature currently being edited.
 * Shared by the native renderer (declarative <GeoJSONSource>) and the web
 * renderer (imperative maplibre-gl layers) so both draw identical ml-vert-*
 * handles for the same target.
 */
function buildEditHandleData(
  layers: MapLayerData[],
  target: { featureId: string; layerId: string } | null | undefined,
): {
  featureId: string;
  layerId: string;
  coords: [number, number][];
  color: string;
  isPolygon: boolean;
  polygonGeom: any;
  vertexFeatures: any[];
} | null {
  if (!target) return null;
  for (const layerData of layers) {
    // Match exact layer ID OR temp-preview- prefixed version (used during Move Mode)
    const layerId = layerData.id;
    const previewLayerId = `temp-preview-${target.layerId}`;
    if (layerId !== target.layerId && layerId !== previewLayerId) continue;
    for (const feat of layerData.features) {
      const fid = (feat.properties as any)?.id ?? (feat.properties as any)?._id ?? '';
      if (fid !== target.featureId) continue;

      const geom = feat.geometry as any;
      const color = layerData.color ?? '#0D5CFF';
      let coords: [number, number][] = [];
      let isPolygon = false;

      if (geom?.type === 'LineString') {
        coords = (geom.coordinates as [number, number][]) ?? [];
      } else if (geom?.type === 'MultiLineString') {
        coords = ((geom.coordinates as [number, number][][])[0] ?? []) as [number, number][];
      } else if (geom?.type === 'Polygon') {
        coords = ((geom.coordinates as [number, number][][])[0] ?? []) as [number, number][];
        isPolygon = true;
      } else if (geom?.type === 'MultiPolygon') {
        coords = ((geom.coordinates as [number, number][][][])[0]?.[0] ?? []) as [number, number][];
        isPolygon = true;
      }

      if (coords.length === 0) return null;

      const pointFeatures = coords.map(([lng, lat], idx) => ({
        type: 'Feature' as const,
        geometry: { type: 'Point' as const, coordinates: [lng, lat] },
        properties: {
          _id: `vert-${target.layerId}-${target.featureId}-${idx}`,
          _layer_id: target.layerId,
          _parent_feature_id: target.featureId,
          _vertex_idx: idx,
          _is_vertex: true,
        },
      }));

      return {
        featureId: target.featureId,
        layerId: target.layerId,
        coords,
        color,
        isPolygon: isPolygon || geom?.type === 'Polygon' || geom?.type === 'MultiPolygon',
        polygonGeom: (isPolygon || geom?.type === 'Polygon' || geom?.type === 'MultiPolygon') ? geom : null,
        vertexFeatures: pointFeatures,
      };
    }
  }
  return null;
}

function removeVertexMarkers(map: any): void {
  const vertexPrefixes = ['ml-vert-src-', 'ml-vert-lyr-', 'ml-vert-hl-', 'ml-vert-drag-', 'ml-poly-hl-src-', 'ml-poly-hl-fill-', 'ml-poly-hl-line-'];
  const style = map.getStyle();
  if (style?.layers) {
    for (const layer of [...style.layers]) {
      if (vertexPrefixes.some((p) => layer.id.startsWith(p))) {
        try { map.removeLayer(layer.id); } catch {}
      }
    }
  }
  if (style?.sources) {
    for (const sourceId of Object.keys(style.sources)) {
      if (vertexPrefixes.some((p) => sourceId.startsWith(p))) {
        try { map.removeSource(sourceId); } catch {}
      }
    }
  }
}

/** Approximate distance in metres between two coordinates */
function coordDistMeters(lng1: number, lat1: number, lng2: number, lat2: number): number {
  const avgLat = (lat1 + lat2) / 2;
  const dx = (lng2 - lng1) * 111320 * Math.cos((avgLat * Math.PI) / 180);
  const dy = (lat2 - lat1) * 110540;
  return Math.sqrt(dx * dx + dy * dy);
}

/** Add vertex marker points for a LineString feature being edited */
function addPolygonHighlight(map: any, featureId: string, layerId: string, feature: any, color: string): void {
  const sourceId = `ml-poly-hl-src-${layerId}-${featureId}`;
  const fillLayerId = `ml-poly-hl-fill-${layerId}-${featureId}`;
  const lineLayerId = `ml-poly-hl-line-${layerId}-${featureId}`;

  try {
    map.addSource(sourceId, {
      type: 'geojson',
      data: {
        type: 'FeatureCollection',
        features: [{
          type: 'Feature',
          geometry: feature?.geometry ?? { type: 'Polygon', coordinates: [] },
          properties: { _id: featureId, _layer_id: layerId },
        }],
      },
    });

    map.addLayer({
      id: fillLayerId,
      type: 'fill',
      source: sourceId,
      paint: {
        'fill-color': color,
        'fill-opacity': 0.16,
      },
    });

    map.addLayer({
      id: lineLayerId,
      type: 'line',
      source: sourceId,
      paint: {
        'line-color': color,
        'line-width': 3,
        'line-opacity': 0.95,
      },
    });
  } catch (e) {
    console.warn('[Polygon] Failed to add highlight layers:', e);
  }
}

function addVertexMarkers(
  map: any,
  featureId: string,
  layerId: string,
  coords: [number, number][],
  activeVertexIdx: number,
  color: string,
  minSpacingM = 10,
): void {
  const sourceId = `ml-vert-src-${layerId}-${featureId}`;

  // ── Thin coordinates: only show markers for vertices ≥5m apart ──
  // Start and end are always included. The original vertex index is
  // preserved in _vertex_idx so dragging a marker updates the correct
  // coordinate in tempLineCoords.
  const thinIndices: number[] = []; // original indices that get a marker
  for (let i = 0; i < coords.length; i++) {
    if (thinIndices.length === 0 || i === coords.length - 1) {
      thinIndices.push(i);
      continue;
    }
    const last = coords[thinIndices[thinIndices.length - 1]];
    const dist = coordDistMeters(last[0], last[1], coords[i][0], coords[i][1]);
    if (minSpacingM <= 0 || dist >= minSpacingM) {
      thinIndices.push(i);
    }
  }

  // Build point features for thinned vertices — preserves original indices
  const pointFeatures = thinIndices.map((origIdx) => {
    const [lng, lat] = coords[origIdx];
    return {
      type: 'Feature' as const,
      geometry: { type: 'Point' as const, coordinates: [lng, lat] },
      properties: {
        _id: `vert-${layerId}-${featureId}-${origIdx}`,
        _layer_id: layerId,
        _parent_feature_id: featureId,
        _vertex_idx: origIdx,  // Use ORIGINAL index so dragging updates correct coordinate
        _is_vertex: true,
        _is_active: origIdx === activeVertexIdx,
      },
    };
  });

  try {
    map.addSource(sourceId, {
      type: 'geojson',
      data: { type: 'FeatureCollection', features: pointFeatures },
    });

    // All vertex circles
    map.addLayer({
      id: `ml-vert-lyr-${layerId}-${featureId}`,
      type: 'circle',
      source: sourceId,
      paint: {
        'circle-radius': 7,
        'circle-color': '#FFFFFF',
        'circle-stroke-width': 2.5,
        'circle-stroke-color': color,
        'circle-opacity': 0.95,
      },
    });

    // Active vertex highlight (larger ring)
    map.addLayer({
      id: `ml-vert-hl-${layerId}-${featureId}`,
      type: 'circle',
      source: sourceId,
      filter: ['==', ['get', '_is_active'], true],
      paint: {
        'circle-radius': 12,
        'circle-color': 'transparent',
        'circle-stroke-width': 3,
        'circle-stroke-color': '#0D5CFF',
        'circle-stroke-opacity': 0.8,
      },
    });

    // Larger invisible drag handles for all vertices (easier to grab)
    map.addLayer({
      id: `ml-vert-drag-${layerId}-${featureId}`,
      type: 'circle',
      source: sourceId,
      paint: {
        'circle-radius': 20,
        'circle-color': 'transparent',
        'circle-stroke-width': 0,
        'circle-opacity': 0.01,
      },
    });
  } catch (e) {
    console.warn('[Vertex] Failed to add vertex markers:', e);
  }
}

function addGeoJSONLayers(map: any, layers: MapLayerData[]): void {
  const customPrefixes = ['ml-src-', 'ml-lyr-', 'ml-out-', 'ml-drag-'];

  const style = map.getStyle();
  if (style?.layers) {
    for (const layer of [...style.layers]) {
      if (customPrefixes.some((p) => layer.id.startsWith(p))) {
        try { map.removeLayer(layer.id); } catch {}
      }
    }
  }
  if (style?.sources) {
    for (const sourceId of Object.keys(style.sources)) {
      if (customPrefixes.some((p) => sourceId.startsWith(p))) {
        try { map.removeSource(sourceId); } catch {}
      }
    }
  }

  for (const layerData of layers) {
    if (!layerData.visible || layerData.features.length === 0) continue;

    const sourceId = `ml-src-${layerData.id}`;
    const layerId = `ml-lyr-${layerData.id}`;
    const outlineId = `ml-out-${layerData.id}`;
    const dragLayerId = `ml-drag-${layerData.id}`;
    const geomType = layerData.geometryType ?? detectGeometryType(layerData.features);

    const features = layerData.features.map((f, i) => ({
      ...f,
      properties: {
        ...(f.properties ?? {}),
        _id: f.properties?.id ?? `${layerData.id}-${i}`,
        _layer_id: layerData.id,
      },
    }));

    try {
      map.addSource(sourceId, {
        type: 'geojson',
        data: { type: 'FeatureCollection', features },
      });

      if (geomType === 'Point') {
        map.addLayer({
          id: layerId, type: 'circle', source: sourceId,
          paint: { 'circle-radius': 7, 'circle-color': layerData.color, 'circle-stroke-width': 2, 'circle-stroke-color': '#fff' },
        });
        // Add a larger invisible drag handle layer for easier grabbing
        map.addLayer({
          id: dragLayerId, type: 'circle', source: sourceId,
          paint: { 'circle-radius': 22, 'circle-color': 'transparent', 'circle-stroke-width': 0 },
        });
      } else if (geomType === 'LineString') {
        map.addLayer({
          id: layerId, type: 'line', source: sourceId,
          paint: { 'line-color': layerData.color, 'line-width': 3, 'line-opacity': 0.85 },
        });
      } else if (geomType === 'Polygon') {
        map.addLayer({
          id: layerId, type: 'fill', source: sourceId,
          paint: { 'fill-color': layerData.color, 'fill-opacity': 0.25 },
        });
        map.addLayer({
          id: outlineId, type: 'line', source: sourceId,
          paint: { 'line-color': layerData.color, 'line-width': 2 },
        });
      }
    } catch {}
  }
}

function WebMapView({
  layers,
  onFeatureClick,
  onFeatureCandidates,
  onEmptyAreaClick,
  onFeatureDragEnd,
  onVertexDragEnd,
  onVertexLongPress,
  onSegmentLongPress,
  vertexDragTarget,
  polygonEditTarget,
  polygonMoveTarget,
  onPolygonMove,
  onPolygonMoveEnd,
  onPolygonVertexDragEnd,
  userLocation,
  draggableLayerIds,
  dragMode = false,
  selectedFeatureId,
  height,
  mapStyle,
  loadingTimeoutMs = LOADING_TIMEOUT_MS,
  flyToCenter,
  flyToUserTarget,
  emptyState,
}: MapLibreMapProps) {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const mapRef = useRef<any>(null);
  const [status, setStatus] = useState<MapStatus>('loading');
  const [errorInfo, setErrorInfo] = useState<MapErrorInfo>({ type: 'unknown', message: '' });
  const [loadProgress, setLoadProgress] = useState<number | undefined>(undefined);
  const [mapKey, setMapKey] = useState(0);
  const retryCountRef = useRef(0);
  const layersRef = useRef<MapLayerData[]>(layers);
  layersRef.current = layers;

  const isEmpty = useMemo(() => !hasVisibleFeatures(layers), [layers]);

  // ── Loading timeout ─────────────────────────────────────────────────────
  useEffect(() => {
    if (status === 'ready' || status === 'error') return;
    const timer = setTimeout(() => {
      if (status === 'loading') {
        setErrorInfo({ type: 'timeout', message: 'Map did not load within the expected time.' });
        setStatus('timeout');
      }
    }, loadingTimeoutMs);
    return () => clearTimeout(timer);
  }, [status, loadingTimeoutMs]);

  // ── Initialise map from CDN — re-runs when mapKey changes (retry) ────────
  useEffect(() => {
    let cancelled = false;
    let map: any = null;

    (async () => {
      try {
        setLoadProgress(0.1);
        await loadMapLibreCSS();
        setLoadProgress(0.3);
        await loadMapLibreJS();

        if (cancelled) return;

        const ml = (window as any).maplibregl;
        if (!ml) {
          setErrorInfo({ type: 'module', message: 'maplibre-gl failed to load from local /vendor/maplibre.' });
          setStatus('error');
          return;
        }
        if (!containerRef.current) {
          setErrorInfo({ type: 'module', message: 'Map container not found.' });
          setStatus('error');
          return;
        }

        setLoadProgress(0.5);

        const initialStyle = mapStyle ?? DEFAULT_MAP_STYLE;

        map = new ml.Map({
          container: containerRef.current,
          style: initialStyle,
          center: OAKWOOD_CENTER,
          zoom: 15,
          attributionControl: true,
        });

        map.addControl(new ml.NavigationControl(), 'top-right');
        mapRef.current = map;
        setLoadProgress(0.7);

        // Listen for style load errors
        map.on('error', (e: any) => {
          const errMsg = e?.error?.message || e?.message || '';
          if (errMsg.toLowerCase().includes('tile') || errMsg.toLowerCase().includes('fetch') || errMsg.toLowerCase().includes('network')) {
            console.warn('[MapLibre] Tile/network error:', errMsg.slice(0, 100));
          }
        });

        if (map.isStyleLoaded()) {
          addGeoJSONLayers(map, layersRef.current);
          setLoadProgress(1);
          setStatus('ready');
        }

        map.on('load', () => {
          addGeoJSONLayers(map, layersRef.current);
          setLoadProgress(1);
          setStatus('ready');
        });

        // Fallback timeout inside the effect
        setTimeout(() => {
          try {
            if (map && !map.isStyleLoaded()) {
              addGeoJSONLayers(map, layersRef.current);
              setStatus('ready');
              setLoadProgress(1);
            }
          } catch {}
        }, 15000);
      } catch (err: any) {
        if (!cancelled) {
          const errMsg = err?.message ?? '';
          setErrorInfo({
            type: errMsg.toLowerCase().includes('network') || errMsg.toLowerCase().includes('fetch')
              ? 'network' : 'unknown',
            message: errMsg,
          });
          setStatus('error');
        }
      }
    })();

    return () => {
      cancelled = true;
      if (map) {
        try { map.remove(); } catch {}
        mapRef.current = null;
      }
    };
  }, [mapKey]);

  // ── Basemap style changes ──────────────────────────────────────────────
  const prevStyleRef = useRef<string | Record<string, unknown> | undefined>(undefined);

  useEffect(() => {
    const map = mapRef.current;
    if (!map || status !== 'ready') return;
    if (mapStyle === undefined) return;
    if (prevStyleRef.current === undefined) { prevStyleRef.current = mapStyle; return; }
    if (mapStyle === prevStyleRef.current) return;

    prevStyleRef.current = mapStyle;
    setStatus('loading');
    setLoadProgress(undefined);

    try {
      map.setStyle(mapStyle);
      const onStyleLoad = () => {
        addGeoJSONLayers(map, layersRef.current);
        setLoadProgress(1);
        setStatus('ready');
      };
      if (map.isStyleLoaded()) {
        onStyleLoad();
      } else {
        map.once('style.load', onStyleLoad);
      }
    } catch (err: any) {
      setErrorInfo({ type: 'style', message: err?.message ?? 'Failed to switch basemap style.' });
      setStatus('error');
    }
  }, [mapStyle, status]);

  // ── Layer updates ──────────────────────────────────────────────────────
  // addGeoJSONLayers() rebuilds every drawn layer, so skipping the call is
  // never safe: bailing out while the style was mid-update (which is the
  // state right after another effect adds its own layers) silently left the
  // working copy off the map — the orange preview line, and with it the
  // surface a bend is added on. Wait for the style instead of dropping the
  // update, and let the next render replace the queued one.
  useEffect(() => {
    const map = mapRef.current;
    if (!map || status !== 'ready') return;
    const apply = () => {
      if (!mapRef.current) return;
      addGeoJSONLayers(map, layers);
    };
    if (map.isStyleLoaded()) { apply(); return; }
    // Not loaded yet: retry as soon as it settles. Waiting for a full
    // 'idle' instead delays the working copy by seconds on a busy map.
    let cancelled = false;
    let tries = 0;
    let timer: any = null;
    const poll = () => {
      if (cancelled) return;
      if (map.isStyleLoaded()) { apply(); return; }
      if (tries++ > 100) return; // ~5 s, then give up quietly
      timer = setTimeout(poll, 50);
    };
    poll();
    return () => {
      cancelled = true;
      if (timer) clearTimeout(timer);
    };
  }, [layers, status]);

  // ── User Location Dot (GPS) ── blue dot + halo when the device has a fix ──
  // The source + layers are created ONCE; position updates only call
  // source.setData(). This avoids removeSource/addSource churn on every
  // watchPositionAsync tick (~every 5m of movement while the surveyor walks).
  useEffect(() => {
    const map = mapRef.current;
    if (!map || status !== 'ready') return;
    if (!map.isStyleLoaded()) return;

    const SRC = 'ml-user-loc-src';
    const HALO = 'ml-user-loc-halo';
    const DOT = 'ml-user-loc-dot';

    // NOTE: this effect also re-runs after a basemap switch because the
    // basemap effect sets status → 'loading' → 'ready' (deps include status),
    // and map.setStyle() destroys all sources/layers — so the getSource/
    // getLayer guards below re-create the dot on the freshly loaded style.

    try {
      // Create source + layers once (skip if already present — e.g. after
      // a style reload, getLayer/getSource return null so they get re-added).
      if (!map.getSource(SRC)) {
        map.addSource(SRC, {
          type: 'geojson',
          data: { type: 'FeatureCollection', features: [] },
        });
      }
      if (!map.getLayer(HALO)) {
        map.addLayer({
          id: HALO,
          type: 'circle',
          source: SRC,
          paint: {
            'circle-radius': 14,
            'circle-color': 'transparent',
            'circle-stroke-width': 3,
            'circle-stroke-color': '#0D5CFF',
            'circle-stroke-opacity': 0.35,
          },
        });
      }
      if (!map.getLayer(DOT)) {
        map.addLayer({
          id: DOT,
          type: 'circle',
          source: SRC,
          paint: {
            'circle-radius': 6,
            'circle-color': '#0D5CFF',
            'circle-stroke-width': 2,
            'circle-stroke-color': '#FFFFFF',
          },
        });
      }

      // Update position without recreating GL resources.
      const source = map.getSource(SRC);
      if (source && typeof source.setData === 'function') {
        source.setData({
          type: 'FeatureCollection',
          features: userLocation
            ? [{
                type: 'Feature',
                geometry: {
                  type: 'Point',
                  coordinates: [userLocation.longitude, userLocation.latitude],
                },
                // Non-empty property so the click handler can identify (and
                // ignore) taps that land only on the GPS dot.
                properties: { _is_user_location: true },
              }]
            : [],
        });
      }
    } catch (e) {
      console.warn('[UserLoc] Failed to update user-location dot:', e);
    }
  }, [userLocation, status]);

  // ── Click handler — fires onFeatureClick if a feature is hit,
  //     otherwise fires onEmptyAreaClick (if provided) ───────────────────
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !onFeatureClick) return;

    const handleClick = (e: any) => {
      const features = map.queryRenderedFeatures(e.point);
      const screenPt = e.point ? { x: e.point.x, y: e.point.y } : undefined;
      const tapLngLat: [number, number] = [e.lngLat.lng, e.lngLat.lat];

      // Taps that land ONLY on the GPS user-location dot are not feature
      // interactions — ignore them so draw/continue-line modes don't place a
      // stray path point at the surveyor's own position.
      const nonUserFeatures = (features ?? []).filter(
        (f: any) => !f?.properties?._is_user_location
      );

      if (nonUserFeatures.length === 0) {
        // ── Padded retry for small point targets ──
        // A PDP/premise circle is a couple of pixels of ink on top of a trench.
        // If nothing at all was hit, look for a point feature of ours within
        // ~12 px before treating the tap as empty ground.
        const px = e.point?.x ?? 0;
        const py = e.point?.y ?? 0;
        let padded: any[] = [];
        try {
          padded = map.queryRenderedFeatures([[px - 12, py - 12], [px + 12, py + 12]]) ?? [];
        } catch { padded = []; }
        const paddedPoints = padded.filter(
          (f: any) =>
            !f?.properties?._is_user_location &&
            isPointFeature(f) &&
            (f.properties?._id || f.properties?._layer_id),
        );
        if (paddedPoints.length > 0) {
          const chosen = pickTappedFeature(paddedPoints);
          const props = (chosen?.properties ?? {}) as Record<string, unknown>;
          const fid = props._id as string | undefined;
          const lid = props._layer_id as string | undefined;
          if (fid && lid) {
            if (onFeatureCandidates) {
              const stack = tapCandidates(padded);
              if (stack.length > 1) onFeatureCandidates(stack, tapLngLat, screenPt);
            }
            onFeatureClick(fid, lid, tapLngLat, screenPt);
            return;
          }
        }
        // No custom feature at click point — fire empty-area click for draw/geometry modes
        if (onEmptyAreaClick) {
          onEmptyAreaClick(e.lngLat.lng, e.lngLat.lat, screenPt);
        }
        return;
      }

      // Check if ANY of the returned features belong to our custom layers
      // (basemap features like street labels won't have _id/_layer_id)
      const hasOurFeature = nonUserFeatures.some(
        (f: any) => f.properties?._id || f.properties?._layer_id
      );

      if (!hasOurFeature) {
        // No custom feature at click point — fire empty-area click for draw/geometry modes
        if (onEmptyAreaClick) {
          onEmptyAreaClick(e.lngLat.lng, e.lngLat.lat, screenPt);
        }
        return;
      }

      if (onFeatureCandidates) {
        const stack = tapCandidates(nonUserFeatures);
        if (stack.length > 1) onFeatureCandidates(stack, tapLngLat, screenPt);
      }

      // Point beating line / top-most first — see pickTappedFeature.
      const chosen = pickTappedFeature(nonUserFeatures);
      const props = (chosen?.properties ?? null) as Record<string, unknown> | null;
      if (!props) return;
      const fid = props._id as string | undefined;
      const lid = props._layer_id as string | undefined;
      if (fid && lid) onFeatureClick(fid, lid, tapLngLat, screenPt);
    };

    map.on('click', handleClick);
    return () => { try { map.off('click', handleClick); } catch {} };
  }, [status, onFeatureClick, onFeatureCandidates, onEmptyAreaClick]);

  // ── Hover cursor ──────────────────────────────────────────────────────
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;
    const handlers: { layer: string; enter: () => void; leave: () => void }[] = [];

    for (const layerData of layers) {
      const layerId = `ml-lyr-${layerData.id}`;
      const isDraggable = dragMode && draggableLayerIds?.has(layerData.id) && layerData.geometryType === 'Point';
      try { if (!map.getLayer(layerId)) continue; } catch { continue; }
      const enter = () => {
        try {
          map.getCanvas().style.cursor = isDraggable ? 'grab' : 'pointer';
        } catch {}
      };
      const leave = () => { try { map.getCanvas().style.cursor = ''; } catch {} };
      try {
        map.on('mouseenter', layerId, enter);
        map.on('mouseleave', layerId, leave);
        handlers.push({ layer: layerId, enter, leave });
      } catch {}
    }

    return () => {
      for (const h of handlers) {
        try { map.off('mouseenter', h.layer, h.enter); map.off('mouseleave', h.layer, h.leave); } catch {}
      }
    };
  }, [layers, status, dragMode, draggableLayerIds]);

  // ── Vertex Drag State ──────────────────────────────────────────────────
  // When set, renders vertex markers for a LineString and handles vertex drag.
  // The ref is used inside the drag handler to know if we're dragging a vertex.
  const isVertexDragRef = useRef(false);
  const onVertexDragEndRef = useRef(onVertexDragEnd);
  onVertexDragEndRef.current = onVertexDragEnd;
  const onPolygonVertexDragEndRef = useRef(onPolygonVertexDragEnd);
  onPolygonVertexDragEndRef.current = onPolygonVertexDragEnd;
  const vertexDragTargetRef = useRef(vertexDragTarget);
  vertexDragTargetRef.current = vertexDragTarget;
  const onVertexLongPressRef = useRef(onVertexLongPress);
  onVertexLongPressRef.current = onVertexLongPress;
  const onSegmentLongPressRef = useRef(onSegmentLongPress);
  onSegmentLongPressRef.current = onSegmentLongPress;
  const polygonEditTargetRef = useRef(polygonEditTarget);
  polygonEditTargetRef.current = polygonEditTarget;
  const polygonMoveTargetRef = useRef(polygonMoveTarget);
  polygonMoveTargetRef.current = polygonMoveTarget;
  const onPolygonMoveRef = useRef(onPolygonMove);
  onPolygonMoveRef.current = onPolygonMove;
  const onPolygonMoveEndRef = useRef(onPolygonMoveEnd);
  onPolygonMoveEndRef.current = onPolygonMoveEnd;

  // NOTE: Vertex/edit handles are rendered DECLARATIVELY below (the
  // editHandleData JSX block), which attaches onPress to the vertex source
  // so taps actually start drags. An earlier imperative addVertexMarkers()
  // effect created layers with the SAME IDs but WITHOUT onPress, so taps
  // landed on a layer that could never start a drag — vertex handles
  // appeared frozen or vanished. The imperative path was removed; only
  // the declarative JSX path renders handles now.
  // removeVertexMarkers() is still used on unmount to clear any stray
  // native layers left by older builds.

  // Clean up vertex markers on unmount
  useEffect(() => {
    return () => {
      const map = mapRef.current;
      if (map) removeVertexMarkers(map);
    };
  }, []);

  // ── Point Drag (Geometry Editing) ────────────────────────────────────
  const [dragDistance, setDragDistance] = useState<number | null>(null);
  const dragOriginRef = useRef<{ lng: number; lat: number } | null>(null);

  const dragStateRef = useRef<{
    active: boolean;
    featureId: string;
    layerId: string;
    sourceId: string;
    featureIndex: number;
    originalLng: number;
    originalLat: number;
    startPoint: { x: number; y: number };
    /** If dragging a vertex, the index of the vertex being dragged */
    vertexIdx?: number;
    /** If dragging a vertex, the parent feature's source ID */
    parentSourceId?: string;
    /** Snapshot of full coordinate array at drag start (for rubber-band offset) */
    initialCoords?: [number, number][];
  } | null>(null);

  // ── Haversine distance (metres) ────────────────────────────────────────
  const haversineDistance = useCallback(
    (lng1: number, lat1: number, lng2: number, lat2: number): number => {
      const R = 6371000;
      const toRad = (d: number) => (d * Math.PI) / 180;
      const dLng = toRad(lng2 - lng1);
      const dLat = toRad(lat2 - lat1);
      const a =
        Math.sin(dLat / 2) ** 2 +
        Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLng / 2) ** 2;
      return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    },
    []
  );

  // Separate effect: enable/disable drag-pan based on dragMode
  useEffect(() => {
    const map = mapRef.current;
    if (!map || status !== 'ready') return;
    try {
      if (dragMode) {
        map.dragPan.disable();
      } else {
        map.dragPan.enable();
      }
    } catch {}
  }, [dragMode, status]);

  // ── Point drag effect (guarded by dragMode) ────────────────────────────
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !onFeatureDragEnd || !dragMode || status !== 'ready') return;

    const canvas = map.getCanvas();
    const cleanupFns: (() => void)[] = [];

    const containerToLngLat = (e: any) => {
      if (e.lngLat) return e.lngLat;
      try {
        const rect = map.getContainer().getBoundingClientRect();
        return map.unproject([e.clientX - rect.left, e.clientY - rect.top]);
      } catch { return null; }
    };

    const onDragMove = (e: any) => {
      const ds = dragStateRef.current;
      if (!ds?.active) return;
      const lngLat = containerToLngLat(e);
      if (!lngLat) return;

      if (dragOriginRef.current) {
        const dist = haversineDistance(
          dragOriginRef.current.lng,
          dragOriginRef.current.lat,
          lngLat.lng,
          lngLat.lat
        );
        setDragDistance(Math.round(dist));
      }

      const src = map.getSource(ds.sourceId) as any;
      if (!src?._data?.features) return;
      try {
        const features = [...src._data.features];
        if (features[ds.featureIndex]?.geometry?.type === 'Point') {
          features[ds.featureIndex] = {
            ...features[ds.featureIndex],
            geometry: { ...features[ds.featureIndex].geometry, coordinates: [lngLat.lng, lngLat.lat] },
          };
          src.setData({ type: 'FeatureCollection', features });
        }
      } catch {}
    };

    const cancelDrag = () => {
      const ds = dragStateRef.current;
      if (!ds?.active) return;
      if (ds.originalLng !== undefined) {
        try {
          const src = map.getSource(ds.sourceId) as any;
          if (src?._data?.features) {
            const features = [...src._data.features];
            if (features[ds.featureIndex]?.geometry?.type === 'Point') {
              features[ds.featureIndex] = {
                ...features[ds.featureIndex],
                geometry: { ...features[ds.featureIndex].geometry, coordinates: [ds.originalLng, ds.originalLat] },
              };
              src.setData({ type: 'FeatureCollection', features });
            }
          }
        } catch {}
      }
      try { map.getCanvas().style.cursor = 'grab'; } catch {}
      try { if (map.getLayer(`ml-lyr-${ds.layerId}-dragging`)) map.removeLayer(`ml-lyr-${ds.layerId}-dragging`); } catch {}
      // Remove origin marker
      try {
        const origLayerId = `ml-orig-${ds.sourceId}`;
        const origSourceId = `${ds.sourceId}-origin`;
        if (map.getLayer(origLayerId)) map.removeLayer(origLayerId);
        if (map.getSource(origSourceId)) map.removeSource(origSourceId);
      } catch {}
      setDragDistance(null);
      dragOriginRef.current = null;
      dragStateRef.current = null;
    };

    const onDragEnd = (e: any) => {
      const ds = dragStateRef.current;
      if (!ds?.active) return;
      const lngLat = containerToLngLat(e);
      setDragDistance(null);
      dragOriginRef.current = null;
      cancelDrag();
      if (lngLat && ds) {
        const px = (e as any).point ?? map.project([lngLat.lng, lngLat.lat]);
        const pixelDx = Math.abs((px?.x ?? 0) - ds.startPoint.x);
        const pixelDy = Math.abs((px?.y ?? 0) - ds.startPoint.y);
        if (pixelDx > 8 || pixelDy > 8) {
          onFeatureDragEnd(ds.featureId, ds.layerId, lngLat.lng, lngLat.lat);
        }
      }
    };

    canvas.addEventListener('mousemove', onDragMove);
    canvas.addEventListener('mouseup', onDragEnd);
    canvas.addEventListener('mouseleave', cancelDrag);
    cleanupFns.push(() => {
      canvas.removeEventListener('mousemove', onDragMove);
      canvas.removeEventListener('mouseup', onDragEnd);
      canvas.removeEventListener('mouseleave', cancelDrag);
    });

    for (const layerData of layers) {
      if (!layerData.visible || layerData.features.length === 0) continue;
      if (layerData.geometryType !== 'Point') continue;
      if (!draggableLayerIds?.has(layerData.id)) continue;

      const dragLayerId = `ml-drag-${layerData.id}`;
      const layerId = `ml-lyr-${layerData.id}`;
      const sourceId = `ml-src-${layerData.id}`;
      const handleLayer = map.getLayer(dragLayerId) ? dragLayerId : layerId;

      const onDragStart = (e: any) => {
        if (!dragMode) return;
        e.preventDefault();
        const feature = e.features?.[0];
        if (!feature) return;
        const props = feature.properties;
        const fid = props?._id as string | undefined;
        const lid = props?._layer_id as string | undefined;
        if (!fid || !lid) return;

        let featureIndex = -1;
        try {
          const src = map.getSource(sourceId) as any;
          if (src?._data?.features) {
            featureIndex = src._data.features.findIndex(
              (f: any) => f.properties?._id === fid
            );
          }
        } catch {}
        if (featureIndex < 0) return;

        map.getCanvas().style.cursor = 'grabbing';
        dragOriginRef.current = { lng: e.lngLat.lng, lat: e.lngLat.lat };
        setDragDistance(null);

        dragStateRef.current = {
          active: true,
          featureId: fid,
          layerId: lid,
          sourceId,
          featureIndex,
          originalLng: e.lngLat.lng,
          originalLat: e.lngLat.lat,
          startPoint: e.point ? { x: e.point.x, y: e.point.y } : { x: 0, y: 0 },
        };

        if (!map.getLayer(`${layerId}-dragging`)) {
          try {
            map.addLayer({
              id: `${layerId}-dragging`,
              type: 'circle', source: sourceId,
              paint: { 'circle-radius': 14, 'circle-color': 'transparent', 'circle-stroke-width': 3, 'circle-stroke-color': '#0D5CFF', 'circle-stroke-opacity': 0.7 },
            });
          } catch {}
        }

        const origLayerId = `ml-orig-${sourceId}`;
        const origSourceId = `${sourceId}-origin`;
        try {
          if (!map.getSource(origSourceId)) {
            map.addSource(origSourceId, {
              type: 'geojson',
              data: { type: 'FeatureCollection', features: [{ type: 'Feature', geometry: { type: 'Point', coordinates: [e.lngLat.lng, e.lngLat.lat] }, properties: {} }] },
            });
          }
          if (!map.getLayer(origLayerId)) {
            map.addLayer({ id: origLayerId, type: 'circle', source: origSourceId,
              paint: { 'circle-radius': 10, 'circle-color': 'rgba(255, 255, 255, 0.5)', 'circle-stroke-width': 2, 'circle-stroke-color': '#ff6b6b', 'circle-stroke-opacity': 0.8, 'circle-opacity': 0.3 },
            });
          }
        } catch {}
      };

      try {
        map.on('mousedown', handleLayer, onDragStart);
        cleanupFns.push(() => { try { map.off('mousedown', handleLayer, onDragStart); } catch {} });
      } catch {}
    }

    return () => { for (const fn of cleanupFns) try { fn(); } catch {} };
  }, [layers, status, dragMode, draggableLayerIds, onFeatureDragEnd]);

  const applyVertexGeometryUpdate = useCallback((featureGeom: any, vertexIdx: number, lng: number, lat: number) => {
    if (!featureGeom) return null;

    if (featureGeom.type === 'LineString') {
      const coords = Array.isArray(featureGeom.coordinates) ? [...featureGeom.coordinates] : [];
      if (vertexIdx >= 0 && vertexIdx < coords.length) {
        coords[vertexIdx] = [lng, lat];
        return { ...featureGeom, coordinates: coords };
      }
    }

    if (featureGeom.type === 'Polygon') {
      const rings = Array.isArray(featureGeom.coordinates) ? [...featureGeom.coordinates] : [];
      if (rings.length > 0 && Array.isArray(rings[0])) {
        const outerRing = [...rings[0]] as [number, number][];
        if (vertexIdx >= 0 && vertexIdx < outerRing.length) {
          outerRing[vertexIdx] = [lng, lat];
          // GeoJSON linear rings must remain closed when an endpoint is moved.
          if (vertexIdx === 0 && outerRing.length > 1) {
            outerRing[outerRing.length - 1] = [lng, lat];
          } else if (vertexIdx === outerRing.length - 1 && outerRing.length > 1) {
            outerRing[0] = [lng, lat];
          }
          return { ...featureGeom, coordinates: [outerRing, ...rings.slice(1)] };
        }
      }
    }

    if (featureGeom.type === 'MultiPolygon') {
      const polygons = Array.isArray(featureGeom.coordinates) ? [...featureGeom.coordinates] : [];
      if (polygons.length > 0 && Array.isArray(polygons[0])) {
        const firstPolygon = [...polygons[0]] as [number, number][][];
        if (firstPolygon.length > 0 && Array.isArray(firstPolygon[0])) {
          const outerRing = [...firstPolygon[0]] as [number, number][];
          if (vertexIdx >= 0 && vertexIdx < outerRing.length) {
            outerRing[vertexIdx] = [lng, lat];
            // GeoJSON linear rings must remain closed when an endpoint is moved.
            if (vertexIdx === 0 && outerRing.length > 1) {
              outerRing[outerRing.length - 1] = [lng, lat];
            } else if (vertexIdx === outerRing.length - 1 && outerRing.length > 1) {
              outerRing[0] = [lng, lat];
            }
            const updatedFirstPolygon = [outerRing, ...firstPolygon.slice(1)] as [number, number][][];
            return { ...featureGeom, coordinates: [updatedFirstPolygon, ...polygons.slice(1)] };
          }
        }
      }
    }

    return null;
  }, []);

  const snapshotGeometryCoords = useCallback((featureGeom: any) => {
    if (!featureGeom) return undefined;
    if (featureGeom.type === 'LineString') {
      return Array.isArray(featureGeom.coordinates) ? featureGeom.coordinates.map((c: [number, number]) => [c[0], c[1]] as [number, number]) : undefined;
    }
    if (featureGeom.type === 'Polygon') {
      const firstRing = Array.isArray(featureGeom.coordinates?.[0]) ? featureGeom.coordinates[0] : [];
      return firstRing.map((c: [number, number]) => [c[0], c[1]] as [number, number]);
    }
    if (featureGeom.type === 'MultiPolygon') {
      const firstRing = Array.isArray(featureGeom.coordinates?.[0]?.[0]) ? featureGeom.coordinates[0][0] : [];
      return firstRing.map((c: [number, number]) => [c[0], c[1]] as [number, number]);
    }
    return undefined;
  }, []);

  // ── Vertex handles (web) ───────────────────────────────────────────────
  // The native renderer draws these declaratively from editHandleData; on web
  // they must be added to the maplibre style imperatively. Without this the
  // "drag vertex handles" affordance draws NOTHING and the drag effect below
  // has no ml-vert-drag-* layer to bind its mousedown listener to.
  // Hidden in whole-polygon Move mode (the corners stay put there), matching
  // the native renderer.
  const editHandleData = useMemo(
    () => (polygonMoveTarget ? null : buildEditHandleData(layers, vertexDragTarget ?? polygonEditTarget)),
    [layers, vertexDragTarget, polygonEditTarget, polygonMoveTarget],
  );
  const editHandleDataRef = useRef(editHandleData);
  editHandleDataRef.current = editHandleData;
  const editHandleSignature = useMemo(
    () => (editHandleData
      ? `${editHandleData.layerId}|${editHandleData.featureId}|${editHandleData.color}|${editHandleData.coords
          .map((c) => `${c[0].toFixed(7)},${c[1].toFixed(7)}`)
          .join(';')}`
      : null),
    [editHandleData],
  );

  useEffect(() => {
    const map = mapRef.current;
    if (!map || status !== 'ready') return;
    const data = editHandleDataRef.current;
    // Drop any previous handle set first so vertices from another feature
    // can never linger on the map.
    try { removeVertexMarkers(map); } catch {}
    if (!data) return;
    addVertexMarkers(map, data.featureId, data.layerId, data.coords, -1, data.color, 0);
    return () => {
      try { removeVertexMarkers(map); } catch {}
    };
  }, [status, editHandleSignature]);

  // ── Vertex drag effect (runs independently of dragMode) ────────────────
  useEffect(() => {
    const map = mapRef.current;
    const activeTarget = vertexDragTargetRef.current ?? polygonEditTargetRef.current;
    if (
      !map ||
      (!onVertexDragEndRef.current && !onPolygonVertexDragEndRef.current) ||
      !activeTarget ||
      status !== 'ready'
    ) return;

    const vt = activeTarget;
    const vertDragLayerId = `ml-vert-drag-${vt.layerId}-${vt.featureId}`;
    const vertSourceId = `ml-vert-src-${vt.layerId}-${vt.featureId}`;
    const parentSourceId = `ml-src-${vt.layerId}`;
    const canvas = map.getCanvas();
    const cleanupFns: (() => void)[] = [];


    const containerToLngLat = (e: any) => {
      if (e.lngLat) return e.lngLat;
      try {
        const rect = map.getContainer().getBoundingClientRect();
        return map.unproject([e.clientX - rect.left, e.clientY - rect.top]);
      } catch { return null; }
    };

    const onDragMove = (e: any) => {
      const ds = dragStateRef.current;
      if (!ds?.active || ds.vertexIdx === undefined) return;
      const lngLat = containerToLngLat(e);
      if (!lngLat) return;

      if (dragOriginRef.current) {
        const dist = haversineDistance(
          dragOriginRef.current.lng, dragOriginRef.current.lat,
          lngLat.lng, lngLat.lat
        );
        setDragDistance(Math.round(dist));
      }

      const src = map.getSource(ds.sourceId) as any;
      if (!src?._data?.features) return;
      try {
        const features = [...src._data.features];
        if (features[ds.featureIndex]?.geometry?.type === 'Point') {
          features[ds.featureIndex] = {
            ...features[ds.featureIndex],
            geometry: { ...features[ds.featureIndex].geometry, coordinates: [lngLat.lng, lngLat.lat] },
          };
        }
        src.setData({ type: 'FeatureCollection', features });

        // Update the parent feature geometry at the dragged vertex index
        try {
          const parentSrc = map.getSource(ds.parentSourceId!) as any;
          if (parentSrc?._data?.features) {
            const parentFeatures = [...parentSrc._data.features];
            const parentFeat = parentFeatures.find(
              (f: any) => (f.properties?._id === ds.featureId || f.properties?.id === ds.featureId)
            );
            if (parentFeat) {
              const updatedGeom = applyVertexGeometryUpdate(parentFeat.geometry, ds.vertexIdx, lngLat.lng, lngLat.lat);
              if (updatedGeom) {
                parentFeat.geometry = updatedGeom;
                parentSrc.setData({ type: 'FeatureCollection', features: parentFeatures });
              }
            }
          }
        } catch {}
      } catch {}
    };

    const cancelDrag = () => {
      const ds = dragStateRef.current;
      if (!ds?.active || ds.vertexIdx === undefined) return;
      try {
        const src = map.getSource(ds.sourceId) as any;
        if (src?._data?.features) {
          const features = [...src._data.features];
          if (features[ds.featureIndex]?.geometry?.type === 'Point') {
            features[ds.featureIndex] = {
              ...features[ds.featureIndex],
              geometry: { ...features[ds.featureIndex].geometry, coordinates: [ds.originalLng, ds.originalLat] },
            };
            src.setData({ type: 'FeatureCollection', features });
          }
        }
        // Restore parent line
        const parentSrc = map.getSource(ds.parentSourceId!) as any;
        if (parentSrc?._data?.features) {
          const parentFeatures = [...parentSrc._data.features];
          const parentFeat = parentFeatures.find(
            (f: any) => (f.properties?._id === ds.featureId || f.properties?.id === ds.featureId)
          );
          if (parentFeat?.geometry?.type === 'LineString') {
            const coords = [...parentFeat.geometry.coordinates];
            if (ds.initialCoords) {
              // Restore all coordinates from snapshot (rubber-band cancel)
              for (let i = 0; i < coords.length && i < ds.initialCoords.length; i++) {
                coords[i] = [ds.initialCoords[i][0], ds.initialCoords[i][1]];
              }
            } else {
              // Legacy: restore only the dragged vertex
              coords[ds.vertexIdx] = [ds.originalLng, ds.originalLat];
            }
            parentFeat.geometry = { ...parentFeat.geometry, coordinates: coords };
            parentSrc.setData({ type: 'FeatureCollection', features: parentFeatures });
          }
        }
      } catch {}
      try { map.getCanvas().style.cursor = ''; } catch {}
      try {
        const hlId = `ml-vert-hl-${ds.layerId}-${ds.featureId}`;
        if (map.getLayer(hlId)) map.removeLayer(hlId);
      } catch {}
      setDragDistance(null);
      dragOriginRef.current = null;
      dragStateRef.current = null;
    };

    const onDragEnd = (e: any) => {
      const ds = dragStateRef.current;
      if (!ds?.active || ds.vertexIdx === undefined) return;
      const lngLat = containerToLngLat(e);
      const vertexIdx = ds.vertexIdx;
      setDragDistance(null);
      dragOriginRef.current = null;

      // ── Keep the last drag position in the map sources ────────────
      // Do NOT call cancelDrag() here — that would restore the original
      // coordinates, snapping the line back AFTER the user released the
      // mouse. Instead, just clean up the drag state and cursor. The
      // parent LineString source already has the final position from
      // the last onDragMove event.
      try { map.getCanvas().style.cursor = ''; } catch {}
      try {
        const hlId = `ml-vert-hl-${ds.layerId}-${ds.featureId}`;
        if (map.getLayer(hlId)) map.removeLayer(hlId);
      } catch {}
      dragStateRef.current = null;

      if (lngLat && ds) {
        const px = (e as any).point ?? map.project([lngLat.lng, lngLat.lat]);
        const pixelDx = Math.abs((px?.x ?? 0) - ds.startPoint.x);
        const pixelDy = Math.abs((px?.y ?? 0) - ds.startPoint.y);
        if ((pixelDx > 8 || pixelDy > 8) && onVertexDragEndRef.current) {
          const isPolygonTarget = polygonEditTargetRef.current != null && vertexDragTargetRef.current == null;
          if (isPolygonTarget && onPolygonVertexDragEndRef.current) {
            onPolygonVertexDragEndRef.current(ds.featureId, ds.layerId, vertexIdx, lngLat.lng, lngLat.lat);
          } else if (onVertexDragEndRef.current) {
            onVertexDragEndRef.current(ds.featureId, ds.layerId, vertexIdx, lngLat.lng, lngLat.lat);
          }
        }
      }
    };

    // ── Hold gestures ───────────────────────────────────────────────────
    // A press that stays put for ~0.55 s acts on what is under it: a vertex
    // handle drops that vertex, the working copy gains a bend. Both are
    // hit-tested at press time, so this never depends on the drag state
    // surviving the hold; a moving press or a quick release cancels the
    // timer, which leaves drag, select and tap behaviour untouched.
    let holdTimer: any = null;
    let holdStart: { x: number; y: number } | null = null;
    const containerPoint = (e: any) => {
      const r = map.getContainer().getBoundingClientRect();
      return { x: e.clientX - r.left, y: e.clientY - r.top };
    };
    const cancelHold = () => {
      if (holdTimer) { clearTimeout(holdTimer); holdTimer = null; }
      holdStart = null;
    };
    const fireHold = (press: { x: number; y: number }) => {
      const hits = (layerId: string) => {
        try { return map.getLayer(layerId) ? map.queryRenderedFeatures([press.x, press.y], { layers: [layerId] }) : []; } catch { return []; }
      };
      // 1. a handle removes that vertex
      const vertexHits = hits(vertDragLayerId);
      if (vertexHits.length && onVertexLongPressRef.current) {
        const idx = (vertexHits[0].properties || {})._vertex_idx;
        if (typeof idx === 'number') {
          // Cancel the pending drag so a hold does not also move the line.
          dragStateRef.current = null;
          isVertexDragRef.current = false;
          setDragDistance(null);
          dragOriginRef.current = null;
          try { map.getCanvas().style.cursor = ''; } catch {}
          try {
            const hlId = `ml-vert-hl-${vt.layerId}-${vt.featureId}`;
            if (map.getLayer(hlId)) map.removeLayer(hlId);
          } catch {}
          onVertexLongPressRef.current(vt.featureId, vt.layerId, idx);
          return;
        }
      }
      // 2. the working copy itself gains a bend
      if (!onSegmentLongPressRef.current) return;
      const lineIds = [`ml-lyr-${vt.layerId}`, `ml-out-${vt.layerId}`].filter((id) => {
        try { return !!map.getLayer(id); } catch { return false; }
      });
      if (lineIds.length === 0) return;
      let lineHits: any[] = [];
      try { lineHits = map.queryRenderedFeatures([press.x, press.y], { layers: lineIds }); } catch { return; }
      if (!lineHits.length) return;
      const lngLat = map.unproject([press.x, press.y]);
      onSegmentLongPressRef.current(vt.featureId, vt.layerId, lngLat.lng, lngLat.lat);
    };
    const onHoldDown = (e: any) => {
      cancelHold();
      holdStart = containerPoint(e);
      const press = holdStart;
      holdTimer = setTimeout(() => {
        holdTimer = null;
        holdStart = null;
        fireHold(press);
      }, 550);
    };
    const onHoldMove = (e: any) => {
      if (!holdTimer || !holdStart) return;
      const p = containerPoint(e);
      if (Math.abs(p.x - holdStart.x) > 8 || Math.abs(p.y - holdStart.y) > 8) cancelHold();
    };
    canvas.addEventListener('mousedown', onHoldDown);
    canvas.addEventListener('mousemove', onHoldMove);
    canvas.addEventListener('mouseup', cancelHold);
    canvas.addEventListener('mouseleave', cancelHold);
    cleanupFns.push(() => {
      cancelHold();
      canvas.removeEventListener('mousedown', onHoldDown);
      canvas.removeEventListener('mousemove', onHoldMove);
      canvas.removeEventListener('mouseup', cancelHold);
      canvas.removeEventListener('mouseleave', cancelHold);
    });

    canvas.addEventListener('mousemove', onDragMove);
    canvas.addEventListener('mouseup', onDragEnd);
    canvas.addEventListener('mouseleave', cancelDrag);
    cleanupFns.push(() => {
      canvas.removeEventListener('mousemove', onDragMove);
      canvas.removeEventListener('mouseup', onDragEnd);
      canvas.removeEventListener('mouseleave', cancelDrag);
    });

    const onVertexDragStart = (e: any) => {
      e.preventDefault();
      const feature = e.features?.[0];
      if (!feature) return;
      const props = feature.properties;
      const fid = props?._id as string | undefined;
      const vIdx = props?._vertex_idx as number | undefined;
      const isVertex = props?._is_vertex === true;
      if (!fid || vIdx === undefined || !isVertex) return;

        // Find feature index in vertex marker source
        let featureIndex = -1;
        try {
          const src = map.getSource(vertSourceId) as any;
          if (src?._data?.features) {
            featureIndex = src._data.features.findIndex(
              (f: any) => f.properties?._id === fid
            );
          }
        } catch {}
        if (featureIndex < 0) return;

        // ── Snapshot initial coordinate array for rubber-band decay ──
        let initialCoords: [number, number][] | undefined;
        try {
          const parentSrc = map.getSource(parentSourceId) as any;
          if (parentSrc?._data?.features) {
            const parentFeat = parentSrc._data.features.find(
              (f: any) => (f.properties?._id === vt.featureId || f.properties?.id === vt.featureId)
            );
            initialCoords = snapshotGeometryCoords(parentFeat.geometry);
          }
        } catch {}

        isVertexDragRef.current = true;
        map.getCanvas().style.cursor = 'grabbing';

        dragStateRef.current = {
          active: true,
          featureId: vt.featureId,
          layerId: vt.layerId,
          sourceId: vertSourceId,
          featureIndex,
          originalLng: e.lngLat.lng,
          originalLat: e.lngLat.lat,
          startPoint: e.point ? { x: e.point.x, y: e.point.y } : { x: 0, y: 0 },
          vertexIdx: vIdx,
          parentSourceId,
          initialCoords,
        };

      };

      try {
        if (map.getLayer(vertDragLayerId)) {
          map.on('mousedown', vertDragLayerId, onVertexDragStart);
          cleanupFns.push(() => {
            try { map.off('mousedown', vertDragLayerId, onVertexDragStart); } catch {}
          });
        }
      } catch {}

    return () => {
      for (const fn of cleanupFns) try { fn(); } catch {}
    };
}, [status, vertexDragTarget, polygonEditTarget, onVertexDragEnd, onPolygonVertexDragEnd, applyVertexGeometryUpdate, snapshotGeometryCoords]);

  // ── Whole-polygon Move effect (web) — polygon body translates together ──
  // Mirrors the point/vertex drag: mousedown on the polygon's rendered layer
  // starts a translate; mousemove shifts every ring vertex by the same delta;
  // mouseup reports the cumulative delta to the parent.
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !polygonMoveTargetRef.current || !onPolygonMoveRef.current || status !== 'ready') return;

    const target = polygonMoveTargetRef.current;
    const fillLayerId = `ml-lyr-${target.layerId}`;
    const outlineId = `ml-out-${target.layerId}`;
    // The polygon may be rendered under the temp-preview-<layerId> id.
    const previewFillId = `ml-lyr-temp-preview-${target.layerId}`;
    const canvas = map.getCanvas();
    const cleanupFns: (() => void)[] = [];

    const containerToLngLat = (e: any) => {
      if (e.lngLat) return e.lngLat;
      try {
        const rect = map.getContainer().getBoundingClientRect();
        return map.unproject([e.clientX - rect.left, e.clientY - rect.top]);
      } catch { return null; }
    };

    const moveState = {
      active: false as boolean,
      featureId: '',
      layerId: '',
      startLng: 0,
      startLat: 0,
      cumLng: 0,
      cumLat: 0,
      startPoint: { x: 0, y: 0 },
    };

    const onMove = (e: any) => {
      if (!moveState.active) return;
      const lngLat = containerToLngLat(e);
      if (!lngLat) return;
      moveState.cumLng = lngLat.lng - moveState.startLng;
      moveState.cumLat = lngLat.lat - moveState.startLat;
      onPolygonMoveRef.current!(moveState.featureId, moveState.layerId, moveState.cumLng, moveState.cumLat);
    };

    const onUp = () => {
      if (!moveState.active) return;
      moveState.active = false;
      try { map.getCanvas().style.cursor = ''; } catch {}
      if ((Math.abs(moveState.cumLng) > 1e-9 || Math.abs(moveState.cumLat) > 1e-9) && onPolygonMoveEndRef.current) {
        onPolygonMoveEndRef.current(moveState.featureId, moveState.layerId, moveState.cumLng, moveState.cumLat);
      }
    };

    const onDown = (e: any) => {
      e.preventDefault();
      const feature = e.features?.[0];
      if (!feature) return;
      const props = feature.properties ?? {};
      const fid = props._id as string | undefined;
      const lid = props._layer_id as string | undefined;
      if (!fid || !lid) return;
      moveState.active = true;
      moveState.featureId = fid.replace(/^temp-preview-/, '');
      moveState.layerId = lid.replace(/^temp-preview-/, '');
      moveState.startLng = e.lngLat.lng;
      moveState.startLat = e.lngLat.lat;
      moveState.cumLng = 0;
      moveState.cumLat = 0;
      moveState.startPoint = e.point ? { x: e.point.x, y: e.point.y } : { x: 0, y: 0 };
      map.getCanvas().style.cursor = 'grabbing';
    };

    canvas.addEventListener('mousemove', onMove);
    canvas.addEventListener('mouseup', onUp);
    canvas.addEventListener('mouseleave', onUp);
    cleanupFns.push(() => {
      canvas.removeEventListener('mousemove', onMove);
      canvas.removeEventListener('mouseup', onUp);
      canvas.removeEventListener('mouseleave', onUp);
    });

    for (const layerId of [previewFillId, fillLayerId, outlineId]) {
      try {
        if (map.getLayer(layerId)) {
          map.on('mousedown', layerId, onDown);
          cleanupFns.push(() => {
            try { map.off('mousedown', layerId, onDown); } catch {}
          });
        }
      } catch {}
    }

    return () => {
      for (const fn of cleanupFns) try { fn(); } catch {}
    };
  }, [status, polygonMoveTarget, onPolygonMove, onPolygonMoveEnd]);

  // ── Fly-to imported center ────────────────────────────────────────────
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !flyToCenter || status !== 'ready') return;
    try {
      map.flyTo({ center: [flyToCenter.lng, flyToCenter.lat], zoom: flyToCenter.zoom, duration: 1200 });
    } catch {}
  }, [flyToCenter?.lng, flyToCenter?.lat, flyToCenter?.zoom, status]);

  // ── Fly-to user GPS location (crosshair FAB) ──────────────────────────
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !flyToUserTarget || status !== 'ready') return;
    try {
      map.flyTo({ center: [flyToUserTarget.lng, flyToUserTarget.lat], zoom: flyToUserTarget.zoom, duration: 1000 });
    } catch {}
  }, [flyToUserTarget?.ts, status]);

  // ── Fly-to selected feature ────────────────────────────────────────────
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !selectedFeatureId) return;

    for (const layerData of layers) {
      for (const feature of layerData.features) {
        const fid = (feature.properties?.id as string) ?? (feature.properties?._id as string);
        if (fid === selectedFeatureId) {
          const coords = feature.geometry.coordinates;
          const center: [number, number] =
            feature.geometry.type === 'Point'
              ? [(coords as number[])[0], (coords as number[])[1]]
              : [((coords as unknown[][])[0] as number[])?.[0] ?? 0, ((coords as unknown[][])[0] as number[])?.[1] ?? 0];
          try { map.flyTo({ center, zoom: 17, duration: 800 }); } catch {}
          return;
        }
      }
    }
  }, [selectedFeatureId, layers, status]);

  const containerStyle: any = { width: '100%', minHeight: 300 };
  if (height !== undefined) containerStyle.height = height;

  return (
    <View style={containerStyle}>
      <div ref={containerRef} style={{ width: '100%', height: '100%', minHeight: 300 }} />

      {status === 'loading' && (
        <LoadingOverlay
          message={
            retryCountRef.current > 0
              ? `Retrying... (attempt ${retryCountRef.current})`
              : 'Loading map...'
          }
          progress={loadProgress}
        />
      )}

      {status === 'timeout' && (
        <ErrorOverlay
          error={{ type: 'timeout', message: 'Map did not load within the expected time.' }}
          onRetry={() => {
            retryCountRef.current += 1;
            setStatus('loading');
            setLoadProgress(undefined);
            setMapKey((k) => k + 1);
          }}
        />
      )}

      {status === 'error' && (
        <ErrorOverlay
          error={errorInfo}
          onRetry={() => {
            retryCountRef.current += 1;
            setStatus('loading');
            setLoadProgress(undefined);
            setMapKey((k) => k + 1);
          }}
        />
      )}

      {/* Drag Distance Display — shown during point drag */}
      {dragDistance !== null && (
        <View style={styles.dragDistanceOverlay}>
          <View style={styles.dragDistanceCard}>
            <Text style={styles.dragDistanceIcon}>↕️</Text>
            <View style={{ flexDirection: 'row', alignItems: 'baseline' }}>
              <Text style={styles.dragDistanceValue}>{dragDistance}</Text>
              <Text style={styles.dragDistanceUnit}>m</Text>
            </View>
          </View>
        </View>
      )}

      {status === 'ready' && isEmpty && <EmptyOverlay emptyState={emptyState} />}
    </View>
  );
}

// ── Main Export ──────────────────────────────────────────────────────────

function NativeMapUnavailableView({ isExpoGo }: { isExpoGo: boolean }) {
  const colors = useThemeStore((s) => s.colors);
  return (
    <View style={[styles.errorContainer, { minHeight: 300 }]}>
      <View style={styles.errorIconCircle}>
        <Package size={30} stroke={colors.error} />
      </View>
      <Text style={styles.errorTitle}>Map Library Not Available</Text>
      <Text style={styles.errorDescription}>
        {isExpoGo
          ? 'The map engine (MapLibre) is not included in Expo Go. Install the development build of this app instead: connect your phone and run `npx expo run:android`, or install an APK built with EAS (`eas build -p android --profile preview`).'
          : 'The MapLibre native module could not be loaded. Rebuild the app with `npx expo run:android` or `eas build -p android --profile preview` and install the new APK.'}
      </Text>
    </View>
  );
}

export default function MapLibreMap(props: MapLibreMapProps) {
  if (IS_NATIVE) {
    return <NativeMapView {...props} />;
  }
  if (Platform.OS === 'web') {
    return <WebMapView {...props} />;
  }
  // Native platform without the native module (e.g. Expo Go or a stale
  // build) — never attempt the DOM-based WebMapView here.
  return <NativeMapUnavailableView isExpoGo={IS_EXPO_GO} />;
}

// ── Shared Styles ─────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  // ── Overlay Base ────────────────────────────────────────────────────────
  overlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(247, 249, 252, 0.92)',
    zIndex: 10,
  },

  // ── Loading Card ────────────────────────────────────────────────────────
  loadingCard: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 40,
    paddingVertical: 32,
    borderRadius: 20,
    backgroundColor: '#FFFFFF',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.12,
    shadowRadius: 12,
    elevation: 8,
    minWidth: 220,
  },
  mapIconContainer: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: '#EEF2FF',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 16,
  },
  mapIconLarge: { fontSize: 28 },
  loadingDots: {
    flexDirection: 'row',
    gap: 6,
    marginBottom: 16,
  },
  dot: {
    width: 10,
    height: 10,
    borderRadius: 5,
  },
  loadingTitle: {
    fontSize: 17,
    fontWeight: '700',
    color: '#1F2937',
    marginBottom: 4,
  },
  loadingHint: {
    fontSize: 12,
    color: '#9CA3AF',
    marginTop: 8,
    fontWeight: '400',
  },
  progressContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginTop: 8,
    width: '100%',
  },
  progressTrack: {
    flex: 1,
    height: 4,
    backgroundColor: '#E5E7EB',
    borderRadius: 2,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    backgroundColor: '#0D5CFF',
    borderRadius: 2,
  },
  progressText: {
    fontSize: 11,
    fontWeight: '600',
    color: '#6B7280',
    minWidth: 32,
    textAlign: 'right',
  },

  // ── Error Card ──────────────────────────────────────────────────────────
  errorCard: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 32,
    paddingVertical: 28,
    borderRadius: 20,
    backgroundColor: '#FFFFFF',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.12,
    shadowRadius: 12,
    elevation: 8,
    maxWidth: 300,
  },
  errorContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(247, 249, 252, 0.9)',
    gap: 12,
  },
  errorIconCircle: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: '#FEF2F2',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
  },
  errorIconLarge: { fontSize: 24 },
  errorTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#1F2937',
    marginBottom: 6,
    textAlign: 'center',
  },
  errorDescription: {
    fontSize: 13,
    color: '#6B7280',
    textAlign: 'center',
    lineHeight: 19,
    marginBottom: 8,
    paddingHorizontal: 8,
  },
  tipContainer: {
    backgroundColor: '#FFFBEB',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 8,
    marginBottom: 12,
  },
  tipText: {
    fontSize: 12,
    color: '#92400E',
    fontWeight: '500',
  },
  retryButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 12,
    marginTop: 4,
    minWidth: 160,
    minHeight: 48,
  },
  retryButtonText: {
    fontSize: 14,
    fontWeight: '700',
    color: '#FFFFFF',
    letterSpacing: 0.3,
  },

  // ── Empty State Card ────────────────────────────────────────────────────
  emptyCard: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 32,
    paddingVertical: 24,
    borderRadius: 20,
    backgroundColor: '#FFFFFF',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.10,
    shadowRadius: 10,
    elevation: 6,
    maxWidth: 280,
  },
  emptyIconContainer: {
    position: 'relative',
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: '#F3F4F6',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
  },
  emptyIcon: { fontSize: 24 },
  emptyIconBadge: {
    position: 'absolute',
    top: -2,
    right: -2,
    width: 20,
    height: 20,
    borderRadius: 10,
    backgroundColor: '#9CA3AF',
    alignItems: 'center',
    justifyContent: 'center',
  },
  emptyBadgeText: { fontSize: 11, fontWeight: '700', color: '#FFFFFF' },
  // ── Drag Distance Overlay ────────────────────────────────────────────
  dragDistanceOverlay: {
    position: 'absolute',
    top: 12,
    left: 0,
    right: 0,
    alignItems: 'center',
    zIndex: 100,
    pointerEvents: 'none',
  },
  dragDistanceCard: {
    backgroundColor: '#1F2937',
    borderRadius: 20,
    paddingHorizontal: 14,
    paddingVertical: 8,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 6,
  },
  dragDistanceIcon: {
    fontSize: 14,
  },
  dragDistanceValue: {
    fontSize: 18,
    fontWeight: '700',
    color: '#FFFFFF',
  },
  dragDistanceUnit: {
    fontSize: 13,
    fontWeight: '500',
    color: '#9CA3AF',
    marginLeft: 2,
  },
  emptyTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1F2937',
    marginBottom: 4,
    textAlign: 'center',
  },
  emptyDescription: {
    fontSize: 12,
    color: '#6B7280',
    textAlign: 'center',
    lineHeight: 18,
  },
  errorText: { fontSize: 13, color: '#6B7280', textAlign: 'center', paddingHorizontal: 40, lineHeight: 18 },
});
