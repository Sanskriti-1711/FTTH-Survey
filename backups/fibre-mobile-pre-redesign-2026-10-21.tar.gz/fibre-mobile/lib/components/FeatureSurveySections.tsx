// ── Feature Survey Sections ─────────────────────────────────-------------
// Reusable component that renders all survey editing modules for a feature:
//  - Trench Classification
//  - Risk Assessment
//  - Hazards
//  - Field Evidence
//  - Survey Status & Notes
//  - Change History
//
// Used by: feature/[featureId].tsx detail screen

import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  ScrollView,
} from 'react-native';
import { useThemeStore } from '../stores/theme';
import { useSurveyStore } from '../stores/survey';
import { useSurveyFeaturesStore } from '../stores/survey-features';
import { router } from 'expo-router';
import {
  Camera, Ruler, ClipboardList, CheckCircle, Flag,
  ChevronRight, AlertTriangle,
} from 'lucide-react-native';
import { Spacing, Radius } from '../theme/colors';
import { Button } from '../../components/ui/Button';
import { Toast } from '../../components/ui/Toast';

// ── Constants ─────────────────────────────────────────────────────────────

type TrenchType =
  | 'new_trench' | 'existing_duct' | 'existing_trench' | 'existing_fibre_route'
  | 'existing_openreach_duct' | 'existing_virgin_duct' | 'hdd_bore'
  | 'mole_plough' | 'micro_trench' | 'surface_mounted' | 'pole_route';

interface TrenchTypeInfo {
  label: string;
  color: string;
  icon: string;
}

const TRENCH_TYPES: Record<TrenchType, TrenchTypeInfo> = {
  new_trench: { label: 'New Trench', color: '#E74C3C', icon: '⛏️' },
  existing_duct: { label: 'Existing Duct', color: '#2ECC71', icon: '🔌' },
  existing_trench: { label: 'Existing Trench', color: '#3498DB', icon: '🔄' },
  existing_fibre_route: { label: 'Existing Fibre', color: '#9B59B6', icon: '🔗' },
  existing_openreach_duct: { label: 'Openreach Duct', color: '#1ABC9C', icon: '📡' },
  existing_virgin_duct: { label: 'Virgin Duct', color: '#E67E22', icon: '📺' },
  hdd_bore: { label: 'HDD Bore', color: '#F39C12', icon: '🔩' },
  mole_plough: { label: 'Mole Plough', color: '#8E44AD', icon: '🚜' },
  micro_trench: { label: 'Micro Trench', color: '#2C3E50', icon: '🔧' },
  surface_mounted: { label: 'Surface Mounted', color: '#7F8C8D', icon: '📐' },
  pole_route: { label: 'Pole Route', color: '#795548', icon: '🏗️' },
};

// Values match the backend RiskAssessment.RiskCategory choices (snake_case);
// labels are what the engineer sees. Sending labels to the API used to fail
// validation (DRF ChoiceField rejects display labels), so saves silently 400'd.
const RISK_CATEGORIES = [
  { value: 'traffic', label: 'Traffic' },
  { value: 'pedestrian', label: 'Pedestrian' },
  { value: 'private_land', label: 'Private Land' },
  { value: 'tree_roots', label: 'Tree Roots' },
  { value: 'concrete_surface', label: 'Concrete Surface' },
  { value: 'railway', label: 'Railway' },
  { value: 'bridge', label: 'Bridge' },
  { value: 'river', label: 'River' },
  { value: 'protected_area', label: 'Protected Area' },
  { value: 'environmental', label: 'Environmental' },
  { value: 'gas_line', label: 'Gas Line' },
  { value: 'water_main', label: 'Water Main' },
  { value: 'electric_cable', label: 'Electric Cable' },
  { value: 'telecom', label: 'Telecom' },
  { value: 'asbestos', label: 'Asbestos' },
  { value: 'confined_space', label: 'Confined Space' },
];

const SEVERITY_LEVELS = ['low', 'medium', 'high', 'critical'] as const;
const PROBABILITY_LEVELS = ['rare', 'possible', 'likely', 'certain'] as const;

const HAZARD_TYPES = [
  { value: 'working_at_height', label: 'Working at Height' },
  { value: 'confined_space', label: 'Confined Space' },
  { value: 'excavation', label: 'Excavation' },
  { value: 'traffic_management', label: 'Traffic Management' },
  { value: 'high_voltage', label: 'High Voltage' },
  { value: 'flood_risk', label: 'Flood Risk' },
  { value: 'dog', label: 'Dog' },
  { value: 'aggressive_resident', label: 'Aggressive Resident' },
  { value: 'private_security', label: 'Private Security' },
  { value: 'environmental', label: 'Environmental Protection' },
  { value: 'tree_order', label: 'Tree Preservation Order' },
];

const MITIGATION_TEMPLATES = [
  { value: 'traffic_lights', label: 'Traffic Lights' },
  { value: 'temp_barriers', label: 'Temporary Barriers' },
  { value: 'road_closure', label: 'Road Closure' },
  { value: 'permit', label: 'Permit' },
  { value: 'hdd', label: 'HDD' },
  { value: 'night_work', label: 'Night Work' },
  { value: 'police_assist', label: 'Police Assistance' },
  { value: 'tree_officer', label: 'Tree Officer Approval' },
  { value: 'env_approval', label: 'Environmental Approval' },
  { value: 'utility_locate', label: 'Utility Locate' },
  { value: 'cat_scan', label: 'CAT Scan' },
  { value: 'trial_hole', label: 'Trial Hole' },
];

const SURVEY_STATUS_FLOW = [
  'not_started', 'visited', 'verified', 'modified',
  'needs_review', 'rejected', 'approved', 'completed',
] as const;

/** Format an ISO timestamp as a short date for the "Saved …" badge */
function formatSavedDate(iso: string): string {
  try {
    return new Date(iso).toLocaleDateString(undefined, {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
    });
  } catch {
    return iso.slice(0, 10);
  }
}

// ── Props ─────────────────────────────────────────────────────────────────

interface Props {
  featureId: string;
  layerId: string;
  /** Current feature geometry (used to create the SurveyFeature record when
   *  the engineer writes network attributes without a geometry change). */
  initialGeometry?: Record<string, unknown> | null;
}

// ── Color Helpers ─────────────────────────────────────────────────────────

function getSeverityColor(severity: string) {
  switch (severity) {
    case 'low': return { bg: '#27AE6020', text: '#27AE60' };
    case 'medium': return { bg: '#F39C1220', text: '#F39C12' };
    case 'high': return { bg: '#E74C3C20', text: '#E74C3C' };
    case 'critical': return { bg: '#8E44AD20', text: '#8E44AD' };
    default: return { bg: '#95A5A620', text: '#95A5A6' };
  }
}

function getProbabilityColor(prob: string) {
  switch (prob) {
    case 'rare': return { bg: '#3498DB20', text: '#3498DB' };
    case 'possible': return { bg: '#F39C1220', text: '#F39C12' };
    case 'likely': return { bg: '#E67E2220', text: '#E67E22' };
    case 'certain': return { bg: '#E74C3C20', text: '#E74C3C' };
    default: return { bg: '#95A5A620', text: '#95A5A6' };
  }
}

// ── Component ─────────────────────────────────────────────────────────────

export default function FeatureSurveySections({ featureId, layerId, initialGeometry }: Props) {
  const colors = useThemeStore((s) => s.colors);
  const store = useSurveyStore();

  const [activeModule, setActiveModule] = useState<string | null>(null);
  const [toastVisible, setToastVisible] = useState(false);
  const [toastMsg, setToastMsg] = useState('');
  const [toastType, setToastType] = useState<'success' | 'error'>('success');

  const showToast = (msg: string, type: 'success' | 'error' = 'success') => {
    setToastMsg(msg);
    setToastType(type);
    setToastVisible(true);
  };

  // Trench Module
  const [selectedTrenchType, setSelectedTrenchType] = useState<TrenchType | null>(null);
  const [trenchAttrs, setTrenchAttrs] = useState({
    depth: '', width: '', surface_type: '',
    road_crossing: false, footpath_crossing: false, rail_crossing: false,
    river_crossing: false, private_property: false, traffic_sensitive: false,
    permit_required: false, notes: '',
  });

  // Risk Module
  const [riskCategory, setRiskCategory] = useState('');
  const [riskSeverity, setRiskSeverity] = useState<string>('medium');
  const [riskProbability, setRiskProbability] = useState<string>('possible');
  const [riskMitigation, setRiskMitigation] = useState('');
  const [riskNotes, setRiskNotes] = useState('');

  // Hazard Module
  const [selectedHazard, setSelectedHazard] = useState('');
  const [hazardMitigation, setHazardMitigation] = useState('');
  const [hazardNotes, setHazardNotes] = useState('');

  // Evidence Module
  const [evidenceDescription, setEvidenceDescription] = useState('');
  const [evidenceWeather, setEvidenceWeather] = useState('');

  // Network Attributes Module (trench class / duct capacity / cable / aerial)
  // These values ride in survey_attributes so LLD's _survey_capacity(props),
  // Mode A trench mirroring, the brownfield fibre register and the
  // aerial-drop planner can read the engineer's field observation.
  // Standardized engine keys:
  //   trench  -> trench_type (Feeder | Distribution | Garden)
  //   duct    -> duct_type (single|twin|quad), capacity_total, spare_capacity
  //              (%), occupied, condition (good|partial|blocked|collapsed)
  //   cable   -> cable_type (Feeder | Distribution), fiber_count / fibre_count
  //              / capacity_total (strands per cable)
  //   premise -> aerial_required (bool)
  const [netTrenchClass, setNetTrenchClass] = useState(''); // Feeder|Distribution|Garden
  const [netDuctType, setNetDuctType] = useState('');       // single|twin|quad
  const [netCableType, setNetCableType] = useState('');     // Feeder|Distribution
  const [netFiberCount, setNetFiberCount] = useState('');   // strands per cable
  const [netCapacity, setNetCapacity] = useState('');
  const [netSpare, setNetSpare] = useState('');
  const [netOccupied, setNetOccupied] = useState(false);
  const [netCondition, setNetCondition] = useState('');
  const [netAerial, setNetAerial] = useState(false);

  // Status Module
  const [surveyStatus, setSurveyStatus] = useState<string>('not_started');
  const [fieldNotes, setFieldNotes] = useState('');

  // ── Previously-saved data (prefill) ───────────────────────────────────
  // Each module's form is backed by a dedicated backend record (trench,
  // risk, hazard, evidence, status). On mount we fetch the feature's
  // existing records and pre-fill the form states so engineers continue
  // their survey instead of re-entering everything from scratch. The
  // "Saved <date>" chip next to a module title indicates data was loaded.
  const [savedDates, setSavedDates] = useState<{
    trench?: string;
    risk?: string;
    hazard?: string;
    evidence?: string;
    status?: string;
    network?: string;
  }>({});

  useEffect(() => {
    let cancelled = false;

    (async () => {
      if (!featureId) return;
      try {
        // ── Reset module states first so a reused component instance never
        //    shows the previous feature's values (e.g. featureId changed).
        setSelectedTrenchType(null);
        setTrenchAttrs({ depth: '', width: '', surface_type: '', road_crossing: false, footpath_crossing: false, rail_crossing: false, river_crossing: false, private_property: false, traffic_sensitive: false, permit_required: false, notes: '' });
        setRiskCategory('');
        setRiskSeverity('medium');
        setRiskProbability('possible');
        setRiskMitigation('');
        setRiskNotes('');
        setSelectedHazard('');
        setHazardMitigation('');
        setHazardNotes('');
        setEvidenceDescription('');
        setEvidenceWeather('');
        setSurveyStatus('not_started');
        setFieldNotes('');
        setNetTrenchClass('');
        setNetDuctType('');
        setNetCableType('');
        setNetFiberCount('');
        setNetCapacity('');
        setNetSpare('');
        setNetOccupied(false);
        setNetCondition('');
        setNetAerial(false);
        setSavedDates({});

        // Fire all fetchers in parallel; each is independent.
        await Promise.allSettled([
          store.fetchTrenchSurveys(featureId),
          store.fetchRisks(featureId),
          store.fetchHazards(featureId),
          store.fetchEvidence(featureId),
          store.fetchStatuses(featureId),
          store.fetchChanges(featureId),
        ]);
        if (cancelled) return;

        const st = useSurveyStore.getState();
        const saved: NonNullable<typeof savedDates> = {};

        // ── Trench ──
        const trench = st.trenchSurveys
          .filter((t) => t.feature === featureId)
          .sort((a, b) => b.created_at.localeCompare(a.created_at))[0];
        if (trench) {
          const tt = trench.trench_type as TrenchType;
          if (TRENCH_TYPES[tt]) setSelectedTrenchType(tt);
          setTrenchAttrs({
            depth: trench.depth_mm != null ? String(trench.depth_mm) : '',
            width: trench.width_mm != null ? String(trench.width_mm) : '',
            surface_type: trench.surface_type ?? '',
            road_crossing: trench.road_crossing,
            footpath_crossing: trench.footpath_crossing,
            rail_crossing: trench.rail_crossing,
            river_crossing: trench.river_crossing,
            private_property: trench.private_property,
            traffic_sensitive: trench.traffic_sensitive,
            permit_required: trench.permit_required,
            notes: trench.notes ?? '',
          });
          saved.trench = formatSavedDate(trench.created_at);
        }

        // ── Risk ──
        const risk = st.riskAssessments
          .filter((r) => r.feature === featureId)
          .sort((a, b) => b.created_at.localeCompare(a.created_at))[0];
        if (risk) {
          setRiskCategory(risk.category ?? '');
          setRiskSeverity(risk.severity ?? 'medium');
          setRiskProbability(risk.probability ?? 'possible');
          setRiskMitigation(risk.mitigation ?? '');
          setRiskNotes(risk.notes ?? '');
          saved.risk = formatSavedDate(risk.created_at);
        }

        // ── Hazard ──
        const hazard = st.hazards
          .filter((h) => h.feature === featureId)
          .sort((a, b) => b.created_at.localeCompare(a.created_at))[0];
        if (hazard) {
          setSelectedHazard(hazard.hazard_type ?? '');
          setHazardMitigation(hazard.mitigation_template ?? '');
          setHazardNotes(hazard.notes ?? '');
          saved.hazard = formatSavedDate(hazard.created_at);
        }

        // ── Evidence ──
        const evidence = st.evidence
          .filter((e) => e.feature === featureId)
          .sort((a, b) => b.created_at.localeCompare(a.created_at))[0];
        if (evidence) {
          setEvidenceDescription(evidence.description ?? '');
          setEvidenceWeather(evidence.weather ?? '');
          saved.evidence = formatSavedDate(evidence.created_at);
        }

        // ── Status ──
        const status = st.statuses
          .filter((s) => s.feature === featureId)
          .sort((a, b) => b.created_at.localeCompare(a.created_at))[0];
        if (status) {
          setSurveyStatus(status.status ?? 'not_started');
          setFieldNotes(status.notes ?? '');
          saved.status = formatSavedDate(status.created_at);
        }

        setSavedDates(saved);
        console.log('[SurveySections] Pre-filled survey data for feature', featureId.slice(-8));
      } catch (err) {
        console.warn('[SurveySections] Failed to pre-fill survey data:', err);
      }
    })();

    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [featureId]);

  // ── Handlers ─────────────────────────────────────────────────────────

  /**
   * Resolve a real backend projects.Feature UUID for the survey API calls.
   * The detail screen can pass a synthetic id ("imp-feat-<layer>-<n>") or a
   * SurveyFeature UUID; the survey endpoints require a real HLD feature UUID.
   * Returns null when no backend feature is linked (e.g. a purely local
   * imported feature with no survey copy yet) — callers must not save.
   */
  const resolveBackendFeatureId = (): string | null => {
    const id = (featureId || '').trim();
    const isUuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
    // 1. Survey-features store FIRST: a survey copy's own id must resolve to
    //    its original HLD feature id. The survey endpoints (trenches/risks/
    //    hazards/status) key on the projects.Feature UUID, not the
    //    SurveyFeature UUID — saving with the copy's id 400s with an invalid pk.
    const st = useSurveyFeaturesStore.getState();
    for (const list of Object.values(st.surveyFeatures)) {
      const sf = list.find((s) => s.id === id);
      if (sf) {
        const hldId = sf.original_hld_feature || sf.hld_feature_id;
        // Engineer-created copy with no HLD link: nothing to attach typed data to.
        return hldId || null;
      }
    }
    // 2. Genuine HLD feature UUID → use as-is.
    if (isUuid.test(id)) return id;
    // 3. Synthetic id ("imp-feat-<layer>-<n>"): an existing survey copy records
    //    the original HLD feature id (the real UUID) even when the route param
    //    is synthetic.
    for (const list of Object.values(st.surveyFeatures)) {
      const sf = list.find(
        (s) => s.original_hld_feature === id || s.hld_feature_id === id
      );
      if (sf) {
        const hldId = sf.original_hld_feature || sf.hld_feature_id;
        if (hldId) return hldId;
      }
    }
    return null;
  };

  /** Guard used by every save handler: resolves the backend UUID or bails
   *  with a clear toast instead of a silent 400 from the API. */
  const requireBackendFeature = (): string | null => {
    const backendId = resolveBackendFeatureId();
    if (!backendId) {
      showToast('This feature has no backend record yet — open it from the map to save survey data', 'error');
    }
    return backendId;
  };

  const handleSaveTrench = async () => {
    if (!selectedTrenchType) return;
    const backendId = requireBackendFeature();
    if (!backendId) return;
    try {
      await store.saveTrenchSurvey({
        feature: backendId,
        trench_type: selectedTrenchType,
        depth_mm: trenchAttrs.depth ? parseInt(trenchAttrs.depth) : null,
        width_mm: trenchAttrs.width ? parseInt(trenchAttrs.width) : null,
        surface_type: trenchAttrs.surface_type || null,
        construction_method: null,
        road_crossing: trenchAttrs.road_crossing,
        footpath_crossing: trenchAttrs.footpath_crossing,
        rail_crossing: trenchAttrs.rail_crossing,
        river_crossing: trenchAttrs.river_crossing,
        private_property: trenchAttrs.private_property,
        traffic_sensitive: trenchAttrs.traffic_sensitive,
        permit_required: trenchAttrs.permit_required,
        notes: trenchAttrs.notes,
      });
      showToast('Trench classification saved', 'success');
      setSavedDates((p) => ({ ...p, trench: formatSavedDate(new Date().toISOString()) }));
      setActiveModule(null);
    } catch { showToast('Failed to save trench', 'error'); }
  };

  const handleSaveRisk = async () => {
    if (!riskCategory) return;
    const backendId = requireBackendFeature();
    if (!backendId) return;
    try {
      await store.saveRisk({
        feature: backendId,
        category: riskCategory,
        severity: riskSeverity as any,
        probability: riskProbability as any,
        mitigation: riskMitigation,
        notes: riskNotes,
        status: 'open',
      });
      showToast('Risk assessment saved', 'success');
      setSavedDates((p) => ({ ...p, risk: formatSavedDate(new Date().toISOString()) }));
      setActiveModule(null);
    } catch { showToast('Failed to save risk', 'error'); }
  };

  const handleSaveHazard = async () => {
    if (!selectedHazard) return;
    const backendId = requireBackendFeature();
    if (!backendId) return;
    try {
      await store.saveHazard({
        feature: backendId,
        hazard_type: selectedHazard,
        mitigation_template: hazardMitigation || null,
        notes: hazardNotes,
        is_active: true,
      });
      showToast('Hazard recorded', 'success');
      setSavedDates((p) => ({ ...p, hazard: formatSavedDate(new Date().toISOString()) }));
      setActiveModule(null);
    } catch { showToast('Failed to save hazard', 'error'); }
  };

  const handleSaveEvidence = async () => {
    const backendId = requireBackendFeature();
    if (!backendId) return;
    try {
      await store.saveEvidence({
        feature: backendId,
        evidence_type: 'measurement',
        description: evidenceDescription,
        weather: evidenceWeather,
        captured_at: new Date().toISOString(),
      });
      showToast('Field evidence saved', 'success');
      setSavedDates((p) => ({ ...p, evidence: formatSavedDate(new Date().toISOString()) }));
      setEvidenceDescription('');
      setEvidenceWeather('');
      setActiveModule(null);
    } catch { showToast('Failed to save evidence', 'error'); }
  };

  const handleUpdateStatus = async () => {
    const backendId = requireBackendFeature();
    if (!backendId) return;
    try {
      await store.updateStatus(backendId, surveyStatus, fieldNotes);
      showToast('Status updated to ' + surveyStatus.replace(/_/g, ' '), 'success');
      setSavedDates((p) => ({ ...p, status: formatSavedDate(new Date().toISOString()) }));
    } catch { showToast('Failed to update status', 'error'); }
  };

  const isTrenchLayer = layerId === 'trenches' || layerId.includes('trench');
  const isDuctLayer = layerId.includes('duct');
  const isCableLayer = layerId.includes('cable');
  const isPremiseLayer = layerId.includes('premise') || layerId.includes('object') || layerId.includes('polygon') || layerId === 'premises';

  // ── Network attributes: merge capacity/condition/aerial into the survey
  //    features store (survey_attributes), creating the record if needed ──
  const handleSaveNetworkAttrs = async () => {
    const backendId = requireBackendFeature();
    if (!backendId) return;
    try {
      const sfStore = useSurveyFeaturesStore.getState();
      const existing = sfStore.getSurveyFeatureForHld(backendId);
      const attrs: Record<string, unknown> = {
        ...(existing?.survey_attributes ?? {}),
      };
      if (isTrenchLayer) {
        // LLD trench classification — Feeder | Distribution | Garden. This is
        // the key Mode A/B read for mirroring garden trenches into final_trenches
        // and for BOQ/construction planning. Distinct from the construction type
        // (new_trench / existing_duct …) captured in the Trench module above.
        if (netTrenchClass) attrs.trench_type = netTrenchClass;
      }
      if (isDuctLayer) {
        if (netDuctType) attrs.duct_type = netDuctType;
        if (netCapacity) attrs.capacity_total = parseInt(netCapacity, 10);
        if (netSpare) attrs.spare_capacity = parseInt(netSpare, 10);
        attrs.occupied = netOccupied;
        if (netCondition) attrs.condition = netCondition;
      }
      if (isCableLayer) {
        // Fibre count is PER CABLE (strands in that one physical cable), not
        // per bundle — Feeder 288, Distribution >= 48 sized by households
        // served, Garden 12. Written under every spelling the brownfield
        // fibre register reads (capacity_total / fibre_count / fiber_count).
        if (netCableType) attrs.cable_type = netCableType;
        if (netFiberCount) {
          const strands = parseInt(netFiberCount, 10);
          if (!isNaN(strands) && strands > 0) {
            attrs.fiber_count = strands;
            attrs.fibre_count = strands;
            attrs.capacity_total = strands;
          }
        }
      }
      if (isPremiseLayer || isDuctLayer) {
        attrs.aerial_required = netAerial;
      }
      if (existing) {
        await sfStore.updateSurveyFeature(existing.id, layerId, {
          survey_attributes: attrs,
          survey_status: existing.survey_status === 'new' ? 'new' : ('modified' as const),
        });
      } else {
        await sfStore.upsertSurveyFeature(
          backendId,
          layerId,
          layerId.replace(/_/g, ' ').replace(/^./, (c) => c.toUpperCase()),
          (initialGeometry ?? { type: 'Point', coordinates: [0, 0] }) as Record<string, unknown>,
          attrs,
          initialGeometry ?? null,
          {},
          'Captured network attributes',
        );
      }
      showToast('Network attributes saved', 'success');
      setSavedDates((p) => ({ ...p, network: formatSavedDate(new Date().toISOString()) }));
      setActiveModule(null);
    } catch (err) {
      const m = err instanceof Error ? err.message : 'Failed to save network attributes';
      showToast(m, 'error');
    }
  };

  // ── Prefill network attrs from an existing survey feature ──
  useEffect(() => {
    const sf = useSurveyFeaturesStore.getState().getSurveyFeatureForHld(featureId);
    const a = (sf?.survey_attributes ?? {}) as Record<string, unknown>;
    // Normalize stored case so chips compare cleanly (Feeder|Distribution|Garden).
    if (a.trench_type) {
      const raw = String(a.trench_type);
      setNetTrenchClass(raw.charAt(0).toUpperCase() + raw.slice(1));
    }
    if (a.duct_type) setNetDuctType(String(a.duct_type).toLowerCase());
    if (a.cable_type) {
      const raw = String(a.cable_type);
      setNetCableType(raw.charAt(0).toUpperCase() + raw.slice(1));
    }
    const strands = a.fiber_count ?? a.fibre_count ?? (isCableLayer ? a.capacity_total : undefined);
    if (strands != null) setNetFiberCount(String(strands));
    setNetCapacity(a.capacity_total != null && !isCableLayer ? String(a.capacity_total) : '');
    setNetSpare(a.spare_capacity != null ? String(a.spare_capacity) : '');
    setNetOccupied(a.occupied === true || a.occupied === 'true' || a.occupied === 'True' || a.occupied === 1 || a.occupied === '1');
    setNetCondition(a.condition ? String(a.condition) : '');
    setNetAerial(a.aerial_required === true || a.aerial_required === 'true' || a.aerial_required === 'True' || a.aerial_required === '1' || a.aerial_required === 1);
  }, [featureId]);

  const toggleModule = (name: string) => {
    setActiveModule(activeModule === name ? null : name);
  };

  /** Small green chip: "Saved {date}" — shown when an existing backend record was pre-filled */
  const renderSavedChip = (date?: string) =>
    date ? (
      <View style={[styles.savedChip, { backgroundColor: colors.success + '18' }]}>
        <CheckCircle size={10} stroke={colors.success} />
        <Text style={[styles.savedChipText, { color: colors.success }]} numberOfLines={1}>
          Saved {date}
        </Text>
      </View>
    ) : null;

  // ── Render ──────────────────────────────────────────────────────────────

  return (
    <View>
      {/* Module 1: Trench Classification */}
      {isTrenchLayer && (
        <View style={[styles.sectionCard, { backgroundColor: colors.surface }]}>
          <View style={styles.sectionHeader}>
            <View style={styles.sectionHeaderLeft}>
              <Text style={{ fontSize: 20, marginRight: 6 }}>🏗️</Text>
              <View>
                <Text style={[styles.sectionTitle, { color: colors.textPrimary }]}>Trench Classification</Text>
              <Text style={[styles.sectionSubtitle, { color: colors.textTertiary }]}>Select trench type & configure attributes</Text>
            </View>
            {renderSavedChip(savedDates.trench)}
          </View>
            <TouchableOpacity
              style={[styles.moduleToggle, { backgroundColor: activeModule === 'trench' ? colors.primary + '20' : 'transparent' }]}
              onPress={() => toggleModule('trench')}
            >
              <ChevronRight size={16} stroke={colors.primary} style={activeModule === 'trench' ? { transform: [{ rotate: '90deg' }] } : undefined} />
            </TouchableOpacity>
          </View>

          <View style={styles.trenchGrid}>
            {(Object.entries(TRENCH_TYPES) as [TrenchType, TrenchTypeInfo][]).map(([type, info]) => (
              <TouchableOpacity
                key={type}
                style={[
                  styles.trenchChip,
                  {
                    backgroundColor: selectedTrenchType === type ? info.color + '20' : colors.background,
                    borderColor: selectedTrenchType === type ? info.color : colors.outline,
                    borderWidth: selectedTrenchType === type ? 2 : 1,
                  },
                ]}
                onPress={() => { setSelectedTrenchType(type); setActiveModule('trench'); }}
              >
                <Text style={styles.trenchIcon}>{info.icon}</Text>
                <Text style={[styles.trenchLabel, { color: selectedTrenchType === type ? info.color : colors.textSecondary }]} numberOfLines={1}>
                  {info.label}
                </Text>
                {selectedTrenchType === type && <View style={[styles.trenchSelectedDot, { backgroundColor: info.color }]} />}
              </TouchableOpacity>
            ))}
          </View>

          {activeModule === 'trench' && selectedTrenchType && (
            <View style={styles.moduleContent}>
              <View style={styles.attrRow}>
                <Text style={[styles.attrLabel, { color: colors.textSecondary }]}>Depth (mm)</Text>
                <TextInput
                  style={[styles.attrInput, { color: colors.textPrimary, borderColor: colors.outline, backgroundColor: colors.background }]}
                  value={trenchAttrs.depth}
                  onChangeText={(v) => setTrenchAttrs((p) => ({ ...p, depth: v }))}
                  keyboardType="numeric"
                  placeholder="e.g. 450"
                  placeholderTextColor={colors.textTertiary}
                />
              </View>
              <View style={styles.attrRow}>
                <Text style={[styles.attrLabel, { color: colors.textSecondary }]}>Width (mm)</Text>
                <TextInput
                  style={[styles.attrInput, { color: colors.textPrimary, borderColor: colors.outline, backgroundColor: colors.background }]}
                  value={trenchAttrs.width}
                  onChangeText={(v) => setTrenchAttrs((p) => ({ ...p, width: v }))}
                  keyboardType="numeric"
                  placeholder="e.g. 300"
                  placeholderTextColor={colors.textTertiary}
                />
              </View>

              <View style={styles.attrRow}>
                <Text style={[styles.attrLabel, { color: colors.textSecondary }]}>Surface</Text>
                <View style={styles.optionRow}>
                  {['Asphalt', 'Concrete', 'Paving', 'Earth', 'Grass'].map((s) => (
                    <TouchableOpacity
                      key={s}
                      style={[styles.smallChip, { backgroundColor: trenchAttrs.surface_type === s.toLowerCase() ? colors.primary : colors.background, borderColor: colors.outline }]}
                      onPress={() => setTrenchAttrs((p) => ({ ...p, surface_type: s.toLowerCase() }))}
                    >
                      <Text style={[styles.smallChipText, { color: trenchAttrs.surface_type === s.toLowerCase() ? colors.onPrimary : colors.textSecondary }]}>{s}</Text>
                    </TouchableOpacity>
                  ))}
                </View>
              </View>

              <Text style={[styles.sectionLabel, { color: colors.textPrimary }]}>Crossings</Text>
              <View style={styles.toggleGrid}>
                {(['road_crossing', 'footpath_crossing', 'rail_crossing', 'river_crossing'] as const).map((key) => (
                  <TouchableOpacity
                    key={key}
                    style={[styles.toggleBtn, { backgroundColor: trenchAttrs[key] ? colors.primary + '20' : colors.background, borderColor: trenchAttrs[key] ? colors.primary : colors.outline }]}
                    onPress={() => setTrenchAttrs((p) => ({ ...p, [key]: !p[key] }))}
                  >
                    <View style={[styles.toggleCheck, { backgroundColor: trenchAttrs[key] ? colors.primary : 'transparent', borderColor: trenchAttrs[key] ? colors.primary : colors.outline }]}>
                      {trenchAttrs[key] && <CheckCircle size={12} stroke={colors.onPrimary} fill={colors.onPrimary} />}
                    </View>
                    <Text style={[styles.toggleLabel, { color: trenchAttrs[key] ? colors.primary : colors.textSecondary }]}>
                      {key.replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase())}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>

              <View style={styles.toggleGrid}>
                {(['private_property', 'traffic_sensitive', 'permit_required'] as const).map((key) => (
                  <TouchableOpacity
                    key={key}
                    style={[styles.toggleBtn, { backgroundColor: trenchAttrs[key] ? colors.warning + '20' : colors.background, borderColor: trenchAttrs[key] ? colors.warning : colors.outline }]}
                    onPress={() => setTrenchAttrs((p) => ({ ...p, [key]: !p[key] }))}
                  >
                    <View style={[styles.toggleCheck, { backgroundColor: trenchAttrs[key] ? colors.warning : 'transparent', borderColor: trenchAttrs[key] ? colors.warning : colors.outline }]}>
                      {trenchAttrs[key] && <CheckCircle size={12} stroke={colors.onPrimary} fill={colors.onPrimary} />}
                    </View>
                    <Text style={[styles.toggleLabel, { color: trenchAttrs[key] ? colors.warning : colors.textSecondary }]}>
                      {key.replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase())}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>

              <TextInput
                style={[styles.textarea, { color: colors.textPrimary, borderColor: colors.outline, backgroundColor: colors.background }]}
                value={trenchAttrs.notes}
                onChangeText={(v) => setTrenchAttrs((p) => ({ ...p, notes: v }))}
                placeholder="Trench notes, construction method details..."
                placeholderTextColor={colors.textTertiary}
                multiline
                numberOfLines={3}
              />

              <Button title="Save Trench Classification" variant="primary" size="sm" onPress={handleSaveTrench} style={{ marginTop: Spacing.md }} />
            </View>
          )}
        </View>
      )}

      {/* Module 2: Risk Assessment */}
      <View style={[styles.sectionCard, { backgroundColor: colors.surface }]}>
        <View style={styles.sectionHeader}>
          <View style={styles.sectionHeaderLeft}>
            <AlertTriangle size={18} stroke={colors.error} style={{ marginRight: 6 }} />
            <View>
              <Text style={[styles.sectionTitle, { color: colors.textPrimary }]}>Risk Assessment</Text>
              <Text style={[styles.sectionSubtitle, { color: colors.textTertiary }]}>Evaluate risks for this feature</Text>
            </View>
            {renderSavedChip(savedDates.risk)}
          </View>
          <TouchableOpacity
            style={[styles.moduleToggle, { backgroundColor: activeModule === 'risk' ? colors.primary + '20' : 'transparent' }]}
            onPress={() => toggleModule('risk')}
          >
            <ChevronRight size={16} stroke={colors.primary} style={activeModule === 'risk' ? { transform: [{ rotate: '90deg' }] } : undefined} />
          </TouchableOpacity>
        </View>

        <Text style={[styles.sectionLabel, { color: colors.textPrimary }]}>Risk Category</Text>
        <View style={styles.categoryGrid}>
          {RISK_CATEGORIES.map((cat) => (
            <TouchableOpacity
              key={cat.value}
              style={[styles.categoryChip, { backgroundColor: riskCategory === cat.value ? colors.error + '20' : colors.background, borderColor: riskCategory === cat.value ? colors.error : colors.outline }]}
              onPress={() => { setRiskCategory(cat.value); setActiveModule('risk'); }}
            >
              <Text style={[styles.categoryText, { color: riskCategory === cat.value ? colors.error : colors.textSecondary }]}>{cat.label}</Text>
            </TouchableOpacity>
          ))}
        </View>

        {activeModule === 'risk' && riskCategory && (
          <View style={styles.moduleContent}>
            <Text style={[styles.sectionLabel, { color: colors.textPrimary }]}>Severity</Text>
            <View style={styles.severityRow}>
              {SEVERITY_LEVELS.map((sev) => {
                const sc = getSeverityColor(sev);
                return (
                  <TouchableOpacity
                    key={sev}
                    style={[styles.severityBtn, { backgroundColor: riskSeverity === sev ? sc.bg : colors.background, borderColor: riskSeverity === sev ? sc.text : colors.outline }]}
                    onPress={() => setRiskSeverity(sev)}
                  >
                    <Text style={[styles.severityText, { color: riskSeverity === sev ? sc.text : colors.textSecondary, fontWeight: riskSeverity === sev ? '700' : '500' }]}>
                      {sev.charAt(0).toUpperCase() + sev.slice(1)}
                    </Text>
                  </TouchableOpacity>
                );
              })}
            </View>

            <Text style={[styles.sectionLabel, { color: colors.textPrimary }]}>Probability</Text>
            <View style={styles.severityRow}>
              {PROBABILITY_LEVELS.map((prob) => {
                const pc = getProbabilityColor(prob);
                return (
                  <TouchableOpacity
                    key={prob}
                    style={[styles.severityBtn, { backgroundColor: riskProbability === prob ? pc.bg : colors.background, borderColor: riskProbability === prob ? pc.text : colors.outline }]}
                    onPress={() => setRiskProbability(prob)}
                  >
                    <Text style={[styles.severityText, { color: riskProbability === prob ? pc.text : colors.textSecondary, fontWeight: riskProbability === prob ? '700' : '500' }]}>
                      {prob.charAt(0).toUpperCase() + prob.slice(1)}
                    </Text>
                  </TouchableOpacity>
                );
              })}
            </View>

            <TextInput
              style={[styles.textarea, { color: colors.textPrimary, borderColor: colors.outline, backgroundColor: colors.background }]}
              value={riskMitigation}
              onChangeText={setRiskMitigation}
              placeholder="Describe mitigation measures..."
              placeholderTextColor={colors.textTertiary}
              multiline
              numberOfLines={2}
            />
            <TextInput
              style={[styles.textarea, { color: colors.textPrimary, borderColor: colors.outline, backgroundColor: colors.background }]}
              value={riskNotes}
              onChangeText={setRiskNotes}
              placeholder="Additional notes..."
              placeholderTextColor={colors.textTertiary}
              multiline
              numberOfLines={2}
            />

            <Button title="Save Risk Assessment" variant="primary" size="sm" onPress={handleSaveRisk} style={{ marginTop: Spacing.md }} />
          </View>
        )}
      </View>

      {/* Module 3: Hazards */}
      <View style={[styles.sectionCard, { backgroundColor: colors.surface }]}>
        <View style={styles.sectionHeader}>
          <View style={styles.sectionHeaderLeft}>
            <Text style={{ fontSize: 20, marginRight: 6 }}>🚧</Text>
            <View>
              <Text style={[styles.sectionTitle, { color: colors.textPrimary }]}>Hazards</Text>
              <Text style={[styles.sectionSubtitle, { color: colors.textTertiary }]}>Identify site hazards & record mitigations</Text>
            </View>
            {renderSavedChip(savedDates.hazard)}
          </View>
          <TouchableOpacity
            style={[styles.moduleToggle, { backgroundColor: activeModule === 'hazard' ? colors.primary + '20' : 'transparent' }]}
            onPress={() => toggleModule('hazard')}
          >
            <ChevronRight size={16} stroke={colors.primary} style={activeModule === 'hazard' ? { transform: [{ rotate: '90deg' }] } : undefined} />
          </TouchableOpacity>
        </View>

        <Text style={[styles.sectionLabel, { color: colors.textPrimary }]}>Hazard Type</Text>
        <View style={styles.categoryGrid}>
          {HAZARD_TYPES.map((hazard) => (
            <TouchableOpacity
              key={hazard.value}
              style={[styles.categoryChip, { backgroundColor: selectedHazard === hazard.value ? colors.warning + '20' : colors.background, borderColor: selectedHazard === hazard.value ? colors.warning : colors.outline }]}
              onPress={() => { setSelectedHazard(hazard.value); setActiveModule('hazard'); }}
            >
              <Text style={[styles.categoryText, { color: selectedHazard === hazard.value ? colors.warning : colors.textSecondary }]}>{hazard.label}</Text>
            </TouchableOpacity>
          ))}
        </View>

        {activeModule === 'hazard' && selectedHazard && (
          <View style={styles.moduleContent}>
            <Text style={[styles.sectionLabel, { color: colors.textPrimary }]}>Mitigation Template</Text>
            <View style={styles.categoryGrid}>
              {MITIGATION_TEMPLATES.map((tmpl) => (
                <TouchableOpacity
                  key={tmpl.value}
                  style={[styles.mitigationChip, { backgroundColor: hazardMitigation === tmpl.value ? colors.success + '20' : colors.background, borderColor: hazardMitigation === tmpl.value ? colors.success : colors.outline }]}
                  onPress={() => setHazardMitigation(tmpl.value)}
                >
                  <Text style={[styles.mitigationText, { color: hazardMitigation === tmpl.value ? colors.success : colors.textSecondary }]}>{tmpl.label}</Text>
                </TouchableOpacity>
              ))}
            </View>

            <TextInput
              style={[styles.textarea, { color: colors.textPrimary, borderColor: colors.outline, backgroundColor: colors.background }]}
              value={hazardNotes}
              onChangeText={setHazardNotes}
              placeholder="Hazard notes, location, severity details..."
              placeholderTextColor={colors.textTertiary}
              multiline
              numberOfLines={3}
            />

            <Button title="Record Hazard" variant="primary" size="sm" onPress={handleSaveHazard} style={{ marginTop: Spacing.md }} />
          </View>
        )}
      </View>

      {/* Module 4: Field Evidence */}
      <View style={[styles.sectionCard, { backgroundColor: colors.surface }]}>
        <View style={styles.sectionHeader}>
          <View style={styles.sectionHeaderLeft}>
            <Camera size={18} stroke={colors.primary} style={{ marginRight: 6 }} />
            <View>
              <Text style={[styles.sectionTitle, { color: colors.textPrimary }]}>Field Evidence</Text>
              <Text style={[styles.sectionSubtitle, { color: colors.textTertiary }]}>Record observations, photos, and measurements</Text>
            </View>
            {renderSavedChip(savedDates.evidence)}
          </View>
          <TouchableOpacity
            style={[styles.moduleToggle, { backgroundColor: activeModule === 'evidence' ? colors.primary + '20' : 'transparent' }]}
            onPress={() => toggleModule('evidence')}
          >
            <ChevronRight size={16} stroke={colors.primary} style={activeModule === 'evidence' ? { transform: [{ rotate: '90deg' }] } : undefined} />
          </TouchableOpacity>
        </View>

        {activeModule === 'evidence' && (
          <View style={styles.moduleContent}>
            <View style={styles.evidenceTypes}>
              <TouchableOpacity
                style={[styles.evidenceBtn, { backgroundColor: colors.primary + '15', borderColor: colors.primary }]}
                onPress={() => router.push({ pathname: '/camera', params: { featureId } })}
              >
                <Camera size={20} stroke={colors.primary} />
                <Text style={[styles.evidenceBtnText, { color: colors.primary }]}>Photo</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.evidenceBtn, { backgroundColor: colors.warning + '15', borderColor: colors.warning }]}
                onPress={() => setEvidenceDescription((prev) => (prev ? prev + '\n' : '') + 'Measurement: ')}
              >
                <Ruler size={20} stroke={colors.warning} />
                <Text style={[styles.evidenceBtnText, { color: colors.warning }]}>Measure</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.evidenceBtn, { backgroundColor: colors.success + '15', borderColor: colors.success }]}
                onPress={() => setEvidenceDescription((prev) => (prev ? prev + '\n' : '') + 'Note: ')}
              >
                <ClipboardList size={20} stroke={colors.success} />
                <Text style={[styles.evidenceBtnText, { color: colors.success }]}>Note</Text>
              </TouchableOpacity>
            </View>

            <TextInput
              style={[styles.textarea, { color: colors.textPrimary, borderColor: colors.outline, backgroundColor: colors.background }]}
              value={evidenceDescription}
              onChangeText={setEvidenceDescription}
              placeholder="Describe what you observed..."
              placeholderTextColor={colors.textTertiary}
              multiline
              numberOfLines={3}
            />

            <Text style={[styles.sectionLabel, { color: colors.textPrimary }]}>Weather</Text>
            <View style={styles.optionRow}>
              {['Sunny', 'Cloudy', 'Rain', 'Fog', 'Wind'].map((w) => (
                <TouchableOpacity
                  key={w}
                  style={[styles.smallChip, { backgroundColor: evidenceWeather === w.toLowerCase() ? colors.primary : colors.background, borderColor: colors.outline }]}
                  onPress={() => setEvidenceWeather(w.toLowerCase())}
                >
                  <Text style={[styles.smallChipText, { color: evidenceWeather === w.toLowerCase() ? colors.onPrimary : colors.textSecondary }]}>{w}</Text>
                </TouchableOpacity>
              ))}
            </View>

            <Button title="Save Observation" variant="primary" size="sm" onPress={handleSaveEvidence} style={{ marginTop: Spacing.md }} />
          </View>
        )}
      </View>

      {/* Module 5: Network Attributes (LLD-facing field data) */}
      {(isTrenchLayer || isDuctLayer || isCableLayer || isPremiseLayer) && (
        <View style={[styles.sectionCard, { backgroundColor: colors.surface }]}>
          <View style={styles.sectionHeader}>
            <View style={styles.sectionHeaderLeft}>
              <Text style={{ fontSize: 20, marginRight: 6 }}>🧵</Text>
              <View>
                <Text style={[styles.sectionTitle, { color: colors.textPrimary }]}>Network Attributes</Text>
                <Text style={[styles.sectionSubtitle, { color: colors.textTertiary }]}>Field data that drives LLD routing</Text>
              </View>
              {renderSavedChip(savedDates.network)}
            </View>
            <TouchableOpacity
              style={[styles.moduleToggle, { backgroundColor: activeModule === 'network' ? colors.primary + '20' : 'transparent' }]}
              onPress={() => toggleModule('network')}
            >
              <ChevronRight size={16} stroke={colors.primary} style={activeModule === 'network' ? { transform: [{ rotate: '90deg' }] } : undefined} />
            </TouchableOpacity>
          </View>

          {/* Trench classification — Feeder | Distribution | Garden (LLD TRENCH_TYPE) */}
          {isTrenchLayer && (
            <>
              <Text style={[styles.sectionLabel, { color: colors.textPrimary }]}>Trench Classification</Text>
              <View style={styles.categoryGrid}>
                {['Feeder', 'Distribution', 'Garden'].map((c) => (
                  <TouchableOpacity
                    key={c}
                    style={[styles.categoryChip, { backgroundColor: netTrenchClass === c ? colors.primary + '20' : colors.background, borderColor: netTrenchClass === c ? colors.primary : colors.outline }]}
                    onPress={() => { setNetTrenchClass(c); setActiveModule('network'); }}
                  >
                    <Text style={[styles.categoryText, { color: netTrenchClass === c ? colors.primary : colors.textSecondary }]}>{c}</Text>
                  </TouchableOpacity>
                ))}
              </View>
              {activeModule === 'network' && (
                <Text style={[styles.attrLabel, { color: colors.textTertiary }]}>Feeder runs PDP→MFG, Distribution runs premise→PDP, Garden is the short drop to the building. LLD mirrors Garden trenches into final_trenches.</Text>
              )}
            </>
          )}

          {/* Duct capacity / condition — read by LLD _survey_capacity */}
          {isDuctLayer && (
            <>
              <Text style={[styles.sectionLabel, { color: colors.textPrimary }]}>Duct Type</Text>
              <View style={styles.categoryGrid}>
                {['single', 'twin', 'quad'].map((t) => (
                  <TouchableOpacity
                    key={t}
                    style={[styles.categoryChip, { backgroundColor: netDuctType === t ? colors.primary + '20' : colors.background, borderColor: netDuctType === t ? colors.primary : colors.outline }]}
                    onPress={() => { setNetDuctType(t); setActiveModule('network'); }}
                  >
                    <Text style={[styles.categoryText, { color: netDuctType === t ? colors.primary : colors.textSecondary }]}>{t.charAt(0).toUpperCase() + t.slice(1)}</Text>
                  </TouchableOpacity>
                ))}
              </View>
              {activeModule === 'network' && (
                <View style={styles.moduleContent}>
                  <View style={styles.attrRow}>
                    <Text style={[styles.attrLabel, { color: colors.textSecondary }]}>Capacity (ways)</Text>
                    <TextInput
                      style={[styles.attrInput, { color: colors.textPrimary, borderColor: colors.outline, backgroundColor: colors.background }]}
                      value={netCapacity}
                      onChangeText={setNetCapacity}
                      keyboardType="numeric"
                      placeholder="e.g. 4"
                      placeholderTextColor={colors.textTertiary}
                    />
                  </View>
                  <View style={styles.attrRow}>
                    <Text style={[styles.attrLabel, { color: colors.textSecondary }]}>Spare capacity %</Text>
                    <TextInput
                      style={[styles.attrInput, { color: colors.textPrimary, borderColor: colors.outline, backgroundColor: colors.background }]}
                      value={netSpare}
                      onChangeText={setNetSpare}
                      keyboardType="numeric"
                      placeholder="e.g. 50"
                      placeholderTextColor={colors.textTertiary}
                    />
                  </View>
                  <Text style={[styles.sectionLabel, { color: colors.textPrimary }]}>Condition</Text>
                  <View style={styles.categoryGrid}>
                    {['good', 'partial', 'blocked', 'collapsed'].map((c) => (
                      <TouchableOpacity
                        key={c}
                        style={[styles.categoryChip, { backgroundColor: netCondition === c ? (c === 'blocked' || c === 'collapsed' ? colors.error + '20' : colors.success + '20') : colors.background, borderColor: netCondition === c ? (c === 'blocked' || c === 'collapsed' ? colors.error : colors.success) : colors.outline }]}
                        onPress={() => setNetCondition(c)}
                      >
                        <Text style={[styles.categoryText, { color: netCondition === c ? (c === 'blocked' || c === 'collapsed' ? colors.error : colors.success) : colors.textSecondary }]}>{c}</Text>
                      </TouchableOpacity>
                    ))}
                  </View>
                  <TouchableOpacity
                    style={[styles.toggleBtn, { backgroundColor: netOccupied ? colors.warning + '20' : colors.background, borderColor: netOccupied ? colors.warning : colors.outline }]}
                    onPress={() => setNetOccupied(!netOccupied)}
                  >
                    <View style={[styles.toggleCheck, { backgroundColor: netOccupied ? colors.warning : 'transparent', borderColor: netOccupied ? colors.warning : colors.outline }]}>
                      {netOccupied && <CheckCircle size={12} stroke={colors.onPrimary} fill={colors.onPrimary} />}
                    </View>
                    <Text style={[styles.toggleLabel, { color: netOccupied ? colors.warning : colors.textSecondary }]}>Occupied / Full</Text>
                  </TouchableOpacity>
                  <Text style={[styles.attrLabel, { color: colors.textTertiary, marginTop: Spacing.sm }]}>Blocked or collapsed ducts are excluded from LLD routing. Spare % inverts against total capacity.</Text>
                </View>
              )}
            </>
          )}

          {/* Cable — Feeder & Distribution survey data; fibre count per cable */}
          {isCableLayer && (
            <>
              <Text style={[styles.sectionLabel, { color: colors.textPrimary }]}>Cable Type</Text>
              <View style={styles.categoryGrid}>
                {['Feeder', 'Distribution'].map((t) => (
                  <TouchableOpacity
                    key={t}
                    style={[styles.categoryChip, { backgroundColor: netCableType === t ? colors.primary + '20' : colors.background, borderColor: netCableType === t ? colors.primary : colors.outline }]}
                    onPress={() => { setNetCableType(t); setActiveModule('network'); }}
                  >
                    <Text style={[styles.categoryText, { color: netCableType === t ? colors.primary : colors.textSecondary }]}>{t}</Text>
                  </TouchableOpacity>
                ))}
              </View>
              {activeModule === 'network' && (
                <View style={styles.moduleContent}>
                  <View style={styles.attrRow}>
                    <Text style={[styles.attrLabel, { color: colors.textSecondary }]}>Fibre count</Text>
                    <TextInput
                      style={[styles.attrInput, { color: colors.textPrimary, borderColor: colors.outline, backgroundColor: colors.background }]}
                      value={netFiberCount}
                      onChangeText={setNetFiberCount}
                      keyboardType="numeric"
                      placeholder="e.g. 48"
                      placeholderTextColor={colors.textTertiary}
                    />
                  </View>
                  <Text style={[styles.attrLabel, { color: colors.textTertiary }]}>Strands in this physical cable — Feeder 288, Distribution ≥ 48, Garden 12. LLD reads this as the cable's capacity.</Text>
                </View>
              )}
            </>
          )}

          {/* Aerial flag — read by Mode A + aerial_drop_planner */}
          {(isPremiseLayer || isDuctLayer) && (
            <>
              <TouchableOpacity
                style={[styles.toggleBtn, { backgroundColor: netAerial ? colors.primary + '20' : colors.background, borderColor: netAerial ? colors.primary : colors.outline, alignSelf: 'flex-start', marginTop: Spacing.sm }]}
                onPress={() => setNetAerial(!netAerial)}
              >
                <View style={[styles.toggleCheck, { backgroundColor: netAerial ? colors.primary : 'transparent', borderColor: netAerial ? colors.primary : colors.outline }]}>
                  {netAerial && <CheckCircle size={12} stroke={colors.onPrimary} fill={colors.onPrimary} />}
                </View>
                <Text style={[styles.toggleLabel, { color: netAerial ? colors.primary : colors.textSecondary }]}>Aerial drop required</Text>
              </TouchableOpacity>
              {activeModule === 'network' && isPremiseLayer && (
                <Text style={[styles.attrLabel, { color: colors.textTertiary, marginTop: Spacing.sm }]}>Flagging a premise routes its drop overhead (pole route) instead of underground when LLD runs.</Text>
              )}
            </>
          )}

          {(activeModule === 'network' || netTrenchClass !== '' || netDuctType !== '' || netCableType !== '' || netFiberCount !== '' || netCapacity !== '' || netSpare !== '' || netCondition !== '' || netOccupied || netAerial) && (
            <Button title="Save Network Attributes" variant="primary" size="sm" onPress={handleSaveNetworkAttrs} style={{ marginTop: Spacing.md }} />
          )}
        </View>
      )}

      {/* Module 6: Survey Status */}
      <View style={[styles.sectionCard, { backgroundColor: colors.surface }]}>
        <View style={styles.sectionHeader}>
          <View style={styles.sectionHeaderLeft}>
            <ClipboardList size={18} stroke={colors.primary} style={{ marginRight: 6 }} />
            <View>
              <Text style={[styles.sectionTitle, { color: colors.textPrimary }]}>Survey Status</Text>
              <Text style={[styles.sectionSubtitle, { color: colors.textTertiary }]}>Update feature workflow status</Text>
            </View>
            {renderSavedChip(savedDates.status)}
          </View>
          <TouchableOpacity
            style={[styles.moduleToggle, { backgroundColor: activeModule === 'status' ? colors.primary + '20' : 'transparent' }]}
            onPress={() => toggleModule('status')}
          >
            <ChevronRight size={16} stroke={colors.primary} style={activeModule === 'status' ? { transform: [{ rotate: '90deg' }] } : undefined} />
          </TouchableOpacity>
        </View>

        {activeModule === 'status' && (
          <View style={styles.moduleContent}>
            <View style={styles.statusFlow}>
              {SURVEY_STATUS_FLOW.slice(0, 4).map((status, idx) => {
                const flowIdx = SURVEY_STATUS_FLOW.indexOf(surveyStatus as typeof SURVEY_STATUS_FLOW[number]);
                const itemIdx = SURVEY_STATUS_FLOW.indexOf(status);
                const isActive = surveyStatus === status;
                const isPast = flowIdx > itemIdx;
                return (
                  <TouchableOpacity key={status} style={[styles.statusStep, { flex: 1 }]} onPress={() => setSurveyStatus(status)}>
                    <View style={[styles.statusDot, {
                      backgroundColor: isActive ? colors.primary : isPast ? colors.success : colors.outlineLight,
                      borderColor: isActive ? colors.primary : colors.outline,
                      borderWidth: isActive ? 3 : 1,
                    }]}>
                      {isPast && <CheckCircle size={12} stroke={colors.onPrimary} fill={colors.onPrimary} />}
                      {isActive && <View style={[styles.statusInnerDot, { backgroundColor: colors.onPrimary }]} />}
                    </View>
                    <Text style={[styles.statusLabel, { color: isActive ? colors.primary : colors.textTertiary, fontWeight: isActive ? '700' : '400' }]} numberOfLines={2}>
                      {status.replace(/_/g, ' ')}
                    </Text>
                    {idx < 3 && <View style={[styles.statusLine, { backgroundColor: isPast ? colors.success : colors.outlineLight }]} />}
                  </TouchableOpacity>
                );
              })}
            </View>

            <View style={styles.statusFlow}>
              {SURVEY_STATUS_FLOW.slice(4).map((status, idx) => {
                const flowIdx = SURVEY_STATUS_FLOW.indexOf(surveyStatus as typeof SURVEY_STATUS_FLOW[number]);
                const itemIdx = SURVEY_STATUS_FLOW.indexOf(status);
                const isActive = surveyStatus === status;
                const isPast = flowIdx > itemIdx;
                return (
                  <TouchableOpacity key={status} style={[styles.statusStep, { flex: 1 }]} onPress={() => setSurveyStatus(status)}>
                    <View style={[styles.statusDot, {
                      backgroundColor: isActive ? colors.primary : isPast ? colors.success : colors.outlineLight,
                      borderColor: isActive ? colors.primary : colors.outline,
                      borderWidth: isActive ? 3 : 1,
                    }]}>
                      {isPast && <CheckCircle size={12} stroke={colors.onPrimary} fill={colors.onPrimary} />}
                      {isActive && <View style={[styles.statusInnerDot, { backgroundColor: colors.onPrimary }]} />}
                    </View>
                    <Text style={[styles.statusLabel, { color: isActive ? colors.primary : colors.textTertiary, fontWeight: isActive ? '700' : '400' }]} numberOfLines={2}>
                      {status.replace(/_/g, ' ')}
                    </Text>
                    {idx < 3 && <View style={[styles.statusLine, { backgroundColor: isPast ? colors.success : colors.outlineLight }]} />}
                  </TouchableOpacity>
                );
              })}
            </View>

            <TextInput
              style={[styles.textarea, { color: colors.textPrimary, borderColor: colors.outline, backgroundColor: colors.background }]}
              value={fieldNotes}
              onChangeText={setFieldNotes}
              placeholder="Add field notes, observations, or reasons for status change..."
              placeholderTextColor={colors.textTertiary}
              multiline
              numberOfLines={3}
            />

            <View style={styles.statusActions}>
              <Button title="Update Status" variant="primary" size="sm" onPress={handleUpdateStatus} style={{ flex: 1 }} />
              <Button title="Flag Issue" variant="secondary" size="sm" icon={<Flag size={14} stroke={colors.primary} />} onPress={() => showToast('Feature flagged for review', 'success')} style={{ flex: 1 }} />
            </View>
          </View>
        )}
      </View>

      {/* Change History */}
      {store.changes.some((c) => c.feature === featureId) && (
        <View style={[styles.sectionCard, { backgroundColor: colors.surface }]}>
          <View style={styles.sectionHeader}>
            <View style={styles.sectionHeaderLeft}>
              <Text style={{ fontSize: 18, marginRight: 6 }}>📝</Text>
              <Text style={[styles.sectionTitle, { color: colors.textPrimary }]}>Recent Changes</Text>
            </View>
          </View>
          {store.changes.filter((c) => c.feature === featureId).slice(0, 5).map((change) => (
            <View key={change.id} style={styles.changeRow}>
              <View style={styles.changeLeft}>
                <Text style={[styles.changeField, { color: colors.textPrimary }]}>{change.field_name}</Text>
                <Text style={[styles.changeReason, { color: colors.textTertiary }]}>{change.reason}</Text>
              </View>
              <Text style={[styles.changeTime, { color: colors.textTertiary }]}>
                {new Date(change.created_at).toLocaleDateString()}
              </Text>
            </View>
          ))}
        </View>
      )}

      <Toast visible={toastVisible} message={toastMsg} type={toastType} onDismiss={() => setToastVisible(false)} />
    </View>
  );
}

// ── Styles ─────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  sectionCard: {
    borderRadius: Radius.lg,
    padding: Spacing.lg,
    marginBottom: Spacing.md,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.06,
    shadowRadius: 3,
    elevation: 2,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: Spacing.md,
  },
  sectionHeaderLeft: { flexDirection: 'row', alignItems: 'center', flex: 1 },
  sectionTitle: { fontSize: 16, fontWeight: '700' },
  sectionSubtitle: { fontSize: 11, marginTop: 1 },
  moduleToggle: { width: 32, height: 32, borderRadius: 16, alignItems: 'center', justifyContent: 'center' },

  // ── "Saved …" chip ───────────────────────────────────────────────────
  savedChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 3,
    marginLeft: 'auto',
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: Radius.full,
    marginRight: 6,
  },
  savedChipText: { fontSize: 9, fontWeight: '600' },
  moduleContent: { marginTop: Spacing.md, paddingTop: Spacing.md, borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: '#E5E7EB' },

  trenchGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.sm },
  trenchChip: { width: '23%', paddingVertical: Spacing.md, paddingHorizontal: 4, borderRadius: Radius.lg, alignItems: 'center', borderWidth: 1, minWidth: 70 },
  trenchIcon: { fontSize: 20, marginBottom: 4 },
  trenchLabel: { fontSize: 9, fontWeight: '600', textAlign: 'center' },
  trenchSelectedDot: { width: 6, height: 6, borderRadius: 3, marginTop: 4 },
  attrRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: Spacing.md },
  attrLabel: { fontSize: 13, fontWeight: '500', width: 100 },
  attrInput: { flex: 1, borderWidth: 1, borderRadius: Radius.md, paddingHorizontal: Spacing.md, fontSize: 14, height: 44 },
  optionRow: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.sm, flex: 1 },
  smallChip: { paddingHorizontal: 12, paddingVertical: 8, borderRadius: Radius.full, borderWidth: 1 },
  smallChipText: { fontSize: 12, fontWeight: '500' },
  sectionLabel: { fontSize: 14, fontWeight: '600', marginBottom: Spacing.sm, marginTop: Spacing.md },
  toggleGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.sm, marginBottom: Spacing.md },
  toggleBtn: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 12, paddingVertical: 10, borderRadius: Radius.md, borderWidth: 1 },
  toggleCheck: { width: 18, height: 18, borderRadius: 9, alignItems: 'center', justifyContent: 'center', borderWidth: 2 },
  toggleLabel: { fontSize: 12, fontWeight: '500' },
  textarea: { borderWidth: 1, borderRadius: Radius.md, paddingHorizontal: Spacing.lg, paddingTop: Spacing.md, fontSize: 14, minHeight: 80, textAlignVertical: 'top', marginBottom: Spacing.md },
  categoryGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.sm, marginBottom: Spacing.sm },
  categoryChip: { paddingHorizontal: 12, paddingVertical: 8, borderRadius: Radius.full, borderWidth: 1 },
  categoryText: { fontSize: 12, fontWeight: '500' },
  severityRow: { flexDirection: 'row', gap: Spacing.sm, marginBottom: Spacing.md },
  severityBtn: { flex: 1, paddingVertical: 12, borderRadius: Radius.md, borderWidth: 1, alignItems: 'center' },
  severityText: { fontSize: 13 },
  mitigationChip: { paddingHorizontal: 12, paddingVertical: 8, borderRadius: Radius.md, borderWidth: 1 },
  mitigationText: { fontSize: 11, fontWeight: '500' },
  evidenceTypes: { flexDirection: 'row', gap: Spacing.sm, marginBottom: Spacing.md },
  evidenceBtn: { flex: 1, alignItems: 'center', paddingVertical: Spacing.lg, borderRadius: Radius.lg, borderWidth: 1.5, borderStyle: 'dashed', gap: Spacing.sm },
  evidenceBtnText: { fontSize: 13, fontWeight: '600' },
  statusFlow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: Spacing.lg, paddingHorizontal: 4 },
  statusStep: { alignItems: 'center', position: 'relative' },
  statusDot: { width: 28, height: 28, borderRadius: 14, alignItems: 'center', justifyContent: 'center', marginBottom: 4 },
  statusInnerDot: { width: 8, height: 8, borderRadius: 4 },
  statusLabel: { fontSize: 9, textAlign: 'center', textTransform: 'capitalize', lineHeight: 13 },
  statusLine: { position: 'absolute', top: 14, left: '60%', right: '-60%', height: 2 },
  statusActions: { flexDirection: 'row', gap: Spacing.sm, marginTop: Spacing.sm },
  changeRow: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: Spacing.sm, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: '#E5E7EB' },
  changeLeft: { flex: 1 },
  changeField: { fontSize: 14, fontWeight: '500' },
  changeReason: { fontSize: 12, marginTop: 2 },
  changeTime: { fontSize: 11 },
});
